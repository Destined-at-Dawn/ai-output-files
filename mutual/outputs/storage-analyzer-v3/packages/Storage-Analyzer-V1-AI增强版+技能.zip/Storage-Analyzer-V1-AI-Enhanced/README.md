# Storage Analyzer V4 -- AI 增强版（小黎改良版）

## 这是什么

需要配合 AI Agent（牛马AI / Claude Code）使用的磁盘清理技能。
AI 会读取扫描结果，智能分析后生成交互式清理报告。

## 怎么用

1. 将 skill/ 文件夹复制到 ~/.newmax/skills/storage-analyzer/
2. 重启牛马AI
3. 说 "C盘满了" 或 "清理电脑空间"
4. AI 会自动扫描 -> 分析 -> 生成报告

## 安全机制

- 只读扫描，不碰任何文件
- AI 分析后三色分级
- 一键清理前可逐项预览
- 所有删除进回收站

## 需要什么

- 牛马AI 或 Claude Code
- Python 3.8+

## 这东西哪来的

原作者：数字生命卡兹克
小黎改良版：Windows 深度适配 / GBK 编码适配

## 有问题？

群里 @小黎
