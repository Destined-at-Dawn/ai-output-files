#!/bin/bash
# Storage Analyzer -- macOS/Linux Launcher
# 小黎改良版 V4

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "Storage Analyzer V4"
echo "[1] 一键清理  [2] 扫描+报告  [3] 仅扫描  [4] 退出"
read -p "选择 (1-4): " choice

case $choice in
  1)
    python3 scripts/scan.py --all-drives --output raw_scan.json
    python3 scripts/auto_analyze.py raw_scan.json analysis_result.json
    python3 scripts/direct_clean.py --no-scan
    ;;
  2)
    python3 scripts/scan.py --all-drives --output raw_scan.json
    python3 scripts/auto_analyze.py raw_scan.json analysis_result.json
    python3 scripts/build_report.py analysis_result.json
    open report.html 2>/dev/null || xdg-open report.html 2>/dev/null
    ;;
  3)
    python3 scripts/scan.py --all-drives --output raw_scan.json
    python3 scripts/auto_analyze.py raw_scan.json analysis_result.json
    python3 scripts/build_report.py analysis_result.json
    open report.html 2>/dev/null || xdg-open report.html 2>/dev/null
    ;;
  *) echo "退出"; exit 0 ;;
esac
