---
name: li-embedded
description: >
  STM32/ARM Cortex-M 专业嵌入式固件开发——融合裸机编程、状态机架构、实时调试、硬件 CI/CD。
  针对具身智能机器人、硬件工程师日常 — 写代码 + 调试设备。
  触发词：STM32, ARM, embedded, firmware, bare-metal, state machine, RTOS, 嵌入式, 固件, 调试设备, 硬件, 寄存器, 中断, SWD, RTT, 实时.
---

# li-embedded — STM32/ARM 嵌入式专业开发

> 版本：v1.0 | 创建：2026-06-12 ｜ 融合：li-debug + li-hardware + li-code + li-improve + li-analyze
> 依据：cpq bare-metal guide (4.7k★) + Miro Samek 现代嵌入式课程 (1.3k★) + Awesome-Embedded (8.7k★)

---

## 你为什么需要这个 skill

**问题**：AI 默认堆 STM32 HAL 调用，看似能工作，但大块代码易出错 —— 中断丢失、状态混乱、调试盲区。根因是 AI 脑子里没有"专业固件长什么样"。

**解法**：这个 skill 把 GitHub 社区 30 年最佳实践（状态机 + 裸机基础 + 调试工具链）打包成可执行知识，让 AI 写固件时带着范式走。

---

## Phase 0：理解你的工作场景

你是具身智能硬件工程师，日常：
- 写 STM32 控制代码（电机驱动、传感器采集、ROS 通信）
- 调试设备（什么时候执行了？变量值是多少？为什么卡住了？）
- 在实时约束下工作（响应延迟 < 10ms 才行）

→ 这不是"学嵌入式"，是"高效写好生产代码"。不同的套路。

---

## 核心架构（四域）

### 域1：裸机基础 = 理解硬件

为什么要学？AI 容易假设寄存器自动配置，你需要看穿：

```c
// 这 8 行，多少 AI 生成的代码忘了做？
RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;          // 1. 使能时钟
GPIOA->MODER |= (1 << (2*5));                 // 2. GPIO 模式 = 输出
GPIOA->OSPEEDR |= (3 << (2*5));               // 3. 速度 = 高速
GPIOA->OTYPER &= ~(1 << 5);                   // 4. 输出类型 = 推挽
GPIOA->PUPDR &= ~(3 << (2*5));                // 5. 上/下拉 = 禁用
// 同时要记住：不同外设在不同总线（APB1 ≤ 45MHz, APB2 ≤ 90MHz）
// 不同端口的寄存器基址不同（0x40020000 + 0x400 * bank）
```

**cpq 指南的规范**：把这些细节抽成 **pin abstraction macro**，让代码自动不出错。

```c
#define PIN(bank, num)       ((((bank) - 'A') << 8) | (num))
#define PINNO(pin)           ((pin) & 255)
#define PINBANK(pin)         ((pin) >> 8)

void gpio_output(uint16_t pin) {
  struct gpio *gpio = GPIO(PINBANK(pin));
  uint8_t no = PINNO(pin);
  RCC->AHB1ENR |= (1 << PINBANK(pin));     // 自动选对时钟
  gpio->MODER |= (1 << (2 * no));          // 自动计算位位置
}
```

→ **AI 生成码时要用这套模板，不要裸写 0x40020000。**

---

### 域2：状态机架构 = 摆脱 superloop 陷阱

具身智能的控制层天然是有限状态机（FSM）。Miro Samek 的教训：**superloop（无限循环轮询）是业余固件的标志。**

#### 反模式（别这样）
```c
// ❌ 为什么这烂？无法处理实时约束，中断打乱执行顺序，代码搅成一团
while (1) {
  read_sensor();
  if (sensor > threshold) {
    do_something();
  }
  check_motor_status();
  // 一个 read_sensor() 卡了 10ms，整个控制回环就卡住
}
```

#### 正确模式：Event-Driven State Machine
```c
typedef enum {
  STATE_IDLE,
  STATE_ACCELERATING,
  STATE_CRUISING,
  STATE_DECELERATING
} MotorState;

// 中断驱动事件
void EXTI_Handler(void) {           // 传感器中断
  postEvent(EVENT_SENSOR_TRIGGER);
}

// 在主循环中处理事件（非中断）
void handle_events(void) {
  Event e = getEvent();
  switch (current_state) {
    case STATE_IDLE:
      if (e == EVENT_SENSOR_TRIGGER) {
        current_state = STATE_ACCELERATING;
        set_motor_speed(100);
      }
      break;
    case STATE_ACCELERATING:
      if (e == EVENT_MAX_SPEED_REACHED) {
        current_state = STATE_CRUISING;
      }
      break;
    // ...
  }
}
```

**为什么这更好**：
- 中断只负责记录事件，不干复杂活
- 主循环安全处理事件
- 每个状态的行为清晰隔离
- 添加新状态 = 加一个 case，不用改主循环

→ **AI 设计控制逻辑时，问"这是什么状态机"，然后按上面的模式写。**

---

### 域3：实时调试 = SWD + RTT + ITM 工具链

你调试设备时，最常问：
- 这个变量现在值是多少？
- 代码执行到哪里了？
- 为什么中断没触发？

**三大工具链**（对标 FPGA 的 ILA）：

#### 工具3.1：SWD（Serial Wire Debug）
- 2 根线（SWDIO + SWDCLK）+ GND，接 ST-Link/J-Link
- 在代码运行中设置断点、看变量、改寄存器
- **Segger Ozone**：独立 GUI，load `.elf` 直接调
- **GDB**：命令行，脚本化

#### 工具3.2：SEGGER RTT（Real-Time Transfer）
- 不用额外引脚，通过 SWD 传输数据
- **优势**：不停机、无中断损失、很快（1-10 MB/s）
- **用法**：
```c
#include "SEGGER_RTT.h"

void SEGGER_RTT_WriteString(0, "Motor speed = 200\n");
// 在 Ozone 或 RTT Viewer 中实时看输出
```

#### 工具3.3：ITM（Instrumentation Trace Macrocell）
- Cortex-M 内置，通过 SWO 单脚输出
- **用法**：
```c
#define ITM_Port8(n)   (*((volatile unsigned char *)(0xE0000000 + 4*n)))
void ITM_SendChar(int ch) {
  while (ITM_Port8(0) == 0);
  ITM_Port8(0) = ch;
}
```

**实践建议**：
1. 项目一开始配好 RTT（一次 5 分钟）
2. 关键变量用 `RTT_printf()`，不用 UART（快 100 倍）
3. 遇到卡住的 bug，用 Ozone 断点 + 寄存器检查，比加 printf 快 10 倍

---

### 域4：硬件 CI/CD = 自动化测试

cpq 指南的秘密武器：**每次 push 自动烧录到硬件，抓 UART 验证。** 这是从"手工测试"到"生产就绪"的分界线。

#### Step1：GitHub Actions 编译
```yaml
# .github/workflows/build.yml
- name: Build firmware
  run: make -C projects/blinky
```

#### Step2：vcon.io 远程烧录 + 测试
```makefile
test: update
  curl -su :$(VCON_KEY) https://dash.vcon.io/api/v3/devices/$(DEVICE_ID)/ota \
    --data-binary @firmware.bin
  curl -su :$(VCON_KEY) https://dash.vcon.io/api/v3/devices/$(DEVICE_ID)/tx?t=5 \
    | grep -q "Expected: OK" && echo "PASS" || echo "FAIL"
```

→ **一旦设置好，bug 修了就自动验证，不用手工烧板。**

---

## 五大 li-skills 融合

### li-debug：调试驱动开发循环

**铁律**：反馈循环 → 复现 → 假设 → 插桩 → 修复 → 回归。对嵌入式的应用：

```
1. 现象（反馈）：电机没有按预期启动
2. 复现：按如下步骤都能复现
3. 假设：是不是 I2C 读 ADC 失败了？
4. 插桩：RTT_printf("ADC value: %d\n", adc_val); 看实时值
5. 修复：ADC 初始化漏了使能时钟 → 加上 RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
6. 回归：验证电机现在启动了，且其他功能没破
```

→ **不会用 SWD/RTT 的工程师，调试是在黑暗中捅，效率 10 倍低。**

### li-hardware：寄存器 ↔ 硬件的桥梁

**理解层级**：
- **L1（错误）**：不知道为什么要配置这个寄存器 → AI 容易跳这步
- **L2（正确）**：知道 GPIO MODER = 1 = 输出，照搬代码
- **L3（专业）**：知道 ARM Cortex-M 的内存映射、外设总线拓扑、时钟树

→ **AI 需要 L2 以上才能自己补缺。cpq 指南就是 L2→L3 的阶梯。**

### li-code：嵌入式编码规范

**STM32 特定的坑**：
1. **volatile 关键字**：`volatile uint32_t *gpio_reg = (uint32_t *)0x40020000;`
   - 没有 volatile，编译器会"优化"掉对硬件寄存器的读
   - 结果：中断改了硬件值，软件看不到

2. **pin abstraction macros**：不要硬写 `GPIOA->MODER |= 0x0C00;`，写成
   ```c
   gpio_output(PIN('A', 5));  // 自说明 + 不出错
   ```

3. **MISRA-C 兼容**：Awesome-Embedded 指向的 MISRA-C 是汽车/医疗级标准
   - 禁止：带大小的整数没有检查、指针强制转换
   - 推荐：`uint16_t pin = 0x0005u;`（u 后缀表示 unsigned）

### li-improve：从 AI 犯过的错学

**常见 AI 错误 + 修正**：
| AI 错误 | 为什么错 | 正确做法 |
|--------|---------|---------|
| 只写 HAL 初始化，忘了 RCC 时钟 | HAL 文档没显眼说，AI 没读参考手册 | 看 STM32 datasheet 时钟树图，手动 RCC 配置 |
| `if (flag == 1)` 在中断里频繁改 flag | superloop 和中断的竞态条件 | 用 volatile + atomic 操作，或 event queue |
| `printf()` 占用大量时间 | UART 是 9600bps，115200bps 也慢 | 改成 RTT，快 100 倍 |
| 死循环等待事件（`while (!event)`） | 浪费电，CPU 不能睡眠 | 用中断 + `WFI()`，功耗 100 倍低 |
| RTOS 任务堆栈溢出无提示 | 栈溢出覆盖其他数据，表现诡异 | 用 FreeRTOS 栈检查、禁止任务无限递归 |

### li-analyze：道法术器穿透

- **道（Why）**：具身智能 = 感知→决策→控制，STM32 执行"控制"，必须实时、可靠
- **法（How）**：状态机驱动设计、SWD 调试观测、硬件 CI/CD 验证
- **术（What）**：寄存器级初始化、pin abstraction、RTT 日志、中断处理
- **器（With What）**：Ozone、RTT Viewer、vcon.io、GCC、Makefile

---

## 执行流程（遇到 STM32 任务）

### Phase 1：问"什么时候要什么"（5 分钟）
- 这个代码是初始化？控制逻辑？调试工具？
- 有实时约束吗？≤ 10ms？
- 用 HAL 还是裸机？

### Phase 2：框架选择
```
如果是初始化：→ pin abstraction 宏，分批配置
如果是控制逻辑：→ 状态机模式
如果是调试：→ RTT + Ozone
如果是生产验证：→ vcon.io CI/CD
```

### Phase 3：实现 + 验证
```
写代码 → RTT 插桩看实时值 → Ozone 断点验证逻辑 → vcon.io 自动测试
```

---

## 反模式清单（禁止 TOP5）

| # | 反模式 | 后果 | 正确做法 |
|---|--------|------|---------|
| 1 | superloop + 死等(`while (flag)`) | 丢中断、占电、无法多任务 | event-driven state machine |
| 2 | 没有 volatile，寄存器值被编译器优化掉 | 中断无效、死锁 | `volatile uint32_t *reg;` + datasheet 验证 |
| 3 | UART printf 调试，不知道代码在哪卡住 | 盲目加延迟，改不了根本 | RTT + Ozone 看实时值 |
| 4 | 忘了 RCC/时钟配置，外设无响应 | 代码看没问题，硬件就是不动 | 每个外设配置前必读时钟树，手动 RCC |
| 5 | 没有硬件测试，发货后发现问题 | 成本 10 倍高，客户流失 | vcon.io 自动烧录验证，每次 push 都跑 |

---

## 与其他 skill 的联动

| Skill | 何时调用 |
|-------|---------|
| **li-hardware** | 需要理解 FPGA 和 STM32 硬件差异时（SWD vs JTAG、clock vs PLL） |
| **li-code** | 补充嵌入式 C 编码规范（MISRA、volatile、指针安全） |
| **li-debug** | 当代码逻辑错误或硬件状态迷茫时，执行调试循环 |
| **li-improve** | 代码交付后，从 bug 日志反推 AI 的 STM32 理解缺陷 |
| **li-prompt** | 生成 STM32 prompt 时，确保触发词包含"状态机""寄存器""RTT" |

---

## 知识源头（GitHub）

- [cpq/bare-metal-programming-guide](https://github.com/cpq/bare-metal-programming-guide) (4.7k★) — 寄存器级编程 + Ozone 调试 + CI/CD
- [QuantumLeaps/modern-embedded-programming-course](https://github.com/QuantumLeaps/modern-embedded-programming-course) (1.3k★) — 状态机 + Active Object + RTOS
- [nhivp/Awesome-Embedded](https://github.com/nhivp/Awesome-Embedded) (8.7k★) — 知识导航（RTOS/调试/编码标准）
- [STMicroelectronics/STM32CubeF4](https://github.com/STMicroelectronics/STM32CubeF4) — 官方 HAL/LL 参考

---

## 触发词（确保路由）

自动触发：`STM32` `ARM Cortex-M` `嵌入式` `固件` `寄存器` `中断` `SWD` `调试` `RTT` `状态机` `裸机` `硬件工程师` `电机驱动` `传感器` `实时` `RTOS` `UART` `I2C` `SPI`

---

## 边界声明

**可写入材料**：STM32 固件编码规范、寄存器初始化模板、状态机架构、调试工具链配置
**不可写入**：某个特定企业的专利硬件细节、客户固件代码、机密协议
**尚不能声称**：保证零 bug（调试是反馈循环，不是一遍过）、完整 FPGA↔STM32 迁移指南（不同体系）

---

> **工程法则**：专业固件不是"会编程"，是"知道为什么要这样编"。这个 skill 的目标是让 AI 写代码时，一开始就往对的方向去，而不是改 5 遍才对。
