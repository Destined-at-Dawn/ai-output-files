---
name: li-webtest
description: Toolkit for interacting with and testing local web applications using Playwright. Supports verifying frontend functionality, debugging UI behavior, capturing browser screenshots, and viewing browser logs.
license: Complete terms in LICENSE.txt
---
## [LIGHTNING] 执行协议（强制 - 禁止跳过）
> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**
### [RED] 必读（执行前必须读取，不可跳过）
- 执行前**必须** `Read references/testing-strategies.md` - 不读 = 不了解核心方法论 = 产出不合格
### [YELLOW] 按需（匹配场景时必须读取）
- 场景[案例] -> **必须** `Read references/case-studies.md`
- 场景[补充] -> **必须** `Read references/supplementary.md`
### [STOP] 门禁
- Phase 执行前：确认已读取 references/testing-strategies.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）
## 理论锚点
| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
# Web Application Testing
To test local web applications, write native Python Playwright scripts.
**Helper Scripts Available**:
- `scripts/with_server.py` - Manages server lifecycle (supports multiple servers)
**Always run scripts with `--help` first** to see usage. DO NOT read the source until you try running the script first and find that a customized solution is abslutely necessary. These scripts can be very large and thus pollute your context window. They exist to be called directly as black-box scripts rather than ingested into your context window.
## Decision Tree: Choosing Your Approach
```
User task → Is it static HTML?
    ├─ Yes → Read HTML file directly to identify selectors
    │         ├─ Success → Write Playwright script using selectors
    │         └─ Fails/Incomplete → Treat as dynamic (below)
    │
    └─ No (dynamic webapp) → Is the server already running?
        ├─ No → Run: python scripts/with_server.py --help
        │        Then use the helper + write simplified Playwright script
        │
        └─ Yes → Reconnaissance-then-action:
            1. Navigate and wait for networkidle
            2. Take screenshot or inspect DOM
            3. Identify selectors from rendered state
            4. Execute actions with discovered selectors
```
## Example: Using with_server.py
To start a server, run `--help` first, then use the helper:
**Single server:**
```bash
python scripts/with_server.py --server "npm run dev" --port 5173 -- python your_automation.py
```
**Multiple servers (e.g., backend + frontend):**
```bash
python scripts/with_server.py \
  --server "cd backend && python server.py" --port 3000 \
  --server "cd frontend && npm run dev" --port 5173 \
  -- python your_automation.py
```
To create an automation script, include only Playwright logic (servers are managed automatically):
```python
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True) # Always launch chromium in headless mode
    page = browser.new_page()
    page.goto('http://localhost:5173') # Server already running and ready
    page.wait_for_load_state('networkidle') # CRITICAL: Wait for JS to execute
    # ... your automation logic
    browser.close()
```
## Reconnaissance-Then-Action Pattern
1. **Inspect rendered DOM**:
   ```python
   page.screenshot(path='/tmp/inspect.png', full_page=True)
   content = page.content()
   page.locator('button').all()
   ```
2. **Identify selectors** from inspection results
3. **Execute actions** using discovered selectors
## Common Pitfall
❌ **Don't** inspect the DOM before waiting for `networkidle` on dynamic apps
✅ **Do** wait for `page.wait_for_load_state('networkidle')` before inspection
## Best Practices
- **Use bundled scripts as black boxes** - To accomplish a task, consider whether one of the scripts available in `scripts/` can help. These scripts handle common, complex workflows reliably without cluttering the context window. Use `--help` to see usage, then invoke directly. 
- Use `sync_playwright()` for synchronous scripts
- Always close the browser when done
- Use descriptive selectors: `text=`, `role=`, CSS selectors, or IDs
- Add appropriate waits: `page.wait_for_selector()` or `page.wait_for_timeout()`
## Reference Files
- **examples/** - Examples showing common patterns:
  - `element_discovery.py` - Discovering buttons, links, and inputs on a page
  - `static_html_automation.py` - Using file:// URLs for local HTML
  - `console_logging.py` - Capturing console logs during automation
## 与 web-access 的协作指南
**li-webtest** 专注于**本地 Web 应用测试**（Playwright）。
**web-access** 专注于**联网操作和浏览器自动化**（CDP）。
### 何时使用 li-webtest
✅ **适用场景：**
- 本地开发环境测试（localhost）
- 前端功能验证和 UI 调试
- 截图对比和视觉回归测试
- 自动化表单提交和交互测试
- 控制台日志捕获和分析
- 需要 headless 浏览器的场景
❌ **不适用场景：**
- 需要登录态的外部网站
- 反爬严格的平台（小红书、微信等）
- 需要操作用户已有 Chrome tab
- 动态渲染且需登录的内容
### 何时使用 web-access
✅ **适用场景：**
- 搜索信息和网页抓取
- 社交媒体操作（小红书、微博等）
- 需要登录态的平台操作
- 批量调研和并行抓取
- 视频截帧和媒体提取
- 本地 Chrome 书签/历史检索
❌ **不适用场景：**
- 本地开发环境测试
- 需要 headless 模式的 CI/CD
- 纯 Playwright 脚本编写
### 协作示例
**场景 1：测试本地应用 + 抓取外部数据**
```
1. 用 li-webtest 测试本地前端功能
2. 用 web-access 抓取外部 API 数据
3. 合并结果进行端到端验证
```
**场景 2：开发调试 + 登录态操作**
```
1. 用 li-webtest 调试本地 UI
2. 用 web-access 登录外部平台获取配置
3. 将配置应用到本地测试环境
```
**场景 3：自动化测试 + 社交媒体发布**
```
1. 用 li-webtest 验证发布功能
2. 用 web-access 在小红书发布内容
3. 验证发布结果
```
### 快速选择参考
| 任务类型 | 首选 Skill | 原因 |
|----------|-----------|------|
| 本地 UI 测试 | li-webtest | Playwright 更稳定 |
| 外部网站抓取 | web-access | CDP 携带登录态 |
| 社交媒体操作 | web-access | 需要登录态 |
| 开发调试 | li-webtest | headless 模式 |
| 批量调研 | web-access | 并行分治 |
| CI/CD 测试 | li-webtest | 独立浏览器实例 |
| 视频截帧 | web-access | CDP 截图能力 |
### 环境变量共享
两个 skill 可共享以下环境变量：
```bash
# web-access 使用
CLAUDE_SKILL_DIR=~/.newmax/skills/web-access
CDP_PROXY_PORT=3456
# li-webtest 使用
PLAYWRIGHT_BROWSERS_PATH=~/.cache/ms-playwright
```
### 注意事项
1. **端口冲突**：web-access CDP Proxy 默认 3456 端口，确保不与其他服务冲突
2. **浏览器实例**：li-webtest 使用独立 Chromium，web-access 连接用户 Chrome
3. **登录态**：web-access 天然携带用户登录态，li-webtest 需要手动配置
4. **反爬检测**：外部网站优先用 web-access，本地应用用 li-webtest
## Case Studies
### Case 1: 登录页面功能测试
- **场景**：Web 应用登录页面自动化测试
- **方法**：reconnaissance（识别表单元素）→ action（填写提交）→ verify（检查结果）
- **结果**：发现密码重置链接失效 bug
- **教训**：先侦察再行动，不要假设 DOM 结构
### Case 2: 响应式布局测试
- **场景**：移动端适配验证
- **方法**：多 viewport 测试 → 截图对比 → 标记溢出元素
- **结果**：发现 3 个 breakpoint 问题
- **教训**：测试必须覆盖 375px/768px/1440px 三个关键宽度
### Case 3: API 端点冒烟测试
- **场景**：部署后验证 API 是否正常
- **方法**：GET/POST/PUT/DELETE 四种方法 → 状态码验证 → 响应体检查
- **结果**：发现 DELETE 端点返回 200 而非 204
- **教训**：冒烟测试覆盖所有 HTTP 方法，不只是 GET
## Anti-Patterns
| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 直接操作不侦察 | DOM 结构假设错误 | 先 reconnaissance 再 action |
| 2 | 只测 happy path | 漏掉边界条件 | 覆盖正常+异常+边界三种输入 |
| 3 | 不等页面加载完 | 元素未渲染就操作 | 等待策略（networkidle/domcontentloaded） |
| 4 | 测试数据硬编码 | 环境切换就失败 | 使用环境变量或配置文件 |
## Linked Skills
| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-debug** | 测试失败的调试 | "测试失败了""为什么报错" |
| **li-workflow** | 测试自动化集成 | "部署后自动测试" |
| **li-research** | 测试工具选型 | "用什么测试框架" |
> 更多详细内容见 references/supplementary.md
## 案例库
### 案例 1: 牛马AI 系统健康检查
- **场景**: AI 频繁出现 429 限流，需要自动化监控
- **做法**: Phase 1 工具识别（checklist>puppeteer，内部 API 不需要浏览器）→ Phase 2 数据采集（API latency/error rate/cache hit）→ Phase 3 诊断 → Phase 4 验证
- **结果**: 捕获到 3 次 API timeout，成功追踪根因
- **来源**: mutual 工作区，2026-06
### 案例 2: MemPalace Web 端登录流程测试
- **场景**: 用户反馈"登录有时候失败"，需要自动化测试
- **做法**: Playwright 录制登录流程 → 参数化（3 种登录方式） → 循环测试 10 次
- **结果**: 发现 token 过期时间不稳定（15-45 分钟随机），触发修复
- **来源**: MemPalace 项目
### 案例 3: 个人博客 Lighthouse 性能审计
- **场景**: 博客加载 > 5 秒
- **做法**: li-webtest Phase 2 自动 Lighthouse CI → 输出报告 → 识别 4 个阻塞点（图片/JS/CSS/字体）
- **结果**: 图片懒加载 + 字体 CDN 后加载 1.2 秒
- **来源**: 个人工作区
## 联动技能
| 技能 | 触发条件 | 联动方式 |
|------|---------|---------|
| li-debug | 测试发现 bug 时 | 纪律化调试 + 回归验证 |
| li-web | 前端开发时 | 测试覆盖率驱动开发 |
| li-workflow | CI/CD 集成时 | 测试作为流水线门禁 |
| li-improve | 测试质量不达标时 | 用进化引擎优化测试策略 |
> 详细内容见 references/appendix.md
## 条件下一步
| 条件 | 下一步 | 理由 |
|------|--------|------|
| 测试失败但不确定是 bug 还是测试脚本问题 | → li-debug 纪律化调试 | 先定位根因再修 |
| 需要测试多个页面/路由 | → 建 Page Object Model | 避免选择器散落在各脚本 |
| CI/CD 环境跑不通 | → li-workflow 检查环境配置 | 浏览器依赖/端口/权限 |
| 测试覆盖率不足 | → li-research 搜测试策略 | 参考行业最佳实践 |
| 跨浏览器兼容性问题 | → li-web 查 Can I Use | 确认是浏览器差异还是代码 bug |

## 反模式
| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 只测 happy path | 上线后边界场景全挂 | 测试矩阵必须包含边界值和异常输入 |
| 手动测试不记录 | 同样的 bug 反复测 | 用脚本自动化 + 结果写入日志 |
| 不等 networkidle 就操作 | 元素未渲染就点击 → flaky test | `page.wait_for_load_state('networkidle')` 必须是第一步 |
| 选择器用 xpath 而非 CSS/text | DOM 微调就全挂 | 优先用 `role=`、`text=`、CSS class，xpath 是最后手段 |
| 测试脚本不清理状态 | 测试间互相污染 | 每个测试 setUp/tearDown，或用独立 browser context |
| headless=False 跑 CI | CI 无显示器必崩 | CI 环境强制 `headless=True`，本地调试才 False |

