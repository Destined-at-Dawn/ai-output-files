# li-webtest 案例库

## 案例 1: 登录流程测试
- 场景：测试登录页面
- Playwright 脚本：fill -> click -> waitForSelector -> assert
- 失败时自动截图

## 案例 2: 响应式布局测试
- 场景：测试移动端适配
- 多 viewport 测试：375px / 768px / 1280px
- 截图对比
