## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |


## 联动技能

- **li-debug, li-hardware, li-research, li-improve, li-sync**
- 联动方式：上游skill决定何时调用本skill，本skill专注核心能力
- 联动触发条件：上游skill的Phase中明确写了调用本skill的步骤
- 联动验证：联动成功后由li-memory记录事实，li-improve记录教训



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 案例库

### 案例 1：小红书页面功能测试
**场景**：自建的小红书内容管理页面需要测试
**方法**：关键路径测试——登录 → 发布 → 编辑 → 删除 → 验证每个步骤
**结果**：发现 2 个 bug（编辑后未刷新、删除无确认弹窗）
**教训**：关键路径测试比覆盖率更重要

### 曻例 2：Arduino Web 控制面板测试
**场景**：ESP32 的 Web 控制界面，需要在手机端测试
**方法**：响应式测试——桌面 1920px / 平板 768px / 手机 375px
**结果**：发现手机端按钮重叠问题
**教训**：硬件项目的 Web 界面经常忽略移动端适配

### 案例 3：API 接口压力测试
**场景**：后端 API 需要验证并发性能
**方法**：阶梯式加压——10 → 50 → 100 → 500 并发
**结果**：200 并发时响应时间突增，定位到数据库连接池配置
**教训**：压力测试要找到拐点，不是跑满载