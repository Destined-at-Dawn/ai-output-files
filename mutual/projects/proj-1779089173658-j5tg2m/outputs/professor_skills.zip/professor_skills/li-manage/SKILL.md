---
name: li-manage
version: "1.0"
description: li系列 · 全局记忆与工作流管家，跨工作区协调
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/flow-d-startup.md` - 不读 = 不了解核心方法论 = 产出不合格
- 执行前**必须** `Read references/flow-a-post-dialogue.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[记忆统一] -> **必须** `Read references/flow-g-memory-unification.md`
- 场景[技能生态] -> **必须** `Read references/flow-e-skill-ecosystem.md`
- 场景[上下文注入] -> **必须** `Read references/flow-h-context-injection.md`
- 场景[技能健康] -> **必须** `Read references/flow-i-skill-health.md`
- 场景[决策文档] -> **必须** `Read references/flow-j-k-decision-doc.md`
- 场景[反思流程] -> **必须** `Read references/flow-c-reflection.md`
- 场景[协议流程] -> **必须** `Read references/flow-b-g-i-protocols.md`
- 场景[架构详情] -> **必须** `Read references/architecture-detail.md`
- 场景[补充] -> **必须** `Read references/supplementary.md`
- 场景[流程详情] -> **必须** `Read references/flow-details.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/flow-d-startup.md, references/flow-a-post-dialogue.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-manage — 全局记忆与工作流管家

> 版本：v2.1 | 创建：2026-06-05 | 更新：2026-06-08
> 系列：li（小黎自有工具）第 4 个
> 定位：跨工作区统一记忆 + 对话后自动记录 + 工作流反思 + 泼冷水式建议
> v2.1 更新：Progressive Disclosure 架构，主文件 ≤300 行，详细内容移入 references/
> v2.0 更新：注入 dbs-decision 四层不可变性架构（事实→规律→定格→待解）

---

## 为什么需要这个技能

**问题**：5 个工作区各有独立 memory/，长期记忆松散，没有统一的用户画像。每次新对话都要花 5-10 分钟"恢复上下文"。

**解法**：li-manage 建立一个**全局记忆中枢**——`~/.newmax/user-profile.md` + `~/.newmax/conversation-journal/`。任何工作区的任何对话都能在 30 秒内知道：这个用户是谁、在干什么、最近遇到了什么问题。

---

## 核心架构：四层不可变性体系（v2.0 — 来源：dbs-decision）

> 记忆按**不可变性**分层。详细说明见 `references/architecture-detail.md`

| 层 | 目录 | 不变性规则 | 内容 |
|----|------|-----------|------|
| 事实 | `user-profile.md` + `conversation-journal/` + `memory/` | 只追加不改写 | 用户画像、对话日志、确认数据 |
| 规律 | `patterns/` | 缓慢修正不重写 | 行为模式、AI 行为规律、跨区共性 |
| 定格 | `snapshots/` | 写完不改 | 月度状态快照、事件诊断、技能分布 |
| 待解 | `open-questions/` | 完成即清 | 开放问题、待验证假设、决策事件 |

**规律层进阶门槛**（三条满足两条才进）：3 次以上事实出现 / 能解释多个事实条目 / 对下一步有明确指导

---


## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由(System 1) vs 深度分析(System 2) | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行，详情在references/ | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的，看不到没说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次分析结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 每次迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果是一等公民，死路必须归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习比集中突击有效 | 《认知天性》 |
| T9 | 损失厌恶 | 用户更怕丢数据，所以先备份 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问"为什么"再问"怎么做" | 《第一性原理》 |
| T11 | 费曼检验 | 能用简单话解释才算真懂 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败，倒推原因 | 《超越智商》 |

## 触发条件

**自动触发**：
- 对话结束时 → 写对话日志（Flow A）
- 用户不满时 → 即时记录 + 标记痛点

**显式触发**：
- "整理记忆"/"更新画像"/"最近我在干什么" → Flow A/B
- "反思"/"工作流审查" → Flow C
- "记忆宫殿"/"语义搜索记忆" → Flow D
- "优化技能"/"哪些 skill 没用" → Flow E
- "决策"/"记下这个选择" → Flow J
- "收尾"/"整理"/"新人能上手" → Flow K

**手动调用**：`/li-manage`

---

## 流程明细

> 每个 Flow 的完整步骤说明见 `references/flow-details.md`。
> 主文件只保留上方的摘要表（触发条件 + 核心动作 + 联动 skill）。

## 联动技能

| 技能 | 联动方式 | 说明 |
|------|---------|------|
| **dbs-decision** | 架构来源 | 四层不可变性结构是设计原型 |
| **dbs-good-question** | 方法论来源 | 问题消解审查嵌入 Flow C |
| **dbs-learning** | 反馈来源 | 学习反馈流入待解层 |
| **MemPalace MCP** | 核心依赖（Flow D） | 语义搜索替代全量加载，170 token 唤醒 |
| li-local-search | 上游（数据源） | skill-usage-log.md 是 Flow E 基础 |
| li-bestskill | 下游 | Flow E 搜索外部替代品 |
| li-skillfusion | 下游 | 融合/拆分/弃用建议执行者 |
| li-devil | 内嵌 | Flow C 泼冷水复用其框架 |
| auto-evolution | 并行 | 管 skill 进化，li-manage 管记忆进化 |
| conversation-to-knowledge | 互补 | c2k 管知识提取，li-manage 管四层组织 |

---

## 生态副作用

1. 创建 `~/.newmax/user-profile.md`（事实层）
2. 创建 `~/.newmax/conversation-journal/`（事实层）
3. 创建 `~/.newmax/patterns/`（规律层）
4. 创建 `~/.newmax/snapshots/`（定格层）
5. 创建 `~/.newmax/open-questions/`（待解层）
6. 更新 `skill-routing-table.json`：添加 li-manage 路由
7. 更新 `li/SKILL.md`：注册到 li 系列

---

## 文件结构

```
li-manage/
├── SKILL.md                          <- 本文件（主入口，≤300 行）
├── references/                       <- Progressive Disclosure（按需加载）
│   ├── architecture-detail.md        <- 四层架构详解 + 部署策略
│   ├── flow-a-post-dialogue.md       <- Flow A 详细步骤 + 日志模板
│   ├── flow-b-g-i-protocols.md       <- Flow B/G/H/I 初始化与索引
│   ├── flow-c-reflection.md          <- Flow C 反思流程 + 审查模板
│   ├── flow-d-startup.md             <- Flow D 四层恢复 + MemPalace
│   ├── flow-e-skill-ecosystem.md     <- Flow E/F 技能优化 + SOP 生成
│   ├── flow-g-memory-unification.md  <- Flow G 记忆统一（已有）
│   ├── flow-h-context-injection.md   <- Flow H 上下文注入（已有）
│   ├── flow-i-skill-health.md        <- Flow I 技能健康（已有）
│   └── flow-j-k-decision-doc.md      <- Flow J/K 决策立案 + 文档洁癖
├── eval.json                         <- 技能评估断言
└── metrics/                          <- 使用指标（自动积累）
```

---

## 反模式（5 条）

1. **不读直接写**：写 user-profile.md 前不 Read 当前内容 → 覆写丢失旧数据
2. **规律层跳门槛**：1-2 次观察就写入规律层 → 噪声污染模式库
3. **快照可变**：修改已有的 snapshot 文件 → 违反"写完不改"规则
4. **泼冷水无频控**：每次对话都泼冷水 → 用户体验极差
5. **全量加载恢复**：新对话读全部 long-term.md → token 浪费，应用 MemPalace 语义搜索

---

## 边界声明

- 可声称：四层记忆架构覆盖记忆管理完整生命周期
- 仅供参考：泼冷水复用 li-devil 框架，不完全等同独立调用
- 尚不能声称：自动记录准确性需实际验证；画像更新及时性取决于对话结束检测准确率

---

## References 地图

| 文件 | 内容 | 何时加载 |
|------|------|---------|
| `architecture-detail.md` | 四层架构详解 + 对比表 + 目录结构 + 部署 + MemPalace | 理解架构时 |
| `flow-a-post-dialogue.md` | Flow A 完整步骤 + 对话日志模板 + 记录时机 | 执行对话记录时 |
| `flow-b-g-i-protocols.md` | Flow B 初始化 + G/H/I 汇总引用 | 首次使用/索引维护时 |
| `flow-c-reflection.md` | Flow C 完整流程 + 周反思模板 + 泼冷水细节 | 执行反思时 |
| `flow-d-startup.md` | Flow D 四层恢复协议 + MemPalace 集成 | 新对话恢复时 |
| `flow-e-skill-ecosystem.md` | Flow E 技能优化 + Flow F SOP 生成 + 报告模板 | 技能生态审查时 |
| `flow-g-memory-unification.md` | Flow G 记忆统一协议（已有） | 记忆索引更新时 |
| `flow-h-context-injection.md` | Flow H 全局上下文注入（已有） | 上下文注入时 |
| `flow-i-skill-health.md` | Flow I 技能健康度诊断（已有） | 技能健康检查时 |
| `flow-j-k-decision-doc.md` | Flow J 决策立案回填 + Flow K 文档洁癖审查 | 决策记录/文档整理时 |

### Flow L — Knowledge Structuring (Static Infrastructure)
> Full 5-step protocol (Phase 0-4): see `references/knowledge-structuring.md`
> **Triggers**: "知识结构化", "知识图谱", "EvoMap"

## Case Studies

### Case 1: 四层不可变记忆架构
- **场景**：memory 文件混乱，长期/短期/临时记忆混在一起
- **方法**：四层架构（long-term.md → daily.md → session-checkpoint → tmp）+ 不可变规则
- **结果**：记忆检索效率提升 3 倍
- **教训**：记忆必须分层，每层有明确的写入/过期规则

> More cases in references/case-studies.md

## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 案例库

### 案例 1：skill 命名不一致导致路由断裂
**场景**：self-improving → li-improve 重命名后，98 个 SKILL.md 仍引用旧名
**方法**：全量 grep → 替换 → 验证零残留（2369 处替换，506 文件）
**结果**：所有交叉引用修复，路由系统恢复正常
**教训**：重命名 = 全生态替换，不能只改路由表

### 案例 2：workflow-inbox 5 个候选积灰 14 天
**场景**：5/28 写入的 5 个工作流改进候选，6/10 仍未处理
**方法**：检查原因 → "每周清理"机制本身坏了（没人执行）
**结果**：在 li-infra Flow D 加入自动提醒机制
**教训**：SOP 如果没有自动触发机制 = 不存在

### 案例 3：第三方仓库被误改
**场景**：GitHub 下载的 4 个仓库的 CLAUDE.md 被注入了路由激活段
**方法**：立即回滚 + 标记只读 + 修改 li-sync 扫描逻辑排除第三方
**结果**：4 个仓库恢复原状
**教训**：扫描范围必须区分"用户工作区"和"第三方仓库"