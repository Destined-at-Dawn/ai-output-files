# 全局用户画像字段定义

> 文件位置：`~/.newmax/user-profile.md`
> 维护者：li-manage（唯一写入者）
> 读取者：所有工作区的 AI（只读）

---

## 字段规范

### 第一区：身份卡（稳定，月级更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| name | string | 小黎（李兰源） | 永不 |
| university | string | 上海电力大学 | 永不 |
| year | string | 大一 | 年级 |
| major | string | IC/EE | 永不 |
| gpa | string | 3.9/4.0 | 学期末 |
| internship | string | 威泊机器人研发 | 变动时 |
| directions | list | FPGA/具身智能/考研 | 季度 |
| target_schools | list | 上交/东南电气 | 季度 |

### 第二区：当前焦点（动态，周级更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| weekly_focus | string | 本周重点描述 | 每周一 |
| active_projects | list | 项目ID+一句话状态 | 每次对话 |
| open_problems | list | 待解决的问题 | 即时 |
| blocked_tasks | list | 被阻塞的任务 | 即时 |

### 第三区：工作偏好（半稳定，观察级更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| info_density | enum | high/medium/low | 观察2+次 |
| communication_style | string | 直接/不讨好/学长视角 | 稳定 |
| format_preference | list | 列表>表格/全角标点 | 稳定 |
| tech_depth | string | 学生视角硬核笔记 | 稳定 |
| output_length | string | 信息密度高，移动端友好 | 稳定 |
| confirmation_style | enum | 关键点确认/不确认 | 观察 |

### 第四区：技能地图（动态，次级更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| total_installed | number | 198 | 安装/卸载时 |
| top_used | list | [{skill, count, last_used}] | 每次对话 |
| rarely_used_but_important | list | [li-devil, deep-research] | 月级 |
| pain_skills | list | [{skill, issue}] | 即时 |
| missing_coverage | list | [电气工程专用skill] | 周级 |

### 第五区：痛点档案（动态，即时更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| cross_workspace_memory | string | 碎片化 | 状态 |
| ai_completion_verification | string | 声称完成但未落盘 | 状态 |
| skill_routing_accuracy | string | 路由不准导致手动指定 | 状态 |
| iteration_quality | string | 迭代无实质差异 | 状态 |
| new_pains | list | [{date, description, source}] | 即时 |

### 第六区：认知武器库（稳定，月级更新）

| 字段 | 类型 | 示例 | 更新频率 |
|------|------|------|---------|
| total_books | number | 63 | 新增书时 |
| index_version | string | v54.0 | 索引更新时 |
| frequently_cited | list | [010, 046, 025, 011] | 月级 |
| underutilized | list | [047, 062, 041] | 月级 |
| learning_style | string | 认知科学驱动/实操优先 | 稳定 |

---

## 更新规则

1. **增量更新**：每次只更新变化的字段，不覆写整个文件
2. **冲突解决**：新观察与已有记录矛盾时，标记 `[待确认]` 并在下次对话中询问用户
3. **过期检查**：超过 30 天未更新的字段标记 `[需刷新]`
4. **隐私保护**：不记录密码、token、密钥等敏感信息
