# 跨工作区数据索引

> 用途：li-manage 快速定位各工作区的记忆和产出文件
> 更新方式：每次对话后自动检查

---

## 工作区记忆文件索引

### mutual（管理/优化区）

| 文件类型 | 路径 | 最后更新 |
|---------|------|---------|
| 长期记忆 | `E:\ai产出文件\牛马\mutual\mutual\memory\long-term.md` | 按需 |
| 每日记忆 | `E:\ai产出文件\牛马\mutual\mutual\memory\{date}.md` | 每日 |
| 技能使用日志 | `E:\ai产出文件\牛马\mutual\mutual\memory\skill-usage-log.md` | 每次调用 |
| 调研画像 | `E:\ai产出文件\牛马\mutual\mutual\memory\research-profile.md` | 调研后 |
| 进化日历 | `E:\ai产出文件\牛马\mutual\mutual\self-evolution\evolution-calendar.md` | 进化时 |
| 运行时快照 | `E:\ai产出文件\牛马\mutual\mutual\runtime-snapshot.md` | 启动时 |
| 会话检查点 | `E:\ai产出文件\牛马\mutual\mutual\.claude\session-checkpoint.md` | 压缩时 |
| 项目文档 | `E:\ai产出文件\牛马\mutual\mutual\project.md` | 里程碑 |

### 个人

| 文件类型 | 路径 |
|---------|------|
| 长期记忆 | `E:\ai产出文件\牛马\个人\个人\memory\long-term.md` |
| 每日记忆 | `E:\ai产出文件\牛马\个人\个人\memory\{date}.md` |
| 进化日历 | `E:\ai产出文件\牛马\个人\个人\self-evolution\evolution-calendar.md` |

### 创作

| 文件类型 | 路径 |
|---------|------|
| 长期记忆 | `E:\ai产出文件\牛马\创作\创作\memory\long-term.md` |
| 每日记忆 | `E:\ai产出文件\牛马\创作\创作\memory\{date}.md` |
| 进化日历 | `E:\ai产出文件\牛马\创作\创作\self-evolution\evolution-calendar.md` |

### 求职

| 文件类型 | 路径 |
|---------|------|
| 长期记忆 | `E:\ai产出文件\牛马\求职\求职\memory\long-term.md` |
| 每日记忆 | `E:\ai产出文件\牛马\求职\求职\memory\{date}.md` |
| 进化日历 | `E:\ai产出文件\牛马\求职\求职\self-evolution\evolution-calendar.md` |

### 竞赛

| 文件类型 | 路径 |
|---------|------|
| 长期记忆 | `E:\ai产出文件\牛马\竞赛\竞赛\memory\long-term.md` |
| 每日记忆 | `E:\ai产出文件\牛马\竞赛\竞赛\memory\{date}.md` |
| 进化日历 | `E:\ai产出文件\牛马\竞赛\竞赛\self-evolution\evolution-calendar.md` |

---

## 共享资源索引

| 资源 | 路径 | 说明 |
|------|------|------|
| 工作区注册表 | `E:\ai产出文件\牛马\知识中枢\00-注册表\工作区注册表.md` | 5工作区元数据 |
| 跨工作区快速参考 | `E:\ai产出文件\牛马\知识中枢\00-注册表\跨工作区快速参考.md` | 跨区导航 |
| 共享规则 | `E:\ai产出文件\牛马\知识中枢\02-共享规则\` | R13-R17 |
| 百大认知书籍 | `E:\ai产出文件\牛马\个人\个人\百大认知书籍\` | 63本索引 |
| 全局用户画像 | `~/.newmax/user-profile.md` | li-manage 维护 |
| 对话日志 | `~/.newmax/conversation-journal/` | li-manage 维护 |

---

## 同步状态检查

每次 li-manage 执行时，检查以下同步项：

- [ ] 各工作区 long-term.md 是否有新增内容需要汇总到全局画像？
- [ ] 各工作区 memory/{recent}.md 是否有新的痛点/偏好信号？
- [ ] 路由表是否有新增/变更需要记录？
- [ ] 进化日历是否有到期任务？
