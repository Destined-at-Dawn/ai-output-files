- **方法**：DAG 依赖图 + SKILL.md 标准化 + EvoMap 追踪
- **结果**：SOP 从散落变成可检索的知识库
- **教训**：知识不结构化 = 不可检索 = 不存在


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 记忆不分层 | 长期/临时混在一起 | 四层不可变架构 |
| 2 | write_project_file 覆写 memory | 丢失历史 | 先 Read 再 Edit 追加 |
| 3 | 不检查路由就弃用 skill | 可能路由没配对 | Flow E 先查路由再决定 |
| 4 | 画像注入超过 200 token | 占用上下文窗口 | static + dynamic 分层，≤200 token |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-memory** | 事实提取和检索 | "提取事实""记忆检索" |
| **li-sync** | 跨工作区记忆同步 | "同步记忆" |
| **li-improve** | 教训沉淀和规则更新 | "记录教训" |
| **li-infra** | 基础设施配置 | "修改 CLAUDE.md" |
| **li-skillcreate** | 新 skill 创建管理 | "创建新 skill" |
