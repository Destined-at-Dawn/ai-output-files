# Flow H：全局上下文注入

> 本文件是 li-manage SKILL.md 的 Progressive Disclosure 组件。
> **何时加载**：当新对话启动需要恢复上下文时（自动触发，或用户说"我上次在干什么"/"恢复上下文"）。

---

## 目标

让任何新对话在 30 秒内知道"用户是谁、在干什么、最近遇到什么问题"。

## 执行流程

```
1. 读取 ~/.newmax/memory-index.md（统一索引，1 个文件代替 7 个）
2. 读取 ~/.newmax/user-profile.md（全局画像）
3. 读取当前工作区的 project.md（项目状态）
4. 生成「上下文恢复摘要」注入对话开头
```

## 注入格式

```
📋 上下文恢复（li-manage）
- 用户：[姓名]，[身份]，[当前焦点]
- 本周重点：[从对话日志提取]
- 最近教训：[最近 1-2 条，如有]
- 进行中任务：[从 project.md 提取]
```

## 依赖

- Flow G（记忆统一协议）：提供 `~/.newmax/memory-index.md`
- Flow B（全局画像初始化）：提供 `~/.newmax/user-profile.md`
- Flow A（对话后自动记录）：提供最近对话日志

## 边界

- 上下文恢复摘要**不替代** CLAUDE.md 启动序列（Step 0-6），它是补充
- 如果 memory-index.md 不存在 → 先执行 Flow B 初始化，再执行 Flow G 建索引
