# Flow B / G / H / I：初始化与索引协议 — 详细说明

> 本文件是 SKILL.md 的参考文档。主文件只保留触发条件和一句话摘要。
> Flow G/H/I 已有独立参考文件（flow-g/h/i-*.md），本文件补充 Flow B 和汇总。

---

## Flow B：全局画像初始化（首次使用）

```
1. 扫描所有 5 个工作区的 memory/ 目录
2. 读取所有 memory/long-term.md
3. 读取所有 memory/{recent 7 days}.md
4. 读取所有工作区的 project.md
5. 读取 skill-routing-table.json 和 skill-usage-log.md
6. 综合提取 → 写入 ~/.newmax/user-profile.md
7. 交叉验证：提取的信息是否一致？矛盾点标记
```

---

## Flow G：记忆统一协议

**做什么**：维护 `~/.newmax/memory-index.md`，把 7 处存储位置的教训统一到一个索引文件。
**何时加载**：用户说"整理记忆"/"教训在哪里"/"记忆碎片化"，或需要更新统一索引时。
**参考文件**：`references/flow-g-memory-unification.md`（完整定义）

---

## Flow H：全局上下文注入

**做什么**：新对话启动时，30 秒内恢复"用户是谁、在干什么、最近遇到什么问题"。
**何时加载**：新对话启动自动触发，或用户说"恢复上下文"/"我上次在干什么"。
**依赖**：Flow G（统一索引）+ Flow B（全局画像）。
**参考文件**：`references/flow-h-context-injection.md`（完整定义）

---

## Flow I：技能健康度诊断

**做什么**：五维健康检查（活跃度/路由准确度/重复度/维护度/用户满意度），标记不健康的 skill。
**何时加载**：用户说"技能健康"/"哪些技能有问题"，或每周六与 Flow E 联动。
**联动**：诊断数据输入 Flow E（技能生态优化），重叠/弃用建议交给 li-skillfusion 执行。
**参考文件**：`references/flow-i-skill-health.md`（完整定义）
