# 流程明细（按需加载）

> 主文件只保留 Flow 摘要表。完整步骤说明在本文件。

## 执行流程骨架

### Flow A：对话后自动记录 + 四层分流

**触发**：每次对话结束 | **参考**：`references/flow-a-post-dialogue.md`

```
1. 检测对话结束信号
2. 提取：用户需求 / 产出文件 / 情绪信号 / 关键决策
3. 写入对话日志（事实层）
4. 四层分流：事实→追加 | 规律→暂定/确认 | 定格→新建快照 | 待解→新建条目
5. 更新 user-profile.md 的"当前焦点"和"痛点档案"
6. 可复用教训 → 候选写入 memory/long-term.md
7. 新 skill 使用记录 → 更新 skill-usage-log.md
```

### Flow B：全局画像初始化（首次使用）

**触发**：首次使用 | **参考**：`references/flow-b-g-i-protocols.md`

```
1. 扫描 5 个工作区 memory/ + project.md + 路由表 + 使用日志
2. 综合提取 → 写入 ~/.newmax/user-profile.md
3. 交叉验证一致性，标记矛盾点
```

### Flow C：工作流反思 + 问题消解审查

**触发**：每周五 / 连续 3 次不满 / 用户要求 | **参考**：`references/flow-c-reflection.md`

```
1. 读取近 7 天对话日志，统计分析
2. 问题消解审查（dbs-good-question）：问题本身是否正确？
3. 泼冷水审查：盲目自信？声称完成未验证？重复犯错？
4. 四层健康检查（事实/规律/定格/待解）
5. 生成杠铃式建议（保守端 + 激进端）
```

### Flow D：新对话启动辅助（四层恢复协议）

**触发**：新对话自动 | **参考**：`references/flow-d-startup.md`

```
1. 读取事实层 → 30 秒知道"用户是谁"
2. 读取定格层 → 知道"上次是什么状态"
3. 读取待解层 → 知道"什么没解决"
4. MemPalace 语义搜索规律层（170 token 唤醒，降级读 patterns/ 最近 10 条）
5. 生成四层恢复摘要注入对话
```

### Flow E：技能生态优化

**触发**：每周六 / 连续 3 次漏调 / 用户要求 | **参考**：`references/flow-e-skill-ecosystem.md`

```
1. 提取沉睡技能清单 / 漏调模式 / SOP 候选
2. li-bestskill 搜索外部替代品
3. 泼冷水审查（精要主义 + 认知负荷 + 探索-利用）
4. 杠铃式建议：弃用/修复/创建 SOP vs 融合/安装新 skill
```

### Flow F：技能调用 SOP 生成

**触发**：SOP 候选检测时 | **参考**：`references/flow-e-skill-ecosystem.md`（附在 Flow E 末尾）

```
1. 收集历史记录 → 分析措辞变体和上下文
2. 写入 SOP + 更新路由表 + 更新索引
```

### Flow G：记忆统一协议

**触发**："整理记忆"/"教训在哪里" | **参考**：`references/flow-g-memory-unification.md`

维护 `~/.newmax/memory-index.md`，统一 7 处存储位置的教训。

### Flow H：全局上下文注入

**触发**：新对话自动 | **参考**：`references/flow-h-context-injection.md`

30 秒恢复"用户是谁、在干什么、最近遇到什么问题"。依赖 Flow G + B。

### Flow I：技能健康度诊断

**触发**："技能健康"/每周六联动 Flow E | **参考**：`references/flow-i-skill-health.md`

五维健康检查（活跃度/路由准确度/重复度/维护度/用户满意度）。

### Flow J：决策立案与结果回填

**触发**：重大决策 / "记下这个选择" | **参考**：`references/flow-j-k-decision-doc.md`

```
立案：open-questions/ 新建决策事件文件（背景/判断/观察指标）
回填：结果确认 → 事实层 + 规律层 → 标记已完成
关键纪律：不编造预期结果，不把后见之明倒灌回原文
```

### Flow K：文档记忆洁癖审查

**触发**：里程碑完成 / "收尾"/"整理" | **参考**：`references/flow-j-k-decision-doc.md`

```
Step 0: 尺寸体检（CLAUDE.md > 300 行？单条 memory > 100 行？）
Step 1: 盘点现状
Step 2: 变更影响矩阵
Step 3: 实际修改（减优于加，合并优于追加，绝对时间）
Step 4: 自检（净涨幅 ≤ 30 行，无相对时间遗留）
Step 5: 输出变更摘要
```

---

