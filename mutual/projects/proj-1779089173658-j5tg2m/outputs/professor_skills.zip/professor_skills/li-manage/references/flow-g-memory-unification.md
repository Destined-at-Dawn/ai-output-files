# Flow G：记忆统一协议

> 本文件是 li-manage SKILL.md 的 Progressive Disclosure 组件。
> **何时加载**：当需要统一索引 7 处存储位置时（用户说"整理记忆"/"我最近的教训"/"记忆在哪里"）。

---

## 根因

教训分散在 7 个存储位置，每次新对话都"失忆"。本 Flow 建立统一的记忆索引层。

## 7 处存储位置现状

| # | 位置 | 用途 | 维护者 |
|---|------|------|--------|
| 1 | `.learnings/LEARNINGS.md` | li-improve 结构化日志 | li-improve |
| 2 | `~/li-improve/memory.md` | HOT tier 记忆 | li-improve |
| 3 | `self-evolution/lessons.md` | 教训总库 | CLAUDE.md F6 |
| 4 | `经验库/做得差的/` + `做得好的/` | 模块级经验库 | li-improve v3.3 |
| 5 | `memory/{日期}.md` | 每日记忆 | CLAUDE.md F3 |
| 6 | `MEMORY.md` | 长期记忆主索引 | longmemory skill |
| 7 | `negative-results.md` | 负结果日志 | li-improve v3.3 |

## 统一索引机制

li-manage 维护一个**全局记忆索引**文件：

```
~/.newmax/memory-index.md
```

内容结构：
```markdown
# 全局记忆索引（li-manage 维护）

## 最近 7 天教训（从各存储位置汇总）
| 日期 | 编号 | 来源 | 摘要 | 存储位置 |

## 高频教训 Top 10（>=2 次同类触发）
| 教训 | 次数 | 最近触发 | 升级状态 |

## 用户偏好快照（从 MEMORY.md + user-profile.md 汇总）
- 信息密度：[高/中/低]
- 文风：[描述]
- 禁忌：[列表]

## 当前焦点（从最近 3 天对话日志提取）
- 正在做什么：[一句话]
- 遇到什么问题：[一句话]
- 下一步：[一句话]
```

## 更新频率

- 每次对话结束时更新"最近 7 天教训"和"当前焦点"
- 每周五更新"高频教训 Top 10"和"用户偏好快照"

## 新对话启动时

AI 只需读 `~/.newmax/memory-index.md` 一个文件，30 秒内恢复完整上下文。不需要再去 7 个地方搜索。
