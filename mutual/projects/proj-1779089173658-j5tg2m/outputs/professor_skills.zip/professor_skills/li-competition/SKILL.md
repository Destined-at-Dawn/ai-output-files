---
name: li-competition
description: 竞赛项目管理通用技能（适用于任何竞赛）
version: 2.0.0
auto_trigger: true
triggers:
  - 竞赛
  - 比赛
  - 项目管理
  - 里程碑
  - 进度跟踪
  - 任务分解
  - SOP
  - 实操
  - 理论
---


> **必读（执行前必须 Read）**：`references/skill-linkage.md` — li- 系列联动规则。不读 = 跳过联动 = 产出不完整。500 万 token 上下文中本文件可能被压缩，但 references/ 不会被压缩。


# li-competition - 竞赛项目管理通用技能

> **通用方法论**：适用于任何竞赛项目管理
> **项目级配置**：具体竞赛信息、数据集、训练结果存放在项目目录的 `skills/competition-local.md`
> 版本：v2.0 | 更新：2026-06-13

---

## 项目级配置（必读）

**本 Skill 提供通用项目管理方法论，具体数据存放在项目目录。**

执行竞赛任务前，必须先读取项目级配置文件：
```
{项目目录}/skills/competition-local.md
```

项目级配置包含：
- 竞赛信息（名称、日期、地点、报名截止）
- 数据资产清单（具体数据集路径、规模、状态）
- 训练结果（mAP50、mAP50-95、权重路径）
- 项目复盘记录（历史事故、教训）

**铁律**：通用流程从本文件获取，具体数据从项目级配置获取。两者缺一不可。

---

## 通用项目管理流程

### 1. 项目启动阶段
- 明确竞赛目标和要求
- 分解任务到可执行单元
- 建立里程碑和时间线
- 识别风险和依赖项

### 2. 执行阶段
- 按 SOP 执行各单元
- 定期检查进度
- 记录问题和解决方案
- 及时调整计划

### 3. 收尾阶段
- 整理文档和代码
- 准备交付物
- 复盘总结教训
- 归档项目资产

## 竞赛实操6单元 SOP
1. 硬件连接与配置
2. 开发环境搭建
3. 数据准备（标注+格式转换）
4. 模型训练（YOLO12n）
5. 模型编译与可执行文件生成（ONNX+量化）
6. 模型部署与集成

## 理论考试4模块
- 电力设施巡检
- 数字图像处理
- 计算机视觉技术
- 人工智能算法

## 论文方法速查（2026最新研究）
| 方法 | 核心创新 | 性能 | 可借鉴程度 |
|------|---------|------|-----------|
| TRS-YOLO | GhostConv+Triplet Attention+C2f-EMSCP | 97.0% mAP, 1.74M参数 | 高（轻量化直接可用） |
| IDD-DETR | Patch Diffusion去雾+SIIM+FCM | 95.8% Precision, 39.3M参数 | 中（两阶段pipeline复杂） |
| Drone-DETR | ESDNet+P2浅层特征+动态竞争学习 | 53.9% mAP50 (VisDrone) | 高（小目标检测策略） |
| YOLOv11n-SSA | Star Operation+NWD Loss | 91.9% mAP50 | 高（NWD损失函数） |
| RSP-YOLOv11n | RCSOSA+SEA注意力+P2检测头 | 参数-30%, FLOPs-31% | 高（轻量化+小目标） |
| 数据增强YOLOv12 | 旋转+平移合成增强 | mAP提升30-34% | 极高（立即可用） |
| LID-YOLO | 轻量化设计 | 参数-50% | 中（边缘部署参考） |

## 快速可集成改进（优先级排序）
1. **数据增强增强**（立即）：Mosaic + MixUp + Copy-Paste + 旋转平移合成
2. **类别权重平衡**（立即）：defect 类权重加大 cls_pw=[1.0, 5.0]
3. **NWD损失函数**（第一阶段）：小目标检测提升显著
4. **CSConv替换Conv**（第一阶段）：轻量化，参数减少30%
5. **P2检测头**（第二阶段）：提升小目标检测能力
6. **AIFI-Inception模块**（第二阶段）：改进特征融合

## 关联文件
- 项目计划：project.md
- 边缘部署方案：outputs/边缘部署实施方案.md
- 报名指南：outputs/竞赛报名操作指南.md
- D-Day清单：outputs/竞赛D-Day检查清单.md
- 理论笔记：outputs/理论笔记/
- 实操SOP：outputs/实操SOP/
- 论文：Yolo算法比赛/outputs/论文/
- 数据集研究汇总：outputs/数据集优化与论文方法研究汇总.md
- 论文技术调研：outputs/论文技术调研_2026.md
- 论文方法技术简报：outputs/论文方法技术简报.md

## 使用方式
`mcp__skill-handler__Skill skill: "li-competition"`
