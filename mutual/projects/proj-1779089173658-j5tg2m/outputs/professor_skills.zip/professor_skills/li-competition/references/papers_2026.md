# 2026年电力AI检测论文索引

## 10篇核心论文

| ID | 论文 | 平台 | 核心技术 | 结果 |
|----|------|------|---------|------|
| P1 | APF-YOLOV8 (PMC 2026) | YOLOv8 | SPD-Conv+SimAM+C2f-ODConv | mAP50=94.5% |
| P2 | NanoDet改进 (Symmetry 2026) | NanoDet-M | C2f-Ghost-v2+SEAM+ECA | mAP50=93.07% |
| P3 | STF-YOLOv8 (IOP 2026) | YOLOv8 | SPD-Conv+BiFormer+SIOU | 精度提升显著 |
| P4 | DFE-YOLOv5 (Drones 2026) | YOLOv5 | 弱监督SMM-CAM | mAP@.5=.75=56.7% |
| P5 | EASA-YOLOv8 (BIBE 2026) | YOLOv8n | BiFormer+ContextGuided | 小目标+5% |
| P6 | CSMB-YOLOv8 (Sci Reports 2026) | YOLOv8 | 联邦学习+知识蒸馏 | 分布式训练 |
| P7 | UAV-DETR (JESA 2026) | DETR | DWT下采样+SPDConv | mAP95=53.7% |
| P8 | INSPIRED (V2V 2026) | 综述 | Transformer+few-shot | 综合比较 |
| P9 | YOLO-AP (IEEE T-STE 2026) | YOLO-AP | LKConv+SEv2+BiFPN | mAP@.5:.95=53.3% |
| P10 | 8类细粒度 (PMC 2026) | 多模型 | 细粒度分类+Grad-CAM | DenseNet201:93.1% |

## GitHub仓库
- P1: https://github.com/ywfwydd/APF-YOLOV8 (⭐19)
- P2: https://github.com/jluo-xi-an/NanoDet_C2fGhost_SEAM_ECA_IMproved_ (⭐29)
- P8: https://github.com/pmusig/INSPIRED-Dataset (⭐10)

## 数据集链接
- MPID: https://zenodo.org/records/14604384
- CPLID: https://github.com/InsulatorData/InsulatorDataSet
- InsPLAD-det: https://data.mendeley.com/datasets/58v4jct8t8/3
