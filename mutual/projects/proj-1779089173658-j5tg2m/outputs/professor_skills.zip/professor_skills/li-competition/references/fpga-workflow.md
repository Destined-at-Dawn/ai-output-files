# FPGA 开发完整流程

> 来源：li-hardware v3.0 + 竞赛区 1844 个文件实战经验
> 用途：li-competition Phase 1 逆向拆解的技术基础

## 五阶段模型

```
调研选型 → 架构设计 → RTL 编码 → 综合实现 → 系统验证
   M1         M2         M3         M4         M5
```

---

## M1：调研选型（-21 天）

### 目标
- 确定芯片型号
- 确定开发工具
- 确定参考设计
- 确定外设清单

### 关键动作

#### 1.1 芯片选型

**选型维度**：
- 逻辑资源（LUT/FF/BRAM/DSP）
- 速度等级（-1/-2/-3）
- 封装（QFP/BGA/CSP）
- 价格和供货
- 开发板支持

**常用系列**：

| 系列 | 适用场景 | 典型型号 |
|------|---------|---------|
| Xilinx Artix-7 | 中低端，性价比高 | XC7A35T, XC7A100T |
| Xilinx Kintex-7 | 高端，高速接口 | XC7K325T, XC7K410T |
| Intel Cyclone V | 中低端，Nios II 软核 | 5CEBA4F17C7N |
| Intel Arria 10 | 高端，高速收发器 | 10AX048H2F34E2SG |
| Lattice iCE40 | 超低功耗，手持设备 | iCE40HX8K |
| Gowin LittleBee | 国产，低成本 | GW1NR-9 |

**选型决策树**：
```
需要高速收发器（>10Gbps）？
  ├─ 是 → Xilinx Kintex-7 / Intel Arria 10
  └─ 否 → 逻辑资源 > 100K LUT？
             ├─ 是 → Xilinx Artix-7 100T / Intel Cyclone V
             └─ 否 → 预算 < 100 元？
                      ├─ 是 → Gowin LittleBee / Lattice iCE40
                      └─ 否 → Xilinx Artix-7 35T（竞赛首选）
```

#### 1.2 开发工具

| 工具 | 厂商 | 特点 |
|------|------|------|
| Vivado | Xilinx | 综合+实现+仿真+调试一体化 |
| Quartus Prime | Intel | 综合+实现+SignalTap 调试 |
| Gowin IDE | Gowin | 国产工具，轻量级 |
| ModelSim | Mentor | 专业仿真工具 |
| Verilator | 开源 | 快速仿真，适合大型设计 |

**工具选择建议**：
- 学生竞赛：Vivado（资料多，社区活跃）
- 工业项目：Quartus Prime（Intel FPGA 生态）
- 成本敏感：Gowin IDE（国产 FPGA）

#### 1.3 参考设计

**来源**：
- 官方开发板例程（最快上手）
- GitHub 开源项目（学习架构）
- 论坛帖子（踩坑经验）
- 竞赛优秀作品（实战参考）

**评估标准**：
- 代码质量（注释、命名、结构）
- 文档完整性（README、设计文档）
- 可移植性（是否绑定特定硬件）
- 社区活跃度（issues、PRs）

#### 1.4 外设清单

**常用外设**：
- LCD 显示屏（SPI/并行接口）
- 摄像头（DVP/MIPI CSI）
- 以太网（RGMII/SGMII）
- DDR3/DDR4 存储器
- ADC/DAC（SPI/I2C）
- 传感器（I2C/SPI/UART）

**采购注意**：
- 提前 2 周下单（防缺货）
- 买 2 个（防损坏）
- 确认电压匹配（3.3V/5V）
- 确认接口标准（SPI/I2C/UART）

---

## M2：架构设计（-14 天）

### 目标
- 定义顶层接口
- 划分功能模块
- 设计时钟域
- 规划资源使用

### 关键动作

#### 2.1 顶层接口设计

**接口规范**：
```verilog
module top (
    // 时钟和复位
    input  wire        clk,        // 系统时钟
    input  wire        rst_n,      // 异步复位（低有效）
    
    // 输入接口
    input  wire [7:0]  data_in,    // 数据输入
    input  wire        valid_in,   // 输入有效
    
    // 输出接口
    output wire [7:0]  data_out,   // 数据输出
    output wire        valid_out   // 输出有效
);
```

**设计原则**：
- 接口清晰（输入/输出/双向分离）
- 信号命名规范（前缀：i_/o_/io_）
- 位宽明确（不使用 `[0:7]`，使用 `[7:0]`）
- 复位策略统一（同步/异步、高/低有效）

#### 2.2 功能模块划分

**三层架构**：
```
顶层 (top)
  ├─ 控制层 (ctrl) — 状态机、配置、调度
  ├─ 数据层 (data) — 数据通路、FIFO、缓冲
  └─ 接口层 (if) — 外设驱动、协议解析
```

**划分原则**：
- 单一职责（每个模块只做一件事）
- 接口最小化（减少模块间连线）
- 可测试性（每个模块可独立仿真）

#### 2.3 时钟域设计

**单时钟域**（最简单）：
```
clk_in → PLL → clk_sys → 所有模块
```

**多时钟域**（常见）：
```
clk_50m → PLL → clk_100m → 高速模块
         → clk_25m  → 低速模块（LCD/VGA）
         → clk_125m → 以太网
```

**跨时钟域处理**：
- 单比特信号：两级触发器同步
- 多比特信号：异步 FIFO / 握手协议
- 命令信号：脉冲同步器

#### 2.4 资源规划

**资源估算**：
- LUT：功能复杂度 × 1.5（余量）
- FF：LUT × 0.8
- BRAM：数据缓冲需求
- DSP：乘法/累加操作

**示例**：
LCD 驱动 + I2C 通信 + 简单图像处理
- LUT：~5000（XC7A35T 有 5200）
- FF：~3000
- BRAM：~10（用于行缓冲）
- DSP：~5（用于像素计算）

---

## M3：RTL 编码（-7 天）

### 目标
- 编写 RTL 代码
- 编写仿真 testbench
- 通过模块级仿真
- 通过集成仿真

### 关键动作

#### 3.1 编码规范

**命名规范**：
```verilog
// 模块名：小写 + 下划线
module lcd_driver (
    // 端口名：小写 + 下划线
    input  wire        clk,
    input  wire        rst_n,
    output wire [15:0] lcd_data
);

// 内部信号：小写 + 下划线
reg  [15:0] pixel_cnt;
wire        line_done;

// 参数：大写 + 下划线
parameter H_SYNC  = 16'd96;
parameter H_BACK  = 16'd48;
```

**编码风格**：
- 一个文件一个模块
- 端口声明按功能分组（时钟、控制、数据）
- always 块按功能划分（组合/时序分离）
- 注释清晰（模块功能、信号含义、设计意图）

#### 3.2 状态机设计

**三段式状态机**（推荐）：
```verilog
// 状态定义
localparam S_IDLE  = 3'd0;
localparam S_READ  = 3'd1;
localparam S_WRITE = 3'd2;
localparam S_DONE  = 3'd3;

// 状态寄存器
reg [2:0] state, next_state;

// 状态转移（时序逻辑）
always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        state <= S_IDLE;
    else
        state <= next_state;
end

// 次态逻辑（组合逻辑）
always @(*) begin
    case (state)
        S_IDLE: next_state = start ? S_READ : S_IDLE;
        S_READ: next_state = data_ready ? S_WRITE : S_READ;
        S_WRITE: next_state = write_done ? S_DONE : S_WRITE;
        S_DONE: next_state = S_IDLE;
        default: next_state = S_IDLE;
    endcase
end

// 输出逻辑（时序逻辑）
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        data_out <= 16'd0;
        valid_out <= 1'b0;
    end else begin
        case (next_state)
            S_WRITE: begin
                data_out <= data_in;
                valid_out <= 1'b1;
            end
            default: begin
                valid_out <= 1'b0;
            end
        endcase
    end
end
```

#### 3.3 仿真 Testbench

**Testbench 结构**：
```verilog
module tb_lcd_driver;

// 时钟生成
reg clk;
initial clk = 0;
always #5 clk = ~clk; // 100MHz

// 复位生成
reg rst_n;
initial begin
    rst_n = 0;
    #100;
    rst_n = 1;
end

// DUT 例化
lcd_driver u_dut (
    .clk      (clk),
    .rst_n    (rst_n),
    .lcd_data (lcd_data)
);

// 测试激励
initial begin
    // 测试用例 1：正常工作
    @(posedge rst_n);
    #100;
    
    // 测试用例 2：边界条件
    // ...
    
    // 测试用例 3：错误注入
    // ...
    
    #1000;
    $finish;
end

// 波形输出
initial begin
    $dumpfile("tb_lcd_driver.vcd");
    $dumpvars(0, tb_lcd_driver);
end

endmodule
```

**仿真策略**：
- 模块级仿真：每个模块单独仿真
- 集成仿真：所有模块组合仿真
- 系统仿真：包含外设模型

---

## M4：综合实现（-3 天）

### 目标
- 综合通过（0 ERROR）
- 布局布线通过
- 时序收敛（WNS > 0）
- 生成 bitstream

### 关键动作

#### 4.1 综合设置

**Vivado 综合命令**：
```tcl
# 创建项目
create_project -part xc7a35tcpg236-1 -force

# 添加源文件
add_files [glob *.v]
add_files -fileset sim_1 [glob tb_*.v]

# 综合
launch_runs synth_1 -jobs 4
wait_on_run synth_1
```

**综合报告检查**：
- 时序报告：WNS（Worst Negative Slack）> 0
- 资源报告：LUT/FF/BRAM/DSP 使用率 < 80%
- 警告报告：0 Critical Warning

#### 4.2 时序约束

**约束文件（XDC）**：
```tcl
# 时钟约束
create_clock -period 10.000 -name clk [get_ports clk]

# 输入延迟
set_input_delay -clock clk -max 5.0 [get_ports data_in]
set_input_delay -clock clk -min 1.0 [get_ports data_in]

# 输出延迟
set_output_delay -clock clk -max 5.0 [get_ports lcd_data]
set_output_delay -clock clk -min 1.0 [get_ports lcd_data]

# 伪路径
set_false_path -from [get_clocks clk_50m] -to [get_clocks clk_125m]
```

**时序收敛技巧**：
- 预留 30% 时序余量
- 关键路径用流水线
- 避免过深的组合逻辑
- 使用寄存器平衡

#### 4.3 布局布线

**布局布线命令**：
```tcl
# 布局布线
launch_runs impl_1 -jobs 4
wait_on_run impl_1

# 生成 bitstream
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1
```

**实现报告检查**：
- 时序报告：WNS > 0（所有时钟域）
- 资源报告：无过载
- DRC 报告：0 Violation

---

## M5：系统验证（上板测试）

### 目标
- 上板功能验证
- 边界条件测试
- 长时间稳定性测试
- 文档完成

### 关键动作

#### 5.1 上板测试

**测试流程**：
1. 下载 bitstream
2. 验证基本功能
3. 测试边界条件
4. 长时间运行测试

**测试清单**：
- [ ] 基本功能：正常工作
- [ ] 边界条件：最大/最小输入
- [ ] 异常处理：错误输入、断电恢复
- [ ] 性能测试：最大频率、吞吐量
- [ ] 稳定性测试：连续运行 24 小时

#### 5.2 问题定位

**调试工具**：
- ILA（Integrated Logic Analyzer）：在线抓取信号
- VIO（Virtual I/O）：在线控制信号
- SignalTap（Intel）：类似 ILA

**调试流程**：
1. 复现问题
2. 添加 ILA 探针
3. 抓取波形
4. 分析根因
5. 修复代码
6. 重新验证

#### 5.3 文档完成

**必备文档**：
- 设计文档（架构、接口、时序）
- 测试报告（测试用例、结果、问题）
- 用户手册（功能说明、使用方法）
- 资源报告（LUT/FF/BRAM/DSP 使用率）

---

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 不做 M1 直接写代码 | 选型错误，后期返工 | 先调研选型 |
| 不做 M2 直接写模块 | 架构混乱，集成困难 | 先设计架构 |
| 不做仿真直接综合 | 综合报错不知原因 | 先仿真通过 |
| 不做时序约束 | 时序不收敛 | 先写约束文件 |
| 不做上板测试 | 功能不对 | 先上板验证 |

---

## 案例库

### 案例 1：XC7A35T LCD 驱动

**时间线**：
- M1（3 天）：选型 XC7A35T + LCD 屏 + I2C 模块
- M2（3 天）：架构设计（三层：top/lcd_ctrl/i2c_master）
- M3（7 天）：RTL 编码 + 仿真
- M4（3 天）：综合 + 时序收敛
- M5（3 天）：上板测试 + 文档

**关键教训**：
- M1 阶段确认 LCD 时序参数（很重要）
- M3 阶段先做模块级仿真，再做集成仿真
- M4 阶段预留时序余量（实际 WNS = +0.5ns）

### 案例 2：RoboMaster 嵌入式控制

**时间线**：
- M1（2 天）：选型 STM32 + CAN 模块 + PID 算法
- M2（2 天）：架构设计（CAN 通信 + PID 控制 + 急停逻辑）
- M3（5 天）：C 代码编写 + 仿真
- M4（2 天）：编译 + 烧录
- M5（3 天）：上板调试 + 参数整定

**关键教训**：
- PID 调参用 Ziegler-Nichols 法（先 P 后 I 最后 D）
- CAN 通信先做环回测试
- 急停逻辑独立于主循环（中断优先级最高）

---

## 工具速查

### Vivado 常用命令

```tcl
# 创建项目
create_project -part xc7a35tcpg236-1 -force

# 综合
launch_runs synth_1 -jobs 4
wait_on_run synth_1

# 实现
launch_runs impl_1 -jobs 4
wait_on_run impl_1

# 生成 bitstream
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1

# 下载
open_hw_manager
connect_hw_server
open_hw_target
set_property PROGRAM.FILE {top.bit} [current_hw_device]
program_hw_devices [current_hw_device]
```

### ModelSim 常用命令

```tcl
# 编译
vlog *.v
vlog tb_*.v

# 仿真
vsim -voptargs="+acc" work.tb_top

# 波形
add wave -r /*
run 1000ns
```

---

## 延伸阅读

- li-hardware：硬件设计的技术支撑
- li-hardware/references/vivado-tcl-guide.md：Vivado TCL 脚本指南
- li-hardware/references/embedded-patterns.md：嵌入式设计模式
- li-hardware/references/vendor-code-porting.md：厂商代码移植指南
