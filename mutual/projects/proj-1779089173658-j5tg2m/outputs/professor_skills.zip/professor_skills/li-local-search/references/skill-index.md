# 本地 Skill 索引（按功能域分组）

> 本文件由 li-local-search 主文件路由至此。
> 更新频率：每次有新 skill 安装时更新。
> 最后更新：2026-06-22 | 总计 128 个活跃 skill | li- 系列 52 个

---

## li 系列工具（52 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| li | li 系列路由器入口 | li系列/小黎工具/li工具箱 |
| li-analyze | 道法术器深度分析 | 分析/拆解/道法术器/框架分析 |
| li-asset | 数字资产归档 | 数字资产/归档/素材管理 |
| li-autoreply | 自动回复 | 自动回复/自动应答 |
| li-bestskill | 技能雷达（外部发现） | 新技能/推荐skill/技能市场/外部技能 |
| li-code | 代码助手 | 写代码/代码审查/代码优化 |
| li-competition | 竞赛助手 | 竞赛/电赛/比赛/集创赛 |
| li-consultant | 咨询顾问 | 咨询/顾问/辅导 |
| li-data | 数据处理 | 数据/数据处理/数据清洗 |
| li-dbs | 商业工具箱 | 商业/诊断/dbs/决策系统 |
| li-debug | 调试助手 | debug/排错/报错/异常 |
| li-design | 设计助手 | 设计/UI/视觉设计 |
| li-devil | 决策质疑器 | 质疑/泼冷水/预验尸/魔鬼代言人 |
| li-diagnose | 熵增诊断 | 诊断/系统问题/熵增/排查 |
| li-embedded | 嵌入式开发 | 嵌入式/单片机/MCU/STM32 |
| li-hardware | 硬件设计 | FPGA/Verilog/硬件/RTL/电路 |
| li-image | 图片处理 | 图片处理/修图/图片分析 |
| li-improve | 进化引擎 | 教训/改进/进化/自学习 |
| li-industry | 行业研究 | 行业/产业/赛道/市场 |
| li-infra | 基础设施 | 基础设施/系统/部署/运维 |
| li-intent | 意图理解引擎 | 意图/理解/路由/SOP匹配 |
| li-manage | 全局记忆管家 | 整理记忆/更新画像/反思/记忆宫殿/收尾 |
| li-memory | 记忆系统 | 记忆/记录/沉淀/事实提取 |
| li-mindcoach | 心力跃迁教练 | 焦虑/拖延/卡住/想放弃/纠结/撑不住 |
| li-office | Office处理 | Office/Word/Excel/PPT办公 |
| li-package | 打包发布 | 打包/发布/分发/zip |
| li-persona-qa | 人设问答 | 人设/角色/QA/问答 |
| li-personal | 个人助手 | 个人/生活/日常 |
| li-plan | 任务规划 | 规划/计划/安排/任务拆解 |
| li-prompt | 提示词工程 | 提示词/prompt/优化提示词 |
| li-research | 深度调研 | 调研/研究/深度分析/竞品分析 |
| li-script | 脚本库管家 | 脚本/脚本库/复用脚本 |
| li-skillcreate | 技能锻造器 | 创建技能/造技能/新技能 |
| li-skillfusion | 技能融合器 | 融合skill/拆分skill/定制skill |
| li-skills-mgmt | 技能管理 | 技能管理/技能审核/技能清单 |
| li-storyboard | 分镜脚本 | 分镜/脚本/故事板 |
| li-study | 学习引擎 | 学习/理解/搞懂/学习计划 |
| li-sync | 跨区同步 | 同步规则/一改全改/跨工作区/整理 |
| li-transcript | 逐字稿清洗 | 逐字稿/会议录音/转录/OCR |
| li-triage | 分流器 | 分流/分诊/优先级/任务分派 |
| li-video | 视频处理 | 视频/剪辑/视频分析 |
| li-visual | 视觉设计 | 视觉/配色/排版/设计系统 |
| li-web | 网页开发 | 网页/前端/网站开发 |
| li-webstyle | 网页风格 | 网页风格/设计语言/CSS |
| li-webtest | 网页测试 | 测试/网页测试/自动化测试 |
| li-wechat | 公众号运营 | 公众号/微信/推文 |
| li-wechat-distiller | 微信蒸馏 | 微信蒸馏/聊天分析/文风蒸馏 |
| li-workflow | 工作流 | 工作流/流程/自动化 |
| li-workspace | 工作区管理 | 工作区/空间/workspace |
| li-xhs | 小红书运营 | 小红书/帖子/标题/种草 |
| li-zhongshu | 中枢知识库 | 知识中枢/中枢/知识库 |

---

## baoyu 系列（16 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| baoyu-article-illustrator | 文章配图 | 配图/插图 |
| baoyu-comic | 知识漫画 | 漫画/知识漫画 |
| baoyu-compress-image | 图片压缩 | 压缩图片/转WebP |
| baoyu-cover-image | 文章封面图 | 封面图/文章封面 |
| baoyu-danger-gemini-web | Gemini网页版 | Gemini网页 |
| baoyu-danger-x-to-markdown | X推文转Markdown | 推文转MD |
| baoyu-format-markdown | Markdown格式化 | 格式化/排版 |
| baoyu-image-gen | AI图片生成 | 画图/生成图片/AI作画 |
| baoyu-infographic | 信息图 | 信息图/infographic |
| baoyu-markdown-to-html | Markdown转HTML | 转HTML/微信排版 |
| baoyu-post-to-wechat | 发布公众号 | 发布公众号/推送 |
| baoyu-post-to-x | 发布到X/Twitter | 发推/发X |
| baoyu-slide-deck | PPT图片 | PPT/幻灯片图片 |
| baoyu-url-to-markdown | URL转Markdown | 保存网页/URL转MD |
| baoyu-xhs-images | 小红书配图 | 小红书图片/XHS图片 |

---

## ljg 系列（7 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| ljg-dialectic | 辩证对话 | 辩证/对话/正反 |
| ljg-echo | 回声写作 | 回声/echo/共鸣 |
| ljg-new | 新建skill | ljg新建 |
| ljg-sourcer | 溯源 | 溯源/来源/source |
| ljg-wujue | 五觉写作 | 五觉/感官/具象 |
| ljg-xm | 写作 | 写作/xm |
| ljg-za | 杂项 | ljg杂项 |

---

## 内容创作与写作（12 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| blog-post-writer | 公众号文章生成 | 写文章/公众号/稿件 |
| chinese-natural-voice-revision | 降AI味文风修订 | AI味/文风/润色/自然 |
| doc-coauthoring | 文档协作 | 协作/共写/多人编辑 |
| internal-comms | 内部沟通 | 内部/沟通/团队 |
| jincheng-pyq (via li) | 朋友圈文案 | 朋友圈/pyq |
| nature-skills | 自然写作 | 自然/文风/写作 |
| personal-info-discovery | 个人信息发现 | 个人信息/背景/简介 |
| session-audit | 会话审计 | 审计/会话/回顾 |
| theme-factory | 主题工厂 | 主题/模板/风格 |
| writing-style-dna (via li) | 文风DNA分析 | 文风/DNA/风格分析 |
| writing-agent-prompt (via li) | 写作Agent提示词 | 写作智能体/Agent提示词 |

---

## 小红书与社媒（3 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| crc-offer-post | CRC offer帖子 | offer帖/CRC帖子 |
| xhs相关 | 由 li-xhs 统一覆盖 | 小红书/帖子/种草 |

---

## 图片与视觉（8 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| canvas-design | 视觉设计 | 海报/设计/艺术 |
| design-extract (via baoyu) | 截图提取设计规范 | 设计提取/逆向设计 |
| gemini-image | Gemini图片生成 | Gemini画图 |
| imagemagick-conversion | 图片格式转换 | 图片转换/ImageMagick |
| algorithmic-art | 算法艺术 | 算法/生成艺术 |
| dot-skill | 点阵图 | 点阵/dot |

---

## 文档与文件处理（10 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| docx | Word文档处理 | Word/docx/文档 |
| pdf | PDF全功能处理 | PDF/合并/拆分/水印 |
| pptx | PPT文件处理 | PPT/slides/演示文稿 |
| xlsx | Excel处理 | 表格/excel/数据 |
| ppocrv5 | OCR文字识别 | OCR/识别文字/提取文字 |
| feishu-doc-reader | 飞书文档 | 飞书/feishu |
| html-to-notes | HTML转笔记 | HTML转笔记/网页笔记 |
| anything-to-notebooklm | NotebookLM上传 | NotebookLM/播客 |
| study-review-pdf | 学习复习PDF | 复习/学习PDF |

---

## 视频与音频（4 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| ffmpeg-usage | FFmpeg音视频处理 | 格式转换/压缩/拼接 |
| remotion-video | React编程视频 | 编程视频/Remotion |
| slack-gif-creator | GIF生成 | GIF/动图 |

---

## 网页与前端（5 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| frontend-design | 前端界面设计 | 前端/网站/landing page |
| web-artifacts-builder | Web Artifacts | Artifacts/网页组件 |
| webapp-testing | Web应用测试 | Web测试/自动化测试 |
| brand-guidelines | 品牌规范 | Anthropic/品牌色 |

---

## 学习与教育（4 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| three-tier-memory | 三层记忆 | 三层记忆/记忆系统 |
| rtl-fpga-lessons | RTL/FPGA课程 | FPGA课程/RTL学习 |
| power-ai-competition | 电力AI竞赛 | 电力/AI竞赛 |

---

## AI 方法与工具（3 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| newmax-help | Newmax帮助 | 帮助/help/Newmax用法 |
| niuma-help | 牛马帮助 | 牛马帮助/系统帮助 |

---

## 项目管理与工作流（6 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| jc-plan | 任务管家 | 今天做什么/记任务/安排 |
| long-term-plan | 长期计划 | 长期计划/任务拆解 |
| project-init | 项目初始化 | 新建项目/项目模板 |
| workflow-automator | 自动化工作流 | CI/CD/自动化/定时 |
| daily-review | 每日回顾 | 每日回顾/工作复盘 |
| deep-review | 深度工作分析 | 深度分析/工作模式 |

---

## 系统与运维（2 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| github-publisher | GitHub发布 | 开源/发布GitHub |
| mcp-builder | MCP Server开发 | MCP/开发MCP |

---

## 硬件与竞赛（4 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| competition-fpga | FPGA竞赛 | FPGA竞赛/电赛FPGA |
| competition-yolo | YOLO竞赛 | YOLO/目标检测/竞赛 |
| fpga | FPGA通用 | FPGA/Verilog/数字电路 |
| systemverilog | SystemVerilog | SystemVerilog/SV/UVM |

---

## 商业与运营（1 个）

| Skill | 功能 | 触发词 |
|-------|------|--------|
| claude-skills-zh-cn | Claude技能中文化 | Claude技能/中文skill |

---

## 统计摘要

| 功能域 | 数量 | 占比 |
|--------|------|------|
| li- 系列 | 52 | 40.6% |
| baoyu 系列 | 15 | 11.7% |
| ljg 系列 | 7 | 5.5% |
| 内容创作 | 12 | 9.4% |
| 文档处理 | 10 | 7.8% |
| 图片视觉 | 8 | 6.3% |
| 网页前端 | 5 | 3.9% |
| 硬件竞赛 | 4 | 3.1% |
| 学习教育 | 3 | 2.3% |
| 项目管理 | 6 | 4.7% |
| 其他 | 6 | 4.7% |
| **总计** | **128** | **100%** |
