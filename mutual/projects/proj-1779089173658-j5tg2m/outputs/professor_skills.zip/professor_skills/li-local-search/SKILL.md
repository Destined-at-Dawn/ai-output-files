---
name: li-local-search
version: "1.3"
description: |
  底层路由基础设施——每次任务自动参与路由决策。
  扫描 128 个本地已安装 skill，支持品牌系列路由、中文语义匹配、场景推荐。
  只搜索本地已安装 skill，外部发现由 li-bestskill 负责。
  定位：skill-auto-activation Layer 2 的执行体，不是普通 skill。
  Triggers: local-skill-search/installed-skills/find-local-skill
  Series: li #5
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/search-algorithms.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[数据采集] -> **必须** `Read references/data-collection.md`
- 场景[技能索引] -> **必须** `Read references/skill-index.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/search-algorithms.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）



## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由(System 1) vs 深度分析(System 2) | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行，详情在references/ | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的，看不到没说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次分析结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 每次迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果是一等公民，死路必须归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习比集中突击有效 | 《认知天性》 |
| T9 | 损失厌恶 | 用户更怕丢数据，所以先备份 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问"为什么"再问"怎么做" | 《第一性原理》 |
| T11 | 费曼检验 | 能用简单话解释才算真懂 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败，倒推原因 | 《超越智商》 |


# li-local-search

> v1.3 | 2026-06-22 | li series #5
> Positioning: 底层路由基础设施，精确导航 128 个本地已安装 skill
> 核心升级：从"用户问有什么 skill 才触发"→"每次任务自动参与路由决策"

## Iron Laws

1. **Local First**: always search local 128 first, no result -> recommend li-bestskill
2. **Chinese Friendly**: match Chinese keywords directly
3. **Brand Routing First**: brand prefix -> navigate directly
4. **Verify Before Recommend**: only recommend skills with real SKILL.md
5. **Log Every Call**: append to `~/.newmax/skill-usage-log.md`
6. **Pattern Detection**: same instruction 3x without SOP -> trigger suggestion

## 底层 Layer 定位（v1.3 核心升级）

> **本 skill 不是"用户问有什么 skill 才触发"的普通 skill。**
> 它是 skill-auto-activation 的 Layer 2 执行体——每次任务都应该参与路由决策。

**自动触发规则**：
- skill-routing-table.json（Layer 0）未命中时 → 自动走 li-local-search 做语义匹配
- 用户说的是需求而非技能名 → li-local-search 帮 AI 找到正确的 skill
- 探索性任务 → li-local-search 确保不会"原生裸跑"

**与路由表的关系**：
- 路由表的显式触发词（"有什么技能""查找skill"）= 用户主动问，直接调用
- 路由表未命中 → li-local-search 自动参与 = AI 内部决策，用户不感知

---

## Two-Layer Discovery

### Layer 1: Brand Series Routing (fastest path)

| User says | Route to | Description |
|-----------|----------|-------------|
| dbs/business/dontbesilent | `dbs` | Business toolbox (21 sub-skills) |
| li/xiaoli-tools/li-series | `li` | li toolbox entry (52 sub-skills) |
| baoyu/images/cover | baoyu-* | Image generation (15 sub-skills) |
| jc/clarify/tutorial | jc-* | Thinking tools |
| khazix/wechat-long-article | khazix-writer | Deep writing |
| crc/offer | crc-* | CRC business |
| vercel/deploy | vercel-* | Vercel ecosystem |
| dg/slides | dg-* | HTML demos |

### Layer 2: Local Semantic Search

Layer 1 miss -> scan SKILL.md names and descriptions for intent matching.

**Full skill index**: -> `references/skill-index.md` (230+ skills grouped by domain)

### Layer 3: Data Collection & Pattern Detection

-> `references/data-collection.md` (auto-record / daily summary / monthly analysis / SOP candidate detection)

## Workflow

1. **Understand** (3s) -> extract core intent
2. **Brand Route** (Layer 1) -> hit? navigate directly
3. **Semantic Search** (Layer 2) -> match skills -> recommend 1-3
4. **Log Call** (Layer 3) -> append to usage log
5. **No Result** -> recommend li-bestskill external / li-skillcreate build / native capability

## Output Format

- **Found**: `Found! You need **{skill-name}**: {description}. Trigger: say "{trigger}"`
- **Brand Series**: `You mentioned **{brand}** series, {N} tools: ...`
- **No Result**: `No match in 128 local skills. Options: 1.li-bestskill search external 2.li-skillcreate build one 3.native capability`

## Quick Navigation

| User says | Recommend |
|-----------|-----------|
| draw an image | baoyu-image-gen |
| write an article | blog-post-writer / khazix-writer |
| translate | deepl |
| this PDF | pdf |
| make a PPT | pptx / baoyu-slide-deck |
| search something | step-search |
| analyze this | dao-fa-shu-qi / data-analysis |
| learn xxx | interactive-learning |
| storage full | storage-analyzer |
| organize/tidy | li-sync / session-summary |

## Anti-patterns

1. Scan 128 skills one by one instead of brand routing first
2. Recommend non-existent/deprecated skills (must ls verify first)
3. Forget to log call to skill-usage-log.md
4. Use this skill for external search (should use li-bestskill)
5. Not update index table (new skill installed -> update references/skill-index.md)

## Collaboration

| Skill | Trigger | Method |
|-------|---------|--------|
| li-bestskill | Local no result | Recommend external search |
| li-skillcreate | Local+external no result | Recommend build one |
| li-manage | Sleepy skills/SOP candidates | Data flows from Layer 3 to li-manage Flow E |
| li-intent | 意图理解引擎 | SOP驱动智能路由 | Phase 0-4 | 0.9 | 自动触发 |


## Case Studies

### Case 1: 找"微信聊天分析" skill
- **场景**：用户说"分析一下微信聊天记录"
- **过程**：Layer 1 品牌路由命中 li- 系列 → 但无直接匹配 → Layer 2 grep "微信" → 找到 wechat-analysis
- **教训**：Layer 1 不中时必须走 Layer 2，不能直接说"没有"

### Case 2: 找"费曼检验"流程
- **场景**：用户说"用费曼技巧检验我的理解"
- **过程**：grep "费曼" → 找到 ai-reading-deep（已弃用）→ 检查 DEPRECATED.md → 路由到 li-analyze
- **教训**：弃用 skill 的知识已融入新 skill，要检查 DEPRECATED 链

### Case 3: 路由表冲突导致错误触发
- **场景**：用户说"优化技能"，同时触发 li-manage 和 li-skillfusion
- **过程**：查路由表优先级 → li-manage priority=5 > li-skillfusion priority=3
- **教训**：同义触发词冲突时，高优先级 skill 胜出


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 只走 Layer 1 不走 Layer 2 | 品牌路由没命中就放弃 | Layer 1 不中 → 自动降级 Layer 2 |
| 2 | grep 全文件系统 | 太慢且结果杂乱 | 先限定目录（~/.newmax/skills/）再 grep |
| 3 | 不检查 DEPRECATED.md | 旧 skill 被当成活跃的 | 命中后先检查是否有 DEPRECATED |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li** | 主路由器的降级路径 | 路由表无匹配时走 li-local-search |
| **li-manage** | 技能生命周期查询 | "哪些 skill 没用""沉睡技能" |
| **li-skillcreate** | 创建前查重 | "有没有类似 skill" |

## 联动技能

- **li-manage, li-improve, li-research, li-sync**
- 联动方式：上游skill决定何时调用本skill，本skill专注核心能力
- 联动触发条件：上游skill的Phase中明确写了调用本skill的步骤
- 联动验证：联动成功后由li-memory记录事实，li-improve记录教训


## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 案例库

### 案例 1：找"百大认知书籍"路径
**场景**：需要定位 62 本认知科学书籍的存储路径
**方法**：本地索引匹配"百大认知"→ 返回 `E:\ai产出文件\牛马\个人\个人\百大认知书籍\`
**结果**：3 秒定位，vs 手动搜索 5 分钟
**教训**：高频访问路径必须有本地索引

### 案例 2：跨工作区找 SOP 文件
**场景**：需要找所有工作区的"硬件设计"SOP
**方法**：递归扫描 SOPs/ 目录 + 文件名匹配
**结果**：找到 4 个工作区的硬件 SOP，为 li-hardware 升级提供素材
**教训**：索引不能只覆盖顶层目录，深层嵌套也要

### 案例 3：找"简历修改"项目目录
**场景**：需要定位简历修改项目的 outputs/ 目录
**方法**：匹配"简历"+"projects" → 返回 proj-1777554288697-9e2i8z
**结果**：精确找到项目目录和所有产出文件
**教训**：项目目录命名要有语义（不是只有 proj-ID）

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 搜索范围只覆盖顶层目录 | 深层嵌套的项目目录被漏掉 | 递归扫描所有子目录 |
| 索引不更新 | 新建的 skill/SOP 找不到 | 每次创建后更新索引 |
| 搜索结果不排序 | 最相关的结果淹没在噪声中 | 按相关度 + 修改时间排序 |
| 只搜文件名不搜内容 | 文件名不含关键词但内容相关的文件被漏掉 | 文件名 + 内容双搜索 |
| 搜索结果太多不筛选 | 100+ 结果 = 没有结果 | 限制 Top 10 + 高亮最相关 |

## 联动技能

- **li-manage** — 搜索结果写入 skill-usage-log.md
- **li-bestskill** — 本地没找到时触发外部搜索
- **li-infra** — 读取工作区索引缩小搜索范围
- **li-sync** — 搜索索引跨工作区同步
- **li-memory** — 搜索历史记录，避免重复搜索