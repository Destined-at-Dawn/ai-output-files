---
name: li-intent
version: "2.0"
description: "SOP-driven intent understanding engine. Phase 0 reads workspace SOP indexes to map user intent to skill chains."
triggers: ["分析", "写", "搜索", "帮我", "优化", "创建", "整理", "总结", "调研", "设计"]
---

# li-intent — SOP 驱动意图引擎

> **核心理念**：用户说的每句话背后都有一个意图，每个意图对应一条已验证的 SOP，每条 SOP 定义了一条 skill 调用链。AI 不需要猜"该调什么"，读 SOP 就知道。

## 理论锚点

| 编号 | 理论 | 来源 | 在本 skill 的应用 |
|------|------|------|-------------------|
| T1 | 意图分类学 | 哈佛谈判项目 | 7 种意图类型对应 7 种处理策略 |
| T2 | 认知负荷理论 | Sweller (1988) | 用户不必说清每个步骤，系统自动填充 |
| T3 | 模式匹配 | Kahneman 快思慢想 | IF/ELSE 路由 = System 1 快速匹配 |
| T4 | 脚本理论 | Schank & Abelson | SOP = 场景脚本，skill chain = 脚本步骤 |
| T5 | 元认知 | Flavell (1979) | 自学习框架 = 监控+评估+调整 |
| T6 | 情境认知 | Lave & Wenger | 知识存在于实践情境中，不在抽象规则里 |
| T7 | 近端发展区 | Vygotsky | SOP 链式调用 = 脚手架 |
| T8 | 产出效应 | Slamecka & Graf | 每次执行 SOP 都强化路径 |
| T9 | 分布式认知 | Hutchins | 多 skill 协作 = 分布式问题解决 |
| T10 | 选择架构 | Thaler & Sunstein | 意图路由 = 降低用户决策成本 |
| T11 | 预测编码 | Clark (2013) | 系统根据历史模式预测用户意图 |
| T12 | 复利沉淀 | 习惯心理学 | 每次成功匹配都强化路由置信度 |


## 设计哲学

> **核心原则：用户说的是意图，不是技能名。路由是 AI 的责任，不是用户的。**

本 skill 不替代 skill-routing-table.json 的关键词匹配（那是 System 1 快速通道），而是在关键词匹配**失败或冲突**时介入（System 2 深度通道）。

### 三条铁律

1. **历史经验优先于重新设计** — 有 SOP 用 SOP，有记忆用记忆，没有才设计新流程
2. **意图理解是手段不是目的** — 匹配到意图后必须立即执行 SOP skill 链，不输出"我理解了你要做什么"
3. **自学习必须落到文件** — 每次匹配成功/失败必须写入 SOP 候选 + golden_rules，不能只在上下文里记住

### 与其他 skill 的分工

- **skill-routing-table.json**（关键词层）："公众号" → baoyu-url-to-markdown。快速、确定、但只认关键词
- **li-intent**（意图层）："帮我分析这篇文章" + URL → 读 SOP总索引 → 匹配"内容分析"意图 → 调 baoyu-url → li-analyze → li-memory。慢但全面
- **触发顺序**：先走 skill-routing-table.json → 命中则直接执行 → 未命中或命中多个 → 唤起 li-intent

### 外部研究

| 项目 | Stars | 学到什么 |
|------|-------|---------|
| AGENTS.md (Linux Foundation) | 60K+ | 指令预算 150-200 条，超出部分按需加载 |
| Anthropic Skills Guide | 官方 | Project Instructions = 全局约束，Skills = 按需能力 |
| Contextual AI | 博客 | RAG + 记忆 + skills 三层架构 = 本 skill 的设计骨架 |

## 核心流程

### Phase 0: 意图识别

收到用户消息后：
1. **扫描关键词** → 匹配 skill-routing-table.json 触发词
2. **如果命中 ≥2 个 skill** → 读当前工作区 SOP总索引 的"消息路由规则"
3. **按 IF/ELSE 链匹配** → 确定意图类别
4. **如果意图模糊** → 读 memory/long-term.md 的"用户偏好记录"

### Phase 1: SOP 查询

意图确定后：
1. 读当前工作区 `SOPs/SOP总索引.md`
2. 找到对应的 SOP 编号
3. 读取该 SOP 的完整流程
4. 提取 skill 调用链

### Phase 2: Skill 链执行

按 SOP 定义的顺序执行：
1. 每个 skill 完成后记录执行日志
2. 如果某 skill 失败 → 按 SOP 的"异常处理"分支执行
3. 所有 skill 完成后 → 进入 Phase 3

### Phase 3: 自学习收尾

按 SOP总索引 的"自学习框架"：
1. 采集用户反馈（"好"/"不好"/无反馈）
2. 1 次 → 记录到 skill-usage-log.md
3. 2 次同类 → 标记为候选模式
4. 3 次同类 → 升级为 SOP 或 golden_rule
5. 写入 memory/{today}.md

## 意图→SOP→Skill 映射表

> 来源：5 个工作区 SOP总索引 的真实路由规则

### 创作区（14 个意图类别，v2.5）

| # | 意图类别 | 匹配规则 | SOP | Skill 链 |
|---|---------|---------|-----|---------|
| 1 | 内容创作 | 写/做/创作+文章/小红书/公众号 | SOP-01~03 | li-analyze → li-transcript → li-writing |
| 2 | 内容分析 | 分析/拆解/看看+链接/文章 | SOP-04 | baoyu-url-to-markdown → li-analyze → li-memory |
| 3 | 学习研究 | 学/理解/深入+概念/主题 | SOP-05~06 | li-research → li-devil → li-memory |
| 4 | 项目管理 | 进度/规划/排期 | SOP-07 | li-plan → li-manage |
| 5 | 多模态内容 | 图/视频/配图 | SOP-08~09 | li-image → li-design → li-video |
| 6 | 数据分析 | 数据/统计/可视化 | SOP-10 | li-data → li-analyze |
| 7 | 自动化 | 自动/批量/定时 | SOP-11 | li-workflow → li-infra |
| 8 | 调试排查 | 问题/报错/失败 | SOP-12 | li-debug → li-diagnose |
| 9 | 优化迭代 | 优化/改进/更好 | SOP-13 | li-improve → li-devil → li-research |
| 10 | 呈现展示 | PPT/汇报/演示 | SOP-14 | li-pptx → li-design → li-office |
| 11 | 代码开发 | 写代码/实现/开发 | SOP-15 | li-frontend → li-hardware → li-debug |
| 12 | 习惯追踪 | 打卡/习惯/坚持 | SOP-16 | li-personal → li-memory |
| 13 | 知识管理 | 整理/归档/索引 | SOP-17 | li-manage → li-sync → li-infra |
| 14 | 技能管理 | 创建/融合/弃用skill | SOP-18 | li-skillcreate → li-skillfusion → li-manage |

### 优先级链（高优先级覆盖低）

| 条件 | 结果 |
|------|------|
| "投入不足" + 内容/方向 | → 被**方向/目标变化**接管 → li-devil 预验尸 |
| "搜索" + ≥2 平台 | → 被**多源搜索**接管 → li-research |
| "迭代" + 同一目标 ≥2 轮 | → 被**优化/迭代**接管 → li-improve |

### 竞赛区意图（FPGA + RoboMaster）

| 意图 | Skill 链 | 铁律 |
|------|---------|------|
| FPGA 开发 | li-hardware → li-debug → li-sync | 修改前必 checkpoint，不读规范不动手 |
| 嵌入式调试 | li-hardware → li-triage | 先 CRC 校验再查逻辑 |
| 一把过交付 | li-hardware → li-infra | RTL + DOCX + ZIP + 清理 |
| 竞赛管理 | li-competition → li-plan | 里程碑 + 风险矩阵 |

### 求职区意图

| 意图 | Skill 链 | 铁律 |
|------|---------|------|
| 简历优化 | li-resume → li-devil | 5 维工程语言检查 |
| 面试准备 | li-research → li-study | 费曼检验 |
| 求职管理 | li-plan → li-memory | 周报复盘 |

### 学习区意图

| 意图 | Skill 链 | 铁律 |
|------|---------|------|
| 课程学习 | li-study → li-memory | 概念→类比→简化→教人 |
| 考试准备 | li-study → li-plan | 知识图谱→间隔复习 |
| 作业 | li-study → li-debug | 先诊断知识缺口 |

## 条件下一步

| 场景 | 下一步 |
|------|--------|
| 意图命中 1 个 skill | 直接调用，不读 SOP |
| 意图命中 ≥2 个 skill | 读 SOP总索引 优先级链 |
| 意图不命中任何 skill | 读 memory/long-term.md 看历史 |
| SOP 不覆盖该意图 | 用原生能力处理，记录到 workflow-inbox |
| 用户纠正意图 | 更新 skill-usage-log.md，3 次升级 SOP |
| 链式调用中间 skill 失败 | 按 SOP 异常分支，或跳过继续 |

## 联动技能

| Skill | 联动方式 |
|-------|---------|
| li-research | 意图="调研/搜索" 时调用 |
| li-analyze | 意图="分析/拆解/道法术器" 时调用 |
| li-improve | 意图="优化/迭代" 或自学习收尾时调用 |
| li-manage | 意图="管理/整理/归档" 时调用 |
| li-memory | 每次任务完成后记忆沉淀 |
| li-devil | 意图="决策/选择" 且风险高时调用 |
| li-sync | 跨工作区操作时调用 |

## 反模式

| # | 反模式 | 后果 |
|---|--------|------|
| 1 | 跳过 SOP 直接猜意图 | 50% 命中率 → 用户体验差 |
| 2 | 不读 SOP总索引 就执行 | 丢失优先级链和异常分支 |
| 3 | 所有意图都走同一 skill | skill 过载，输出模板化 |
| 4 | 不记录执行结果 | 自学习闭环断裂 |
| 5 | SOP 过时了还照搬 | 输出和当前需求脱节 |
| 6 | 用户纠正了但不更新 SOP | 同样的错反复犯 |
| 7 | 链式调用不检查中间结果 | 上游错误传播到下游 |

## 案例库

### Case 1: "帮我分析这篇文章" → SOP 驱动执行
- **触发**：用户发送公众号链接
- **意图匹配**：关键词"分析"+"链接" → 意图类别 2（内容分析）
- **SOP 查询**：SOP-04（内容分析）→ baoyu-url-to-markdown → li-analyze → li-memory
- **执行**：自动串联 3 个 skill，用户不需要指定每一步
- **收尾**：li-memory 沉淀分析结论，下次类似文章可参考

### Case 2: "FPGA 项目一把过" → 竞赛区 SOP 编排
- **触发**：用户提交 FPGA 设计
- **意图匹配**：关键词"FPGA"+"一把过" → 竞赛区意图（一把过交付）
- **SOP 查询**：SOP-13（RTL 一把过）→ li-hardware → li-infra → li-sync
- **执行**：RTL 验证 → DOCX 文档 → ZIP 打包 → 工作区清理
- **铁律**：修改前 checkpoint，不读规范不动手

### Case 3: 意图冲突 → 优先级链仲裁
- **触发**："内容方向变了，投入不够"
- **意图匹配**：命中"方向变化"(P4) + "投入不足"(P6) 两个类别
- **优先级链**：P4 > P6 → 被"方向变化"接管
- **执行**：li-devil 预验尸（不执行 li-mindcoach）
- **教训**：优先级链防止 AI 在两个意图间摇摆

---

## References Index（按需加载）

| 文件 | 何时读取 | 行数 |
|------|---------|------|
| references/real-routing-rules.md | Phase 1 需要查询 5 个工作区 SOP 总索引的完整路由规则时 | ~200 |
| references/skill-chain-catalog.md | Phase 2 需要查询完整 skill→功能→触发场景映射时 | ~100 |
| references/sop-routing-rules.md | 需要查询 SOP 编排规则和 IF/ELSE 路由链时 | ~100 |
| references/sop-routing-guide.md | 需要理解 SOP 如何驱动 skill 调用链时 | ~60 |
| references/intent-patterns.md | 需要查询种子意图模式库时 | ~80 |
