# Skill Chain Catalog — Real SOP编排模板

> Each chain is a predefined sequence of skill activations.
> Source: SOP总索引 § 链式调用 from 5 workspaces.

---

## Content Chains

### Chain 1: Content Extract + Analyze
**Trigger**: "帮我读/分析/看看" + URL/链接/文章
**Steps**:
1. `baoyu-url-to-markdown` → extract article to markdown
2. `li-analyze` → 道法术器四层分析 + 百大认知引用
3. `li-memory` → extract facts + store
4. `li-improve` → record task outcome

### Chain 2: Content Creation (Article)
**Trigger**: "帮我写/做" + 文章/博客/公众号
**Steps**:
1. `li-research` → gather sources (3+ platforms)
2. `li-analyze` → structure with 道法术器
3. `li-transcript` → clean and format
4. `li-devil` → quality check
5. `li-memory` → store patterns

### Chain 3: Xiaohongshu Post
**Trigger**: "小红书/帖子/标题/爆款"
**Steps**:
1. `li-analyze` → analyze 3 top posts for patterns
2. `li-xhs` → generate content with patterns
3. `li-devil` → check for AI traces
4. `li-memory` → store what worked

### Chain 4: Translation + Polish
**Trigger**: "翻译/英译中/中译英"
**Steps**:
1. `deepl` → machine translation
2. `li-analyze` → polish with domain knowledge
3. `li-memory` → store terminology

---

## Hardware Chains

### Chain 5: FPGA Design
**Trigger**: "FPGA/Verilog/Vivado/综合/实现"
**Steps**:
1. `li-hardware` Phase 0 → requirements clarification
2. `li-hardware` Phase 1 → GPIO safety check (6 categories)
3. `li-hardware` Phase 2 → code generation (Arduino/ESP32/SystemVerilog)
4. `li-debug` → error classification if issues
5. `li-sync` → cross-workspace sync

### Chain 6: RTL Verification
**Trigger**: "仿真/时序/测试/验证/testbench"
**Steps**:
1. `li-hardware` → simulation-debug-9step
2. `li-triage` → failure classification (syntax/functional/timing/resource)
3. `li-debug` → feedback loop → fix
4. `li-hardware` → regression check

### Chain 7: Embedded Development
**Trigger**: "Arduino/ESP32/传感器/舵机/面包板"
**Steps**:
1. `li-hardware` → GPIO safety check (voltage/current/ESD)
2. `li-hardware` templates/ → code generation
3. `li-debug` → troubleshooting if issues

---

## Knowledge Chains

### Chain 8: Learning + Study
**Trigger**: "学习/理解概念/知识点/读书"
**Steps**:
1. `li-analyze` → 道法术器 framework
2. `li-study` → Feynman technique verification
3. `li-memory` → extract and store facts
4. `li-improve` → record learning outcome

### Chain 9: Research + Analysis
**Trigger**: "调研/研究/搜/查一下"
**Steps**:
1. `li-research` → multi-platform search (4 phases)
2. `li-devil` → information quality check
3. `li-analyze` → synthesize findings
4. `li-memory` → store research results

### Chain 10: System Diagnosis
**Trigger**: "诊断/分析/优化/改进/为什么"
**Steps**:
1. `li-diagnose` → entropy source identification
2. `li-devil` → root cause verification
3. `li-improve` → improvement plan
4. `li-manage` → implement changes

---

## Career Chains

### Chain 11: Resume Optimization
**Trigger**: "简历/简历优化/CV/resume"
**Steps**:
1. `li-analyze` → 5-dimension engineering language check
2. `li-content` → content optimization
3. `li-devil` → quality audit

### Chain 12: Interview Prep
**Trigger**: "面试/模拟面试/技术面"
**Steps**:
1. `li-research` → company research
2. `li-analyze` → common questions analysis
3. `li-study` → mock interview practice

---

## System Chains

### Chain 13: Skill Lifecycle
**Trigger**: "创建/融合/优化/管理" + skill
**Steps**:
1. `li-bestskill` → search external platforms
2. `li-skillcreate` → create with quality gates
3. `li-skillfusion` → merge if overlapping
4. `li-manage` → lifecycle tracking

### Chain 14: Self-Evolution
**Trigger**: "进化/改进/复盘/迭代"
**Steps**:
1. `li-improve` → Phase 0 self-audit (8 items)
2. `li-improve` → Phase 1 lesson logging
3. `li-memory` → fact extraction + contradiction check
4. `li-manage` → update SOP总索引 if 3+ recurrences

### Chain 15: Cross-Workspace Sync
**Trigger**: "同步/工作区/一致性/路由"
**Steps**:
1. `li-sync` Phase 4 → full scan (os.walk recursive)
2. `li-sync` Phase 1 → sync routing tables
3. `li-sync` Phase 5 → verify consistency

---

## Usage

When li-intent matches an intent:
1. Find matching chain above
2. Execute skills in order via `mcp__skill-handler__Skill`
3. Each skill output feeds into next skill
4. Record chain execution to skill-usage-log.md
5. If chain fails at any step → check §交叉场景处理 in SOP总索引
