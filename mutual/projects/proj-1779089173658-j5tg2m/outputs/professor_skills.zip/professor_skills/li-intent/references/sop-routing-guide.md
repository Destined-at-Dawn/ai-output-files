# SOP Routing Guide (v2.0 -- Real Paths)

## 13 SOP Index Positions (Absolute Paths)

| # | Workspace | Absolute Path | Size | Core Capability |
|---|-----------|---------------|------|-----------------|
| 1 | Creation(project) | E:\ai产出文件\牛马\创作\创作\projects\20260425-内容创作系统\SOPs\SOP总索引.md | 14.4KB | BEST: 14 IF/ELSE + chain + self-learning + frequency |
| 2 | Creation(main) | E:\ai产出文件\牛马\创作\创作\SOPs\SOP总索引.md | 7.4KB | Input dispatch + chain calls |
| 3 | Creation(OPC) | E:\ai产出文件\牛马\创作\创作\outputs\OPC分享AI迁移包_20260601-191638\02-SOP\SOPs\SOP总索引.md | 5.7KB | OPC migration |
| 4 | Competition(main) | E:\ai产出文件\牛马\竞赛\竞赛\SOPs\SOP总索引.md | 4.7KB | 13 SOPs + FPGA/Vivado/Arduino routing |
| 5 | Competition(LCD) | E:\ai产出文件\牛马\竞赛\竞赛\projects\LCD驱动开发-verilog修改\SOPs\SOP总索引.md | 4.5KB | LCD driver routing |
| 6 | Competition(proj) | E:\ai产出文件\牛马\竞赛\竞赛\projects\proj-1777087251931-pj4ul9\SOPs\SOP总索引.md | 3.3KB | Project-level routing |
| 7 | Career(main) | E:\ai产出文件\牛马\求职\求职\SOPs\SOP总索引.md | 3.1KB | Resume/interview/filter/offer routing |
| 8 | Personal(main) | E:\ai产出文件\牛马\个人\个人\SOPs\SOP总索引.md | 2.6KB | Study/plan/review routing |
| 9 | Study(main) | E:\ai产出文件\牛马\学习\学习\SOPs\SOP总索引.md | 1.9KB | Study/exam routing |
| 10 | Career(project) | E:\ai产出文件\牛马\求职\求职\projects\20260430-求职管理系统\SOPs\SOP总索引.md | 1.1KB | Project-level routing |
| 11 | mutual(main) | E:\ai产出文件\牛马\mutual\mutual\SOPs\SOP总索引.md | 557B | Ecosystem management routing |
| 12 | mutual(starter) | E:\ai产出文件\牛马\mutual\mutual\projects\20260518-生态优化\outputs\niuma-starter-kit-v2\examples\my-first-workspace\SOPs\SOP总索引.md | 563B | Template example |
| 13 | Daily Study | E:\ai产出文件\牛马\日常学习\SOPs\SOP总索引.md | 304B | Minimal routing |

## li-intent Execution Flow

### Step 1: Identify current workspace
- Read CLAUDE.md workspace root
- Or infer from user message context

### Step 2: Read nearest SOP Index
- Priority: current workspace -> parent directory -> fallback to skill-routing-table.json
- Do NOT read all 13 indexes (waste of tokens)

### Step 3: Match IF/ELSE patterns
- Match message routing rules one by one
- Match found -> extract SOP number and skill chain
- Multiple matches -> pick most specific
- No match -> Phase 0 clarification

### Step 4: Chain execution
- Execute skill chain in SOP-defined order
- Each skill output feeds into the next
- Log to conversation-journal

### Step 5: Feedback collection
- User satisfied -> reinforce routing
- User corrects -> adjust routing or mark as candidate
- 3 similar -> promote to iron law

## Fallback Strategy

When SOP Index does not cover current intent:
1. skill-routing-table.json keyword match (109 routes, 1493 triggers)
2. li-bestskill 4-phase full-platform search
3. li-research Phase 0 clarification
4. li-memory historical experience retrieval
