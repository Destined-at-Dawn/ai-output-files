# Real Routing Rules — Extracted from 3 SOP总索引

> These are REAL IF/ELSE rules from actual workspace SOP总索引 files.
> DO NOT modify without reading the source SOP总索引 first.

## Source Files

| Workspace | Path | Version | Size |
|-----------|------|---------|------|
| 创作区 | `E:\ai产出文件\牛马\创作\创作\projects\20260425-内容创作系统\SOPs\SOP总索引.md` | v2.5 | 14.4KB |
| 竞赛区 | `E:\ai产出文件\牛马\竞赛\竞赛\SOPs\SOP总索引.md` | v3.0 | 4.7KB |
| 求职区 | `E:\ai产出文件\牛马\求职\求职\SOPs\SOP总索引.md` | v2.1 | 3.1KB |

---

## 一、创作区 SOP总索引 v2.5 — 消息路由规则

### 15 个意图类别

```
# Phase 1: Intent Recognition (IF/ELSE)

IF 链接/URL/分享/文章/公众号
  → SOP-02 内容提取
  → Skills: baoyu-url-to-markdown, markitdown
  → Chain: extract → li-analyze → li-memory

IF PPT/幻灯片/汇报/演示
  → SOP-06 PPT设计
  → Skills: pptx, li-pptx
  → Chain: li-pptx → li-analyze(受众分析) → li-devil(风险检查)

IF 图片/设计/海报/封面/配图
  → SOP-08 图片设计
  → Skills: baoyu-image-gen, li-image
  → Chain: li-design → li-image → li-devil(品牌一致性)

IF 视频/脚本/分镜/配音
  → SOP-09 视频创作
  → Skills: li-video, li-storyboard
  → Chain: li-storyboard → li-video → li-devil

IF 小红书/帖子/标题/爆款
  → SOP-07 小红书运营
  → Skills: li-xhs, li-analyze
  → Chain: li-analyze(爆款拆解) → li-xhs(内容生成) → li-memory

IF 公众号/公众号文章/微信公众号
  → SOP-11 公众号创作
  → Skills: baoyu-post-to-wechat, li-analyze
  → Chain: li-research → li-analyze → li-transcript → baoyu-post-to-wechat

IF 学习/理解概念/知识点/读书
  → SOP-01 学习记录
  → Skills: li-study, li-memory
  → Chain: li-analyze(道法术器) → li-study(费曼检验) → li-memory

IF 翻译/英译中/中译英/翻译优化
  → SOP-03 翻译优化
  → Skills: deepl, li-analyze
  → Chain: deepl → li-analyze(润色) → li-memory

IF 写作/文案/文章/博客/内容
  → SOP-05 文章写作
  → Skills: li-analyze, li-transcript
  → Chain: li-research → li-analyze → li-transcript → li-devil(质量检查)

IF 诊断/分析/优化/改进/问题
  → SOP-10 内容诊断
  → Skills: li-diagnose, li-devil
  → Chain: li-diagnose → li-devil → li-improve

IF 搜索/查找/调研/查一下
  → SOP-12 信息搜索
  → Skills: li-research, web-search
  → Chain: li-research → li-devil(信息质量) → li-memory

IF 表格/数据/Excel/数据分析
  → SOP-13 数据处理
  → Skills: xlsx, li-data
  → Chain: xlsx → li-data(分析) → li-analyze(洞察)

IF 管理/技能/知识库/技能管理
  → SOP-14 知识管理
  → Skills: li-manage, li-skillcreate
  → Chain: li-bestskill → li-skillcreate → li-manage

IF 自我进化/改进/复盘/迭代
  → SOP-15 进化引擎
  → Skills: li-improve, li-evolve
  → Chain: li-improve → li-memory → li-manage

ELSE
  → 通用对话（按需触发 li-devil 做风险检查）
```

### 优先级链

```
P0 (立即执行): 安全/风险/li-devil泼冷水/紧急修复
P1 (对话开始): 学习记录/记忆管理
P2 (关键词触发): 内容创作/技能管理
P3 (需求明确): 搜索/诊断
P4 (对话结束): 知识管理/进化
```

### 交叉场景处理

```
IF 意图同时匹配 ≥2 个 SOP:
  → 选优先级更高的（P0 > P1 > P2 > P3 > P4）
  → 如果优先级相同 → 选更具体的（"小红书帖子" > "写内容"）
  → 如果仍不确定 → 问用户确认

IF 意图涉及跨工作区:
  → 读目标工作区的 SOP总索引
  → 用目标区的路由规则（不是当前区的）
```

### 自学习框架

```
每次任务完成 →
  1. 记录: 意图 + skills used + 结果 + 用户反馈
  2. usage_count++
  3. 1次 → 记录（不生成规则）
  4. 2次 → ⚠️ 标记"高频意图"
  5. 3次 → 🔴 升级为铁律（自动写入 SOP总索引）
```

### SOP→Skill 映射表

| SOP | ID | 主力 Skill | 辅助 Skill |
|-----|-----|-----------|-----------|
| 学习记录 | SOP-01 | li-study | li-memory, li-analyze |
| 内容提取 | SOP-02 | baoyu-url-to-markdown | li-analyze, li-memory |
| 翻译优化 | SOP-03 | deepl | li-analyze |
| 简历优化 | SOP-04 | li-analyze | li-content |
| 文章写作 | SOP-05 | li-analyze | li-transcript, li-research |
| PPT设计 | SOP-06 | li-pptx | li-analyze, li-devil |
| 小红书运营 | SOP-07 | li-xhs | li-analyze, li-memory |
| 图片设计 | SOP-08 | li-image | li-design |
| 视频创作 | SOP-09 | li-video | li-storyboard |
| 内容诊断 | SOP-10 | li-diagnose | li-devil, li-improve |
| 公众号创作 | SOP-11 | baoyu-post-to-wechat | li-analyze, li-research |
| 信息搜索 | SOP-12 | li-research | web-search |
| 数据处理 | SOP-13 | xlsx, li-data | li-analyze |
| 知识管理 | SOP-14 | li-manage | li-skillcreate |
| 进化引擎 | SOP-15 | li-improve | li-memory |

---

## 二、竞赛区 SOP总索引 v3.0 — 消息路由规则

### 14 个意图类别

```
IF FPGA/Verilog/Vivado/综合/实现
  → SOP-02 硬件设计与验证
  → Chain: li-hardware(Phase 0需求澄清 → Phase 1 GPIO检查 → Phase 2代码生成)
  → Always include: li-debug(错误分类) + li-sync(跨区同步)

IF PCB/电路/原理图/Altium/嘉立创
  → SOP-02 硬件设计与验证
  → Skills: li-hardware + li-design

IF Arduino/ESP32/STM32/传感器/舵机/面包板
  → SOP-02 硬件设计与验证
  → Skills: li-hardware(templates/) + li-debug

IF 仿真/时序/测试/验证/testbench
  → SOP-03 RTL验证
  → Chain: li-hardware(simulation-debug-9step) → li-triage(失败分类)

IF 规范/标准/要求/需求/竞赛要求
  → SOP-01 规范解码
  → Skills: li-research + li-hardware

IF 评估/计划/排期/里程碑
  → SOP-04 项目管理
  → Skills: li-plan + li-triage

IF 论文/文档/报告/答辩/综述
  → SOP-07 文档管理
  → Skills: li-analyze + li-research + li-transcript

IF 进化/优化/复盘/改进/SOP
  → SOP-08 进化机制
  → Skills: li-improve + li-memory

IF RoboMaster/机器人/嵌入式/CAN/PID
  → SOP-02 硬件设计与验证
  → Skills: li-hardware(embedded-patterns.md)

IF CRC/UART/I2C/SPI/通信协议
  → SOP-03 RTL验证
  → Skills: li-hardware(crc-debugging.md, uart-rx-patterns.md)

IF 调试/bug/错误/失败/不工作
  → SOP-03 RTL验证
  → Chain: li-debug(反馈循环) → li-hardware(troubleshooting.md)

IF TCL/脚本/自动化/批量
  → SOP-02 硬件设计
  → Skills: li-hardware(vivado-tcl-guide.md) + li-workflow

IF 厂商/移植/第三方代码
  → SOP-02 硬件设计
  → Skills: li-hardware(vendor-code-porting.md)

ELSE
  → 通用分析（按需触发 li-hardware 做 GPIO 安全检查）
```

### 优先级链

```
P0: 安全/急停/GPIO保护 → li-hardware Phase 1 立即执行
P1: 规范解码/需求确认 → 任何硬件任务前必须完成
P2: 代码生成/仿真验证 → 确认需求后执行
P3: 文档/报告/答辩 → 项目后期触发
P4: 进化/复盘 → 项目结束后触发
```

---

## 三、求职区 SOP总索引 v2.1 — 消息路由规则

### 5 个意图类别

```
IF 简历/简历优化/CV/resume
  → SOP-02 简历优化
  → Chain: li-analyze(5维工程语言检查) → li-content(优化) → li-devil(质量审查)

IF 面试/模拟面试/技术面/行为面
  → SOP-03 面试准备
  → Chain: li-research(公司调研) → li-analyze(常见问题) → li-study(模拟练习)

IF 求职/投递/公司/岗位/秋招/春招
  → SOP-04 求职管理
  → Chain: li-research(行业调研) → li-plan(投递计划) → li-manage(进度追踪)

IF 技能/学习/储备/项目经验
  → SOP-05 技能提升
  → Chain: li-study(学习计划) → li-competition(项目实践) → li-memory(成果记录)

ELSE
  → 通用咨询（按需触发 li-research 做行业调研）
```

### 优先级链

```
P0: 简历优化/紧急投递 → 立即执行
P1: 面试准备 → 收到面试通知后触发
P2: 求职管理/技能提升 → 日常触发
```
