# Intent Pattern Library (Extracted from 188 SOPs v2.0)

## High-Frequency Intent -> SOP -> Skill Chain

### Content Creation (Source: Creation SOP Index v2.5)

| User says | Intent | SOP | Skill Chain | Frequency |
|-----------|--------|-----|-------------|-----------|
| read article/link | Extract | SOP-00->01 | baoyu-url->li-analyze->li-memory | 3/week |
| write gongzhonghao | Create | SOP-01 | li-analyze->li-transcript->baoyu-post-to-wechat | 3/week |
| write xiaohongshu | Create | SOP-02 | li-analyze->li-xhs | 3/week |
| video script | Create | SOP-04 | li-storyboard->li-video | 2/week |
| remove AI traces | Extract | SOP-05 | li-transcript->li-analyze | 2/week |
| transcript/speech | Extract | SOP-03 | li-transcript | 2/week |
| diagnose content | Analyze | SOP-13 | li-analyze (diagnosis mode) | 1/week |

### Technical Development (Source: Competition SOP Index)

| User says | Intent | SOP | Skill Chain | Frequency |
|-----------|--------|-----|-------------|-----------|
| FPGA/Verilog/Vivado | Tech | SOP-06 | li-hardware->li-debug->li-sync | 3/week |
| Arduino/servo/ESP32 | Tech | SOP-06 | li-hardware->li-debug | 2/week |
| debug/CRC/I2C/UART | Tech | SOP-06 | li-hardware->li-debug | 2/week |
| delivery/package | Tech | SOP-12/13 | li-hardware (Phase 4) | 1/week |

### Career (Source: Career SOP Index)

| User says | Intent | SOP | Skill Chain | Frequency |
|-----------|--------|-----|-------------|-----------|
| resume/optimize | Career | SOP-01 | li-analyze->li-manage | 2/week |
| interview/prep | Career | SOP-02 | li-research->li-mindcoach | 2/week |
| offer/salary | Career | SOP-04 | li-devil->li-analyze | 1/week |

### Personal Development (Source: Personal SOP Index)

| User says | Intent | SOP | Skill Chain | Frequency |
|-----------|--------|-----|-------------|-----------|
| learn/understand/concept | Study | SOP-01 | li-study->li-analyze | 2/week |
| plan/kaoyan | Manage | SOP-02 | li-plan->li-devil | 2/week |
| review/summary | Evolve | SOP-03 | li-improve->li-memory | 1/week |
| anxious/stuck/give up | Psychology | -- | li-mindcoach->li-devil->li-memory | 1/week |

### Ecosystem Management (Source: mutual SOPs)

| User says | Intent | SOP | Skill Chain | Frequency |
|-----------|--------|-----|-------------|-----------|
| create/fuse/optimize skill | Manage | sop-skill-lifecycle | li-bestskill->li-skillcreate->li-skillfusion->li-manage | 2/week |
| sync/backup/check workspace | Manage | li-infra | li-infra->li-sync->li-manage | 2/week |
| research/search/find | Research | sop-research | li-research->li-devil->li-memory | 2/week |

## Intent Classification Decision Tree (v2.0)

```
User message enters
  Contains URL/link/file? -> Phase 1 Extract
    WeChat article? -> li-wechat + li-analyze
    Gongzhonghao link? -> baoyu-url + li-analyze
    PDF/document? -> li-office + li-analyze
    Code repo? -> li-debug + li-hardware
  Contains analyze/evaluate/dao-fa-shu-qi? -> li-analyze
  Contains write/create/xiaohongshu/gongzhonghao? -> li-analyze -> li-transcript
  Contains research/search/find? -> li-research
  Contains tech words(FPGA/Arduino/debug)? -> li-hardware / li-debug
  Contains create/fuse/optimize skill? -> li-skillcreate / li-skillfusion
  Contains sync/backup/clean? -> li-sync / li-infra
  Contains emotion words? -> li-mindcoach
  Contains learn/understand/kaoyan? -> li-study / li-plan
  Other -> li-research Phase 0 clarification
```

## Chain Call Templates (from SOP Index)

### Three-level nesting (Creation SOP v2.5)
SOP-A (input validation) -> SOP-B (core processing) -> SOP-C (quality check) -> memory persist

### Typical chains
1. Read article: SOP-00 (input gate) -> SOP-01 (extract) -> SOP-18 (reference graph) -> li-memory
2. Write gongzhonghao: SOP-01 (clarify) -> SOP-02 (create) -> SOP-05 (remove AI) -> SOP-13 (diagnose)
3. Make video: SOP-01 (requirements) -> SOP-04 (storyboard) -> SOP-16 (subtitle) -> SOP-15 (voice)
4. Hardware project: SOP-06 (safety) -> SOP-06 (code gen) -> SOP-12 (RTL verify) -> SOP-13 (delivery)
5. Skill management: li-bestskill (search) -> li-skillcreate (create) -> li-skillfusion (fuse) -> li-manage (lifecycle)
