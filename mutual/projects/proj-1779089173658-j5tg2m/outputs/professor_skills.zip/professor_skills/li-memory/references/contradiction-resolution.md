# 矛盾检测与解决

> 来源：Supermemory — "Resolves contradictions: 'I just moved to SF' supersedes 'I live in NYC'"
> 原则：矛盾不是错误，是时间演进。新事实覆盖旧事实，但保留历史。

## 矛盾检测流程

```
新事实写入前:
1. 提取 key（如 "location", "career_path"）
2. 查询 facts.db 中 status=current 且 key 相同的事实
3. 比较 value
  +-- 相同 -> 跳过（重复事实，不写入）
  +-- 不同 -> 进入矛盾处理
  +-- 无匹配 -> 直接写入
```

## 四种矛盾类型

### Type 1: 直接矛盾
- 特征：同 key，互斥 value
- 处理：新事实覆盖旧事实
- 示例：location: Shanghai vs location: Beijing -> 保留 Shanghai
- 标记：旧事实 status=superseded, supersedes_id=<new_id>

### Type 2: 时间演进
- 特征：同 key，value 是时间递进关系
- 处理：标记演进链
- 示例：grade: 大一 -> grade: 大二 -> grade: 大三
- 标记：保留最新，旧的 status=superseded

### Type 3: 偏好变化
- 特征：preference 类型，value 从 A 变到 B
- 处理：新偏好覆盖旧偏好
- 示例：format: tables -> format: no_tables
- 注意：如果变化频繁（>=3 次），触发 li-devil 泼冷水确认

### Type 4: 模糊冲突
- 特征：不确定是矛盾还是补充
- 处理：标记 [uncertain]，等待用户确认
- 示例：career: 考研 vs career: 可能不考研
- 触发：提醒用户确认（不主动追问）

## 反模式

| 反模式 | 正确做法 |
|--------|---------|
| 两个矛盾事实共存不处理 | 新事实自动覆盖旧事实 |
| 删除旧事实 | 标记 superseded，保留历史链 |
| 每次矛盾都问用户 | 只有模糊冲突(type 4)才问 |
| 不区分矛盾类型 | 四种类型有不同处理策略 |
