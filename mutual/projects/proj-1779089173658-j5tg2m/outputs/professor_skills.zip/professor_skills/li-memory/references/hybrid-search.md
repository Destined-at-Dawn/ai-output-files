# 混合检索设计

> 来源：Supermemory — "Hybrid: RAG + Memory in one query. ~50ms response."
> 原则：检索优于遍历

## 四种检索模式

### Mode 1: 精确事实查询
- 触发："我在哪个学校""我的GPA是多少"
- 实现：SELECT * FROM facts WHERE key LIKE '%school%' AND status='current' ORDER BY confidence DESC
- 返回：1 条最匹配事实

### Mode 2: 主题检索
- 触发："我的学习偏好""我的项目经历"
- 实现：SELECT * FROM facts WHERE (key LIKE '%study%' OR value LIKE '%学习%') AND status='current'
- 返回：相关事实列表（<=10 条，按置信度排序）

### Mode 3: 画像查询
- 触发：会话启动 / "你还记得我吗"
- 实现：从 facts.db 提取 static + dynamic 摘要
- 返回：<=200 token 的用户画像

### Mode 4: EvoMap 查询
- 触发：遇到问题 / "有没有类似解决方案"
- 实现：python scripts/memory_search.py --query "问题描述"
- 返回：Capsule 列表

## 检索优先级

L1 当前上下文（0 token 额外开销）
  -> L2 facts.db 查询（<50ms）
  -> L3 long-term.md 全文搜索（<200ms）
  -> EvoMap 远程查询（<2s）

## 与 li-manage MemPalace 的关系

- li-memory Phase 4：事实级检索（原子事实，精确匹配）
- li-manage Flow D MemPalace：模式级检索（行为模式，语义匹配）
