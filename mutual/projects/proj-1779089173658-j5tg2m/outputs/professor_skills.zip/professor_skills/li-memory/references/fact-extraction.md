# 事实提取规则

> 来源：Supermemory 核心机制 — "提取并追踪关于用户的原子事实"
> 原则：存事实，不存原始文本

## 五种事实类型

### Type 1: 身份事实 (Identity)
- 来源：用户明确陈述
- 置信度：high
- 过期：never
- 示例：{type: identity, key: "university", value: "上海电力大学", confidence: high, expires: never}
- 触发词："我是""我在""我的学校""GPA""专业"

### Type 2: 偏好事实 (Preference)
- 来源：用户表达喜好/厌恶
- 置信度：high（明确表达）/ medium（观察推断）
- 过期：permanent 或直到被矛盾覆盖
- 示例：{type: preference, key: "output_format", value: "no_tables", confidence: high, expires: permanent}
- 触发词："我喜欢""不要""偏好""讨厌""用列表不用表格"

### Type 3: 决策事实 (Decision)
- 来源：用户做出的选择
- 置信度：high
- 过期：never（但可能被后续决策覆盖）
- 示例：{type: decision, key: "career_path", value: "考研上交电气", confidence: high, expires: never}
- 触发词："决定""选择""不要这个""用方案A""放弃"

### Type 4: 状态事实 (Status)
- 来源：用户描述当前状态
- 置信度：medium（状态会变）
- 过期：30 天（除非更新）
- 示例：{type: status, key: "current_project", value: "FPGA竞赛", confidence: medium, expires: +30d}
- 触发词："正在""目前""在做""最近"

### Type 5: 临时事实 (Temporary)
- 来源：用户提到的短期信息
- 置信度：medium
- 过期：明确日期或 7 天
- 示例：{type: temporary, key: "exam", value: "高数期末考", confidence: medium, expires: 2026-06-15}
- 触发词："明天""下周""这次""临时"

## 提取流程

```
用户消息 -> 扫描触发词 -> 分类事实类型 -> 置信度评估 -> 矛盾检测(Phase 2) -> 写入 facts.db
```

### 不提取的内容（噪声过滤）

- 寒暄："你好""谢谢""好的"
- AI 推理：模型内部思考过程
- 重复：已存在于 L2/L3 的相同事实
- 元对话："帮我看看这个""你觉得呢"
- 指令：纯操作指令（"打开""搜索""运行"）

## 用户画像生成

学自 Supermemory 的 profile.static + profile.dynamic：

### static（稳定画像，从 L3 提取）
- 身份：学校、专业、GPA
- 偏好：输出格式、信息密度、技术深度
- 痛点：最讨厌的行为模式

### dynamic（动态画像，从 L2 最近 24h 提取）
- 正在做：当前项目/任务
- 最近决策：最近 3 条 decision 事实
- 情绪状态：最近的 status 事实

### 画像注入时机
- 会话启动：注入 L1（<=200 token）
- 用户说"你还记得我吗"：输出完整画像
- 画像过期（30 天未更新）：标记 [needs_refresh]

## facts.db Schema

```sql
CREATE TABLE facts (
    id INTEGER PRIMARY KEY,
    type TEXT,           -- identity/preference/decision/status/temporary
    key TEXT,            -- 事实键
    value TEXT,          -- 事实值
    confidence TEXT,     -- high/medium/low
    source TEXT,         -- 来源
    created_at TEXT,     -- 创建时间
    updated_at TEXT,     -- 最后更新
    expires_at TEXT,     -- 过期时间（NULL = never）
    status TEXT,         -- current/superseded/expired/stale/user_deleted
    supersedes_id INTEGER,
    workspace TEXT,      -- containerTag
    recurrence INTEGER DEFAULT 1
);
```

## 与 li-manage 的分工

| 维度 | li-memory | li-manage |
|------|-----------|-----------|
| 职责 | 事实引擎（提取/存储/检索） | 全局编排（跨区同步/画像管理） |
| 粒度 | 原子事实（1 条 = 1 个事实） | 对话摘要 + 工作流 |
| 写入 | facts.db + daily/ | user-profile.md + conversation-journal/ |
| 矛盾 | Phase 2 自动检测 | Flow D 恢复时检查一致性 |
