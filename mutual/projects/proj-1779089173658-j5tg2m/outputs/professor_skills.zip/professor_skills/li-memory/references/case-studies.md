# 真实案例

## Case 1: 偏好变化的正确处理

场景：用户之前说"喜欢表格"，后来又说"不要用表格"

li-memory v1（错误）：
  L2: [decision] 用表格展示数据
  L2: [decision] 不要用表格
  -> 两条共存，AI 不知道听哪个

li-memory v2（正确）：
  L2: [preference] format: tables [status=superseded]
  L2: [preference] format: no_tables [status=current]
  -> 旧的被标记 superseded，AI 只看 current 事实

## Case 2: 临时事实自动过期

场景：用户说"明天有高数考试"

li-memory v1（错误）：
  L2: [event] 高数考试 -> 永久保存

li-memory v2（正确）：
  L2: [temporary] exam: 高数 [expires: 2026-06-10]
  -> 6/10 自动标记 expired，不参与检索

## Case 3: EvoMap 复利效应

场景：解决了 PCA9685 舵机驱动的 PWM 频率问题

1. 事实提取: [decision] PCA9685 PWM 频率应设为 50Hz
2. 发布 Capsule 到 EvoMap
3. 下次遇到类似问题 -> EvoMap 查询 -> 直接获取解决方案
