# Supermemory 技术分析

> 来源：github.com/supermemoryai/supermemory (23.2K Star)
> 排名：LongMemEval #1, LoCoMo #1, ConvoMem #1

## 核心创新

### 1. Memory != RAG
- RAG：检索文档块，无状态
- Memory：提取并追踪关于用户的事实，有时态、有矛盾解决

### 2. 事实提取（Fact Extraction）
- 不存原始对话文本
- 自动提取原子事实 + 追踪时间变化 + 解决矛盾

### 3. 自动遗忘（Auto-Forgetting）
- 临时事实自动过期
- "噪声永远不变成永久记忆"

### 4. 用户画像（User Profiles）
- profile.static：稳定事实
- profile.dynamic：近期动态
- 50ms 检索

### 5. containerTag 隔离
- 项目/用户级别的记忆命名空间

### 6. 混合搜索
- RAG + Memory 统一查询

### 7. MCP 集成
- memory(save/forget), recall(search), context(profile)

## 我们吸收了什么

| Supermemory 特性 | 吸收到 | 改动 |
|-----------------|--------|------|
| 事实提取 | li-memory Phase 1 | 5 种事实类型 + 置信度 |
| 矛盾检测 | li-memory Phase 2 | 4 种矛盾类型 + 解决策略 |
| 自动遗忘 | li-memory Phase 3 | 基于类型/置信度/频率的三层过期 |
| 用户画像(static/dynamic) | li-memory Phase 0 | 注入 L1 <=200 token |
| containerTag | 已有 | 5 工作区天然隔离 |
| 混合检索 | li-memory Phase 4 | 四种模式 + 优先级链 |

## 我们没吸收什么（及原因）

| 特性 | 原因 |
|------|------|
| 云端向量库 | 本地优先，不依赖外部服务 |
| 多模态处理 | 当前场景不需要 |
| 连接器 | 本地 skill 生态不需要 |

## 参考项目

| 项目 | Stars | 学到了什么 |
|------|-------|-----------|
| supermemoryai/supermemory | 23.2K | 事实提取 + 矛盾解决 + 自动遗忘 |
| peterskoett/self-improving-agent | 641 | Hook 驱动 + 递归度追踪 |
| facebookresearch/HyperAgents | 2.6K | 元认知自修改 |
