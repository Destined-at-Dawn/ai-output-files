# 自动遗忘机制

> 来源：Supermemory — "Auto-forgets expired info. Temporary facts expire after the date passes."
> 原则：噪声不应该成为永久记忆

## 过期规则

### 基于类型的默认过期

| 事实类型 | 默认过期 | 可覆盖 |
|---------|---------|--------|
| identity | never | — |
| preference | permanent | 用户明确改变时 |
| decision | never | 被新决策覆盖时 |
| status | 30 天 | 更新时续期 |
| temporary | 明确日期 或 7 天 | 用户指定 |

### 基于置信度的清理

| 置信度 | 未更新阈值 | 操作 |
|--------|-----------|------|
| high | 180 天 | 标记 [needs_review] |
| medium | 90 天 | 标记 [stale] |
| low | 30 天 | 标记 [stale] |

### 基于频率的强化

| 复现次数 | 效果 |
|---------|------|
| recurrence = 1 | 正常过期 |
| recurrence >= 2 | 过期时间 x2 |
| recurrence >= 5 | 永不过期（核心事实） |

## 清理流程

### 每日清理（00:00 或会话启动时）

1. 查询过期事实（expires_at < now 且 status = current）
2. 对每条：SET status = expired
3. 写入 daily/ 日记

### 每月清理（1 日）

1. 查询 stale 事实（status = stale 且 90 天未更新）
2. 归档到 archive/facts-{month}.json

## 不过期的条件（满足任一）

- [permanent] 标记
- confidence = high 且 recurrence >= 2
- 身份事实（type = identity）
- 用户明确说"记住这个"
- 被 li-improve 教训系统引用的事实

## 反模式

| 反模式 | 正确做法 |
|--------|---------|
| 永远不清理 | 每日 + 每月清理 |
| 直接删除过期事实 | 标记 expired（可恢复） |
| 不区分临时和永久 | 每条事实必须有 expires |
