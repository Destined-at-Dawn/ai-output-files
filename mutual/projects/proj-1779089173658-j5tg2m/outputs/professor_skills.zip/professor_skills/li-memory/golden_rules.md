# li-memory 黄金规则

> 从实际使用中沉淀的永久规则。每条规则都有来源和生效日期。
> 新规则追加在末尾，不修改已有规则。

## GR-001: 事实优先于事件 (2026-06-09)
- 来源：supermemoryai/supermemory (23.2K Star)
- 规则：存原子事实，不存原始对话文本
- 反模式：把用户原话存进 L2

## GR-002: 矛盾必须解决 (2026-06-09)
- 来源：supermemoryai/supermemory temporal tracking
- 规则：同 key 的新事实自动覆盖旧事实，标记 superseded
- 反模式：两条矛盾事实共存不处理

## GR-003: 临时信息必须过期 (2026-06-09)
- 来源：supermemoryai/supermemory auto-forgetting
- 规则：temporary 类型事实必须有 expires_at
- 反模式：临时信息不设过期时间

## GR-004: 检索优于遍历 (2026-06-09)
- 来源：supermemory hybrid search (50ms)
- 规则：查询记忆用 SQL 检索，不遍历全部 daily/ 文件

## GR-005: long-term.md 只追加不覆写 (2026-06-09)
- 来源：longmemory skill 铁律 + 教训（339 行记忆丢失事故）
- 规则：long-term.md 操作必须 Read -> Edit 追加，禁止 Write 覆写
