---
name: li-memory
version: 2.0.0
description: >
  AI 记忆引擎——基于事实的原子记忆（非原始文本）。四层架构：L1 工作上下文、
  L2 原子事实（含矛盾检测+自动遗忘）、L3 长期知识（去重+时间追踪）、
  EvoMap Capsule（解决方案共享）。吸收 Supermemory(23.2K Star) 核心机制。
triggers: [memory, 记忆, 跨会话, 记住, 长期记忆, 会话记录, remind, cross-session,
  加载记忆, 事实提取, 矛盾检测, 自动遗忘, 记忆检索, recall, forget]
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/contradiction-resolution.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[自动遗忘] -> **必须** `Read references/auto-forgetting.md`
- 场景[事实提取] -> **必须** `Read references/fact-extraction.md`
- 场景[混合搜索] -> **必须** `Read references/hybrid-search.md`
- 场景[Supermemory分析] -> **必须** `Read references/supermemory-analysis.md`
- 场景[案例] -> **必须** `Read references/case-studies.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/contradiction-resolution.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-memory v2.0 — 事实驱动记忆引擎

> 灵感来源：supermemoryai/supermemory (23.2K Star)
> 核心转变：存储**原子事实**而非原始文本；自动检测矛盾；临时事实自动过期。

## 设计哲学

| # | 原则 | 来源 |
|---|------|------|
| D1 | 事实优先于事件 | Supermemory: "提取并追踪关于用户的事实" |
| D2 | 矛盾必须被解决 | Supermemory: "搬到旧金山"覆盖"住在纽约" |
| D3 | 临时信息会过期 | Supermemory: "考试明天"过期后自动遗忘 |
| D4 | 检索优于遍历 | Supermemory: 混合搜索50ms，不遍历全量 |
| D5 | 分层不可变 | li-manage 四层架构：事实->规律->快照->待解 |
| D6 | EvoMap 复利 | 高质量解决方案发布共享，越用越好 |

## 四层架构

| 层 | 存储 | 内容 | 持久性 |
|----|------|------|--------|
| **L1** 工作上下文 | LLM Context | 当前对话事实 + 用户画像摘要 | 会话内 |
| **L2** 原子事实 | facts.db + daily/ | 原子事实 + 时间戳 + 来源 + 置信度 | 永久（自动清理过期） |
| **L3** 长期知识 | long-term.md | 去重后的核心知识 | 永久 |
| **EvoMap** | evomap.ai | 解决方案 Capsule | 永久共享 |


## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |

## Phase 0: 会话启动 — 记忆加载

每次会话启动时自动执行（与 CLAUDE.md 启动序列配合）：

1. 读取 L3: long-term.md（核心知识）
2. 读取 L2: facts.db 最近 24h 事实 + 今日 daily/ 日记
3. 读取 L1: 构建用户画像摘要（static + dynamic）
4. 注入 LLM Context（<=500 token 开销）

**用户画像两层**（学自 Supermemory）：
- `static`：稳定偏好（"喜欢简洁输出""电气工程专业"）
- `dynamic`：近期动态（"正在做竞赛项目""昨天刚学了 FPGA"）

详见 `references/fact-extraction.md` 之 用户画像生成。

## Phase 1: 事实提取（对话中）

**核心转变**：不存储原始对话文本，提取原子事实。

### 提取规则

| 输入 | 提取为 | 示例 |
|------|--------|------|
| "我刚搬到上海" | 事实(当前) | location: Shanghai [2026-06-09, high] |
| "我不喜欢表格" | 偏好 | format_preference: no_tables [high, permanent] |
| "这个方案不行" | 决策 | decision: rejected_X [reason: ..., high] |
| "明天有考试" | 临时事实 | temporary: exam_tomorrow [expires: 2026-06-10] |
| "GPA 3.9/4.0" | 身份事实 | academic: gpa_3.9 [high, permanent] |

### 不提取的内容

- 寒暄/礼貌用语
- AI 自己的推理过程
- 已存在于 L3 中的重复事实

详见 `references/fact-extraction.md`。

## Phase 2: 矛盾检测（写入前）

每次写入新事实前，检查是否与已有事实矛盾：

```
新事实 -> 搜索 facts.db 同主题 -> 有冲突?
  +-- 是 -> 标记旧事实为 [superseded]，新事实标记 [current]
  +-- 否 -> 直接写入
```

### 矛盾类型

| 类型 | 处理 | 示例 |
|------|------|------|
| 直接矛盾 | 新覆盖旧 | "在上海" vs "在北京" -> 保留"在上海" |
| 时间演进 | 标记演进 | "大一" -> "大二" -> 保留"大二" |
| 偏好变化 | 新覆盖旧 | "喜欢表格" -> "不喜欢表格" -> 保留新的 |
| 模糊冲突 | 标记待确认 | "可能考研" vs "不考研" -> 标记 [uncertain] |

详见 `references/contradiction-resolution.md`。

## Phase 3: 自动遗忘（定期）

**临时事实必须过期。** 每日 00:00 或会话启动时执行：

1. 扫描 facts.db 中 expires < now 的事实 -> 标记 [expired]
2. 超过 90 天未更新且置信度=low -> 标记 [stale]
3. 超过 180 天的 [stale] 事实 -> 归档到 archive/
4. [expired] 事实不删除，标记后不参与检索

**不过期的事实**：
- 用户明确说的永久偏好（[permanent]）
- 身份事实（学校/GPA/专业）
- 被标记为 [high_confidence] 且 recurrence >= 2

详见 `references/auto-forgetting.md`。

## Phase 4: 记忆检索

### 检索方式

| 方式 | 触发 | 返回 |
|------|------|------|
| **精确查询** | "我在哪个学校" | 最匹配的 1 条事实 |
| **主题查询** | "我的学习偏好" | 相关事实列表（按置信度排序） |
| **画像查询** | 用户首次对话 | static + dynamic 摘要（<=200 token） |
| **EvoMap 查询** | 遇到已解决过的问题 | Capsule 列表 |

### 检索优先级

```
L1 当前上下文 -> L2 facts.db -> L3 long-term.md -> EvoMap
```

详见 `references/hybrid-search.md`。

## Phase 5: EvoMap 集成

当解决了一个有价值的问题 -> 发布 Capsule。遇到问题时 -> 先查 EvoMap。

## 案例库

| # | 案例 | 场景 | 处理方式 | 关键教训 |
|---|------|------|---------|---------|
| 1 | 事实提取 | 用户说"我刚搬到上海，之前在北京"，v1 存原始文本占 200 token，v2 提取为 2 条原子事实占 40 token | Phase 1 提取 `location: Shanghai [current]`，旧事实标记 `[superseded]` | 原子事实比原始文本省 80% token，且可被精确检索 |
| 2 | 矛盾检测 | 用户说"喜欢表格"，两周后说"不要用表格"，v1 两条共存 AI 不知道听哪个 | Phase 2 矛盾检测：旧偏好标记 `[superseded]`，新偏好标记 `[current]` | 矛盾必须被解决，不能共存；新覆盖旧是默认策略 |
| 3 | 自动遗忘 | 用户说"明天有高数考试"，v1 永久保存，3 个月后还在检索到这条过时信息 | Phase 3 设置 `expires: 2026-06-10`，到期后标记 `[expired]` 不参与检索 | 临时信息必须有过期时间；不过期 = 检索噪声 |

> 详细案例 → `references/case-studies.md`

## 反模式

| # | 反模式 | 正确做法 | 理论来源 |
|---|--------|---------|---------|
| A1 | 存原始对话文本 | 提取原子事实 | Supermemory: "distilled facts, not transcripts" |
| A2 | 矛盾共存不处理 | 新事实覆盖旧事实 | Supermemory: temporal tracking |
| A3 | 临时信息永久保存 | 设置 expires 自动清理 | Supermemory: auto-forgetting |
| A4 | 手动遍历全部记忆 | 用检索查询 | Supermemory: 50ms hybrid search |
| A5 | 不区分置信度 | 每条事实标置信度 | 记忆置信度协议 |
| A6 | 跨工作区混存事实 | containerTag 隔离 | Supermemory: containerTag scoping |
| A7 | 覆写 long-term.md | 追加+去重 | longmemory 铁律 |

## 条件下一步

| 条件 | 下一步 | 联动 |
|------|--------|------|
| 用户表达新偏好 | Phase 1 提取 -> Phase 2 矛盾检测 -> 写入 L2 | li-manage Flow A |
| 会话结束 | 提取本轮所有事实 -> 写入 facts.db | li-improve Phase 0.5 |
| 遇到已解决的问题 | 查 EvoMap -> 有则直接用 | li-research |
| 用户说"记住这个" | 提取为 permanent 事实 | li-manage |
| 用户说"忘记这个" | 标记 [user_deleted] | — |
| 事实 contradiction >= 3 次 | 提醒用户确认最终偏好 | li-devil |
| 每月 1 日 | 事实健康检查（过期/矛盾/重复） | li-manage Flow C |

## 联动

| 技能 | 触发 | 联动方式 |
|------|------|---------|
| li-manage | 事实写入后 | 同步到 user-profile.md；全局编排记忆健康检查（每月 Flow C） |
| li-improve | 教训提取后 | 转化为 L2 事实；进化引擎驱动记忆规则迭代 |
| li-sync | 跨区同步时 | facts.db 不同步（隔离），long-term.md 同步到所有工作区 |
| li-devil | 矛盾检测到偏好变化 | 触发泼冷水确认 |
| li-research | EvoMap 查询 | 补充研究结果 |
| li-transcript | 逐字稿清洗后 | 提取事实存入 L2 |

## 脚本

| 脚本 | 功能 |
|------|------|
| `scripts/memory_add.py` | 添加事实到 L2（SQLite + daily/） |
| `scripts/memory_search.py` | 检索事实（支持类型/日期/置信度过滤） |
| `scripts/evomap_publish.py` | 发布 Capsule 到 EvoMap |

## 参考文件（按需加载）

| 文件 | 内容 | 加载时机 |
|------|------|---------|
| `references/fact-extraction.md` | 事实提取规则 + 5 种事实类型 + 用户画像生成 | Phase 1 |
| `references/contradiction-resolution.md` | 矛盾检测算法 + 4 种矛盾类型 + 解决策略 | Phase 2 |
| `references/auto-forgetting.md` | 过期规则 + 清理策略 + 不过期条件 | Phase 3 |
| `references/hybrid-search.md` | 检索方式 + 优先级 + 接口设计 | Phase 4 |
| `references/supermemory-analysis.md` | Supermemory(23.2K Star) 技术分析 + 吸收清单 | 学习/审计 |
| `references/case-studies.md` | 真实案例 | 参考 |

---
最后更新：2026-06-09 (v2.0, Supermemory integration)

## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈

## Case Studies

### Case 1: Supermemory 矛盾检测集成（2026-06-09）
- **场景**: 用户说搬到旧金山了，但记忆里有住在上海
- **方法**: Phase 2 矛盾检测 - 发现直接矛盾 -> 自动标记 -> 告知用户
- **结果**: 记忆库保持一致
- **来源**: Supermemory（23.2K star）的技术设计

### Case 2: 自动遗忘临时事实（2026-06-09）
- **场景**: 今天下午 3 点开会这条事实在第二天应该自动过期
- **方法**: Phase 3 自动遗忘 - 三层过期（类型默认 + 置信度清理 + 频率强化）
- **教训**: 临时事实不设过期 = 记忆库无限膨胀

### Case 3: 跨工作区事实隔离（2026-06-09）
- **场景**: 竞赛区的事实（FPGA 参数）不应该污染学习区
- **方法**: containerTag 隔离 - 每条事实标注来源工作区
- **教训**: 共享记忆会导致上下文污染

## Anti-Patterns

| ID | 反模式 | 后果 | 纠正 |
|----|--------|------|------|
| AP-01 | 存原始事件不提取事实 | 检索噪音大 | 存原子事实 |
| AP-02 | 不设过期时间 | 记忆库无限膨胀 | 每条事实标 TTL |
| AP-03 | 跨区不隔离 | 上下文污染 | containerTag |
| AP-04 | 矛盾不检测 | 新旧信息冲突 | 每次写入前检查矛盾 |
| AP-05 | 存用户说过的话而非事实 | 语义搜索噪音大 | 提取事实再存储 |

## Linked Skills

| Skill | 触发条件 | 联动方式 |
|-------|---------|----------|
| li-manage | 记忆清理/同步 | 调用 manage 的清理流程 |
| li-analyze | 文章分析后 | 提取事实存入记忆 |
| li-improve | 进化总结后 | 记录教训到记忆 |