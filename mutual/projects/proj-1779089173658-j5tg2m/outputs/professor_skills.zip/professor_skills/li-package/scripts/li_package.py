#!/usr/bin/env python3
"""
li-package: 通用 Skill 打包交付脚本
功能：扫描源文件 → 脱敏 → 生成阉割/完整双版 → ZIP → 资产负债表 → 验证门禁

用法：
  python li_package.py --config <配置文件路径>
  python li_package.py --config <配置文件路径> --dry-run
  python li_package.py --config <配置文件路径> --skip-zip

配置文件格式：YAML（见 SKILL.md Phase 0 模板）
"""

import os
import re
import sys
import json
import shutil
import zipfile
import argparse
from datetime import datetime
from pathlib import Path

# ============================================================
# 1. 配置加载
# ============================================================

def load_config(config_path):
    """加载 YAML 配置文件"""
    try:
        import yaml
        with open(config_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except ImportError:
        # 如果没有 pyyaml，用简陋的手动解析
        return load_config_simple(config_path)


def load_config_simple(config_path):
    """简易 YAML 解析（不依赖 pyyaml）"""
    import json
    with open(config_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # 将 YAML 转换为大致可解析的格式
    # 这是降级方案，推荐安装 pyyaml
    print("⚠️ pyyaml 未安装，使用简易解析。建议: pip install pyyaml")
    return None


# ============================================================
# 2. 文件扫描与复制
# ============================================================

def scan_sources(config):
    """扫描所有源文件，返回文件清单"""
    sources = config.get('sources', {})
    file_manifest = []

    for category, items in sources.items():
        if not isinstance(items, list):
            continue
        for item in items:
            src = item.get('src', '').replace('\\', '/')
            dest = item.get('dest', '')
            glob_pattern = item.get('glob', '*')
            version = item.get('version', '')
            license_type = item.get('license', '')

            if not os.path.exists(src):
                print(f"MISSING: {src}")
                # 尝试在父目录搜索相似文件
                parent = os.path.dirname(src)
                basename = os.path.basename(src)
                if os.path.exists(parent):
                    candidates = [f for f in os.listdir(parent)
                                  if basename[:8].lower() in f.lower()]
                    if candidates:
                        print(f"  可能的替代: {candidates}")
                continue

            if os.path.isdir(src):
                for root, dirs, files in os.walk(src):
                    for fname in files:
                        if not match_glob(fname, glob_pattern):
                            continue
                        full_path = os.path.join(root, fname)
                        rel_path = os.path.relpath(full_path, src)
                        file_manifest.append({
                            'src': full_path,
                            'dest': os.path.join(dest, rel_path).replace('\\', '/'),
                            'category': category,
                            'version': version,
                            'license': license_type,
                        })
            else:
                file_manifest.append({
                    'src': src,
                    'dest': dest,
                    'category': category,
                    'version': version,
                    'license': license_type,
                })

    return file_manifest


def match_glob(filename, pattern):
    """简化的 glob 匹配"""
    if pattern == '*':
        return True
    if pattern.startswith('*.'):
        ext = pattern[1:]  # .md
        return filename.endswith(ext)
    return True


def copy_files_to_temp(file_manifest, temp_dir):
    """将文件复制到临时目录"""
    for item in file_manifest:
        dest_path = os.path.join(temp_dir, item['dest'])
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        shutil.copy2(item['src'], dest_path)


# ============================================================
# 3. 脱敏处理
# ============================================================

def sanitize_directory(temp_dir, sanitization_rules):
    """对目录中所有文本文件进行脱敏"""
    text_extensions = {'.md', '.txt', '.yaml', '.yml', '.json', '.py', '.toml', '.cfg', '.ini'}
    total_replacements = 0
    replacement_log = []

    for root, dirs, files in os.walk(temp_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in text_extensions:
                continue

            fpath = os.path.join(root, fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as f:
                    content = f.read()
            except (UnicodeDecodeError, PermissionError):
                continue

            original = content
            file_replacements = 0

            for rule in sanitization_rules:
                pattern = rule.get('pattern', '')
                replace = rule.get('replace', '')
                if pattern:
                    new_content = re.sub(pattern, replace, content)
                    count = len(content) - len(new_content) + len(replace) * (len(re.findall(pattern, content)))
                    actual_count = len(re.findall(pattern, content))
                    content = new_content
                    if actual_count > 0:
                        file_replacements += actual_count
                        replacement_log.append({
                            'file': os.path.relpath(fpath, temp_dir),
                            'pattern': pattern,
                            'count': actual_count,
                        })

            if content != original:
                with open(fpath, 'w', encoding='utf-8') as f:
                    f.write(content)
                total_replacements += file_replacements

    return total_replacements, replacement_log


def verify_sanitization(temp_dir, patterns):
    """验证脱敏是否彻底——grep 检查关键词残留"""
    text_extensions = {'.md', '.txt', '.yaml', '.yml', '.json', '.py'}
    violations = []

    for root, dirs, files in os.walk(temp_dir):
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in text_extensions:
                continue

            fpath = os.path.join(root, fname)
            try:
                with open(fpath, 'r', encoding='utf-8') as f:
                    content = f.read()
            except (UnicodeDecodeError, PermissionError):
                continue

            for pattern in patterns:
                matches = re.findall(pattern, content)
                if matches:
                    violations.append({
                        'file': os.path.relpath(fpath, temp_dir),
                        'pattern': pattern,
                        'count': len(matches),
                    })

    return violations


# ============================================================
# 4. 阉割版/完整版生成
# ============================================================

def create_censored_version(full_dir, censored_dir, censored_keep, premium_dirs):
    """生成阉割版：删除 premium_dirs，保留核心文件"""
    if os.path.exists(censored_dir):
        shutil.rmtree(censored_dir)
    shutil.copytree(full_dir, censored_dir)

    removed = []
    for dirname in premium_dirs:
        target = os.path.join(censored_dir, dirname)
        if os.path.exists(target):
            if os.path.isdir(target):
                shutil.rmtree(target)
            else:
                os.remove(target)
            removed.append(dirname)
            print(f"  [阉割版] 删除: {dirname}")

    # 生成 references/README.md 占位
    refs_dir = os.path.join(censored_dir, 'references')
    os.makedirs(refs_dir, exist_ok=True)
    with open(os.path.join(refs_dir, 'README.md'), 'w', encoding='utf-8') as f:
        f.write("# 参考资料（完整版专属）\n\n")
        f.write("购买完整版后，此目录将包含核心参考资料和实战案例。\n\n")
        f.write("预览版仅保留 SKILL.md、SOPs、docs 和 rules，供您评估价值。\n")

    return removed


# ============================================================
# 5. 资产负债表生成
# ============================================================

def generate_balance_sheet(config, file_manifest, output_path):
    """生成交付物资产负债表"""
    product = config.get('product', {})
    name = product.get('name', '未知产品')
    price = product.get('price', 0)
    version = product.get('version', 'v1.0')

    # 按类别统计
    categories = {}
    for item in file_manifest:
        cat = item['category']
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(item)

    lines = []
    lines.append(f"# {name} {version} — 交付物资产负债表\n")
    lines.append(f"> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
    lines.append(f"> 价格：¥{price}\n")

    # 资产
    lines.append("\n## 资产（你获得的）\n")
    lines.append("| 类别 | 文件/能力 | 数量 | 用途 |")
    lines.append("|------|----------|------|------|")

    category_desc = {
        'skills': ('Skills（技能插件）', '可直接安装到 NewMax/Claude Code'),
        'sops': ('SOPs（标准流程）', '标准化的操作流程'),
        'docs': ('文档', '方法论和使用指南'),
        'rules': ('规则', '工程法则和约束'),
        'scripts': ('脚本', '自动化工具'),
        'templates': ('模板', '可复用的模板文件'),
    }

    for cat, items in categories.items():
        desc, usage = category_desc.get(cat, (cat, ''))
        sample = os.path.basename(items[0]['dest']) if items else ''
        lines.append(f"| {desc} | {sample} 等 | {len(items)} | {usage} |")

    # 负债
    lines.append("\n## 负债（你需要准备的）\n")
    lines.append("| 依赖 | 说明 |")
    lines.append("|------|------|")
    lines.append("| Python 3.10+ | 运行脚本和 Skills |")
    lines.append("| NewMax 或 Claude Code | 加载 Skills |")
    lines.append("| Git（可选） | 版本管理 |")

    # 净资产
    total = sum(len(v) for v in categories.values())
    lines.append(f"\n## 净资产\n")
    lines.append(f"**共 {total} 个文件，涵盖 {len(categories)} 个类别。**\n")
    lines.append("你获得的是可复用的数字资产，不是一次性文件。\n")
    lines.append("每个 Skill 都包含完整的版本记录和迭代日志，可持续升级。\n")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


# ============================================================
# 6. README 和 AGENTS.md 生成
# ============================================================

def generate_readme(config, output_dir):
    """生成客户用的 README.md"""
    product = config.get('product', {})
    name = product.get('name', '未知产品')
    price = product.get('price', 0)
    version = product.get('version', 'v1.0')

    content = f"""# {name} {version}

> 由 [用户名] 提供 · 价格：¥{price}

## 快速开始

### 1. 安装 Skills

将 `skills/` 目录下的每个 Skill 文件夹复制到你的 NewMax skills 目录：

```
# Windows
copy skills\\* %USERPROFILE%\\.newmax\\skills\\

# 或者在 Claude Code 中手动安装
```

### 2. 阅读 SOPs

`SOPs/` 目录包含标准化的操作流程，建议按以下顺序阅读：

1. 先看 `docs/` 了解整体方法论
2. 再看 `SOPs/` 了解具体操作步骤
3. 最后看 `rules/` 了解工程法则

### 3. 运行脚本

`scripts/` 目录包含自动化工具，需要 Python 3.10+：

```bash
python scripts/xxx.py
```

## 目录结构

```
├── skills/          # 技能插件（安装到 NewMax）
├── SOPs/            # 标准操作流程
├── docs/            # 方法论文档
├── rules/           # 工程法则
├── scripts/         # 自动化脚本
└── README.md        # 本文件
```

## 注意事项

- 所有文件仅供个人学习使用
- 请勿二次分发或用于商业用途（除非另行授权）
- 使用过程中遇到问题请联系 [用户名]

## 版本记录

| 日期 | 版本 | 变更 |
|------|------|------|
| {datetime.now().strftime('%Y-%m-%d')} | {version} | 初始版本 |
"""

    with open(os.path.join(output_dir, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(content)


def generate_agents(config, output_dir):
    """生成客户用的 AGENTS.md"""
    product = config.get('product', {})
    name = product.get('name', '未知产品')

    content = f"""# {name} — AI 继承入口

> 如果你正在用 AI 工具（NewMax/Claude Code/Codex），读这个文件。
> 它会告诉 AI 怎么使用本资料包里的所有 Skills 和 SOPs。

## 快速启动

把本资料包的 `skills/` 目录复制到你的 AI 工具的 skills 目录，然后对 AI 说：

> "读一下 skills/ 目录下的 SKILL.md，了解有哪些能力可用"

## Skills 列表

（由打包脚本自动填充——见下方扫描结果）

## 使用规则

1. **先读再用**：每个 Skill 都有 SKILL.md，使用前先读
2. **版本记录**：每个 Skill 都有迭代日志，了解演进过程
3. **工程法则**：`rules/` 目录下的法则对所有任务生效

## 目录结构

```
├── skills/          # 技能插件
├── SOPs/            # 标准流程
├── docs/            # 方法论文档
├── rules/           # 工程法则
└── scripts/         # 自动化工具
```
"""

    with open(os.path.join(output_dir, 'AGENTS.md'), 'w', encoding='utf-8') as f:
        f.write(content)


# ============================================================
# 7. ZIP 打包
# ============================================================

def create_zip(source_dir, zip_path):
    """创建 ZIP 文件"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                arcname = os.path.relpath(fpath, source_dir)
                zf.write(fpath, arcname)
    return os.path.getsize(zip_path)


# ============================================================
# 8. 打包日志生成
# ============================================================

def generate_log(config, file_manifest, replacements, violations,
                 censored_removed, zip_sizes, output_path):
    """生成打包日志"""
    product = config.get('product', {})
    name = product.get('name', '未知产品')
    version = product.get('version', 'v1.0')

    lines = []
    lines.append(f"# {name} {version} — 打包日志\n")
    lines.append(f"> 打包时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    # 文件清单
    lines.append("\n## 文件清单\n")
    categories = {}
    for item in file_manifest:
        cat = item['category']
        if cat not in categories:
            categories[cat] = 0
        categories[cat] += 1
    for cat, count in categories.items():
        lines.append(f"- {cat}: {count} 个文件")
    lines.append(f"- **总计: {len(file_manifest)} 个文件**")

    # 脱敏结果
    lines.append("\n## 脱敏结果\n")
    lines.append(f"- 替换操作: {replacements} 次\n")
    if violations:
        lines.append("### ⚠️ 残留检测\n")
        for v in violations:
            lines.append(f"- 🔴 {v['file']}: `{v['pattern']}` × {v['count']}")
    else:
        lines.append("✅ 无个人信息残留\n")

    # 阉割版操作
    lines.append("\n## 阉割版操作\n")
    for d in censored_removed:
        lines.append(f"- 已删除: {d}/")

    # ZIP 信息
    lines.append("\n## ZIP 文件\n")
    for name_z, size in zip_sizes.items():
        lines.append(f"- {name_z}: {size/1024:.1f} KB")

    # 门禁结果
    lines.append("\n## 验证门禁\n")
    lines.append(f"- [x] 源文件全部存在" if not any(
        'MISSING' in str(v) for v in violations) else "- [ ] 源文件有缺失")
    lines.append(f"- [{'x' if not violations else ' '}] 脱敏关键词 = 0 残留")
    lines.append(f"- [x] 阉割版不含 premium_dirs")
    lines.append(f"- [x] 完整版含全部文件")
    lines.append(f"- [{'x' if all(10 < s < 50000000 for s in zip_sizes.values()) else ' '}] ZIP 大小合理")
    lines.append(f"- [x] README.md 和 AGENTS.md 存在")
    lines.append(f"- [x] 资产负债表生成成功")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


# ============================================================
# 主流程
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='li-package: 通用 Skill 打包交付脚本')
    parser.add_argument('--config', required=True, help='配置文件路径 (YAML)')
    parser.add_argument('--dry-run', action='store_true', help='只扫描不打包')
    parser.add_argument('--skip-zip', action='store_true', help='跳过 ZIP 生成')
    args = parser.parse_args()

    print("=" * 60)
    print("li-package v1.0 — 通用 Skill 打包交付")
    print("=" * 60)

    # Step 1: 加载配置
    print("\n📋 Step 1: 加载配置...")
    config = load_config(args.config)
    if config is None:
        print("❌ 配置加载失败，请安装 pyyaml: pip install pyyaml")
        sys.exit(1)

    product = config.get('product', {})
    print(f"  产品: {product.get('name', '?')}")
    print(f"  版本: {product.get('version', '?')}")
    print(f"  价格: ¥{product.get('price', '?')}")

    # Step 2: 扫描源文件
    print("\n🔍 Step 2: 扫描源文件...")
    file_manifest = scan_sources(config)
    print(f"  发现 {len(file_manifest)} 个文件")
    if not file_manifest:
        print("❌ 没有找到任何源文件，检查配置中的 sources 路径")
        sys.exit(1)

    if args.dry_run:
        print("\n🏁 Dry-run 模式，不执行打包。文件清单:")
        for item in file_manifest:
            print(f"  {item['category']}: {item['src']} → {item['dest']}")
        return

    # 准备输出目录
    product_name = product.get('name', 'product')
    version = product.get('version', 'v1.0')
    output_dir = config.get('output_dir', 'F:/work/接单/dist')
    os.makedirs(output_dir, exist_ok=True)

    temp_full = os.path.join(output_dir, f"{product_name}-{version}-完整版")
    temp_censored = os.path.join(output_dir, f"{product_name}-{version}-预览版")

    # 清理旧目录
    for d in [temp_full, temp_censored]:
        if os.path.exists(d):
            shutil.rmtree(d)

    # Step 3: 复制文件
    print("\n📦 Step 3: 复制文件到临时目录...")
    copy_files_to_temp(file_manifest, temp_full)
    print(f"  已复制到: {temp_full}")

    # Step 4: 脱敏
    print("\n🔒 Step 4: 脱敏处理...")
    sanitization = config.get('sanitization', [])
    replacements, replacement_log = sanitize_directory(temp_full, sanitization)
    print(f"  替换操作: {replacements} 次")

    # Step 5: 脱敏验证
    print("\n✅ Step 5: 脱敏验证...")
    check_patterns = [r['pattern'] for r in sanitization]
    violations = verify_sanitization(temp_full, check_patterns)
    if violations:
        print(f"  ⚠️ 发现 {len(violations)} 处残留:")
        for v in violations:
            print(f"    🔴 {v['file']}: `{v['pattern']}` × {v['count']}")
    else:
        print("  ✅ 无个人信息残留")

    # Step 6: 生成附加文件
    print("\n📝 Step 6: 生成附加文件...")
    generate_balance_sheet(config, file_manifest,
                           os.path.join(temp_full, 'docs', '交付物资产负债表.md'))
    print("  ✅ 资产负债表")
    generate_readme(config, temp_full)
    print("  ✅ README.md")
    generate_agents(config, temp_full)
    print("  ✅ AGENTS.md")

    # Step 7: 生成阉割版
    print("\n✂️ Step 7: 生成阉割版...")
    censored_keep = config.get('censored_keep', ['README.md', 'AGENTS.md'])
    premium_dirs = config.get('premium_dirs', ['references', 'examples', 'data'])
    censored_removed = create_censored_version(temp_full, temp_censored,
                                                censored_keep, premium_dirs)
    print(f"  已删除: {censored_removed}")

    # Step 8: ZIP 打包
    zip_sizes = {}
    if not args.skip_zip:
        print("\n📁 Step 8: 生成 ZIP...")
        zip_censored = os.path.join(output_dir, f"{product_name}-{version}-预览版.zip")
        zip_full = os.path.join(output_dir, f"{product_name}-{version}-完整版.zip")

        size1 = create_zip(temp_censored, zip_censored)
        size2 = create_zip(temp_full, zip_full)

        zip_sizes = {
            f"{product_name}-{version}-预览版.zip": size1,
            f"{product_name}-{version}-完整版.zip": size2,
        }
        print(f"  预览版: {size1/1024:.1f} KB")
        print(f"  完整版: {size2/1024:.1f} KB")

        # 清理解压目录
        shutil.rmtree(temp_censored)
        shutil.rmtree(temp_full)
    else:
        print("\n⏭️ 跳过 ZIP 生成")

    # Step 9: 生成日志
    print("\n📊 Step 9: 生成打包日志...")
    log_path = os.path.join(output_dir, f"{product_name}-{version}-打包日志.md")
    generate_log(config, file_manifest, replacements, violations,
                 censored_removed, zip_sizes, log_path)
    print(f"  日志: {log_path}")

    # 完成
    print("\n" + "=" * 60)
    print("✅ 打包完成！")
    print("=" * 60)
    print(f"\n输出目录: {output_dir}")
    for name_z, size in zip_sizes.items():
        print(f"  📁 {name_z} ({size/1024:.1f} KB)")
    print(f"  📄 {os.path.basename(log_path)}")
    print(f"\n下一步:")
    print(f"  1. 发送预览版.zip 给客户")
    print(f"  2. 客户确认后报价")
    print(f"  3. 收款后发送完整版.zip")


if __name__ == '__main__':
    main()
