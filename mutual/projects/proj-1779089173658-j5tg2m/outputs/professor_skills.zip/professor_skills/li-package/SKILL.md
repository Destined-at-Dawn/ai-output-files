---
name: li-package
version: 1.0.0
description: Skill 交付打包助手——标准化生产「阉割版 + 完整版」资料包
author: niuma
triggers:
  - 打包skill
  - 打包资料
  - 生成交付包
  - 生产资料包
  - 打包工作流
  - packaging
  - 交付准备
  - 准备资料包
---

# li-package v1.0 — Skill 交付打包助手

## 什么时候用这个 Skill

当你要把 Skills、SOP、工作流等数字资产打包成可交付的产品时，自动激活。

典型场景：
- 客户付费后，需要打包发送资料
- 新增产品包时，需要标准化生产流程
- 需要对已有资料包做脱敏处理时
- 需要清理文档中的 emoji 和不专业表达时

## 核心原则

1. **不能裸奔**——任何资料发给客户前必须脱敏
2. **先阉割再完整**——先发预览版建立预期，完整版是付费理由
3. **有借有还**——从工作区「借」文件，打包完「还」回去（物理隔离，不改源文件）
4. **专业交付**——所有文档必须清理 emoji 和粗俗表达，用结构化标题代替
5. **打包完自检**——查杀 5 种致命文件 + 脱敏二次扫描 + ZIP 验证

## 执行流程

### Phase 0：读取约束

**必须**按顺序读取以下文件：

1. `F:\work\接单\AGENTS.md`——铁律 + 路由表
2. `F:\work\接单\docs\Skill交付避坑指南.md`——17 条死线
3. `F:\work\接单\docs\study-review-kit交付迭代全记录.md`——v1→v3 教训
4. 对应产品的 `AI执行指南-*.md`——具体执行步骤

读完后回答 3 个验证问题（自问自答，不需要用户参与）：
- 阉割版和完整版的边界是什么？
- 需要从哪些源目录「借」文件？
- 脱敏规则有哪些？

### Phase 1：源文件盘点

```bash
python F:\work\接单\scripts\package.py scan <产品包目录>
```

确认所有需要的源文件存在。缺失的文件在 Phase 2 补充。

### Phase 2：脱敏处理

```bash
python F:\work\接单\scripts\package.py sanitize <产品包目录>
```

同时运行 emoji 清理：

```bash
python F:\work\接单\scripts\clean_emojis.py <产品包目录> --fix
```

### Phase 3：版本分离

根据指南中的 `EXCLUDE_FROM_PREVIEW` 部分，创建阉割版。

```bash
python F:\work\接单\scripts\package.py split <产品包目录> --guide <指南路径>
```

### Phase 4：打包

```bash
python F:\work\接单\scripts\package.py pack <产品包目录>
```

### Phase 5：自检

```bash
python F:\work\接单\scripts\package.py diagnose <产品包目录>
```

检查清单：
- [ ] 查杀 5 种致命文件（记忆、输出、平台、telos、凭证）
- [ ] 脱敏二次扫描
- [ ] ZIP 可正常解压
- [ ] CHANGELOG.md 包含版本记录
- [ ] 资产负债表（如适用）

## 脚本位置

| 脚本 | 用途 |
|------|------|
| `F:\work\接单\scripts\package.py` | 核心打包脚本（scan/sanitize/split/pack/diagnose） |
| `F:\work\接单\scripts\clean_emojis.py` | emoji + 不专业表达清理 |

## 文档位置

| 文档 | 用途 |
|------|------|
| `F:\work\接单\AGENTS.md` | AI 继承入口（铁律 + 路由表） |
| `F:\work\接单\docs\Skill交付避坑指南.md` | 17 条死线 |
| `F:\work\接单\docs\study-review-kit交付迭代全记录.md` | v1→v3 教训 |
| `F:\work\接单\templates\` | 模板文件 |

## 新增产品包时

1. 在 `F:\work\` 下创建产品包目录（含 `完整版/` 和 `预览版/`）
2. 编写 `AI执行指南-*.md`
3. 更新 `F:\work\接单\CLAUDE.md` 的 §四-B 文档列表
4. 更新 `F:\work\接单\docs\项目总览.md` 的产品包清单
5. 运行 `python package.py full <产品包目录> --guide <指南>` 验证全流程

## 与 li-skillcreate 的关系

- `li-skillcreate`：创建单个 Skill（SKILL.md + _meta.json）
- `li-package`：把多个 Skills + SOP + 参考资料打包成可交付产品

`li-skillcreate` 是生产工具，`li-package` 是交付工具。

## 版本记录

| 日期 | 版本 | 变更 |
|------|------|------|
| 2026-06-20 | v1.0 | 初版创建：基于竞赛工作流包和定时任务自动化包的打包实践 |
