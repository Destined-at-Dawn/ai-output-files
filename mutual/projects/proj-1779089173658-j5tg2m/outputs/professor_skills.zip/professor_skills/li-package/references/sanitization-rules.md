# li-package 脱敏规则表

> 铁律：交付前必须全量脱敏。没有「这次内容很简单不用脱」的例外。
> 脱敏是一次性全量操作，不是分批操作（教训 008）。

---

## 一、脱敏关键词表

### T1 致命级（出现 = 禁止交付，必须替换）

| 关键词 | 类型 | 替换为 | 正则模式 |
|--------|------|--------|---------|
| `小黎` | 姓名 | `{USER_NAME}` | `小黎` |
| `李兰源` | 姓名 | `{USER_NAME}` | `李兰源` |
| `兰源` | 姓名 | `{USER_NAME}` | `兰源` |
| `13975` | 用户 ID | `{USER_ID}` | `13975` |
| `C:\Users\13975` | 本地路径 | `{USER_HOME}` | `C:\\\\Users\\\\13975\|C:/Users/13975` |
| `E:\ai产出文件\牛马` | 工作区路径 | `{WORKSPACE_ROOT}` | `E:\\\\ai产出文件\\\\牛马\|E:/ai产出文件/牛马` |
| `E:\ai产出文件` | 工作区路径 | `{WORKSPACE_ROOT}` | `E:\\\\ai产出文件\|E:/ai产出文件` |
| `.newmax` | 平台路径 | `{NEWMAX}` | `\.newmax` |
| `3.896` | GPA | `{GPA}` | `3\.896` |
| `3.9/4.0` | GPA | `{GPA}` | `3\.9/4\.0` |
| `上海电力大学` | 学校 | `{UNIVERSITY}` | `上海电力大学` |
| `上电` | 学校简称 | `{UNIVERSITY}` | `上电(?!网)` |
| `SUEP` | 学校英文 | `{UNIVERSITY}` | `SUEP` |
| `威泊` | 实习公司 | `{COMPANY}` | `威泊` |
| `D:\study` | 学习路径 | `{STUDY_ROOT}` | `D:\\\\study\|D:/study` |
| `F:\work` | 工作路径 | `{WORK_ROOT}` | `F:\\\\work\|F:/work` |

### T2 重要级（出现 = 需人工判断是否替换）

| 关键词 | 类型 | 处理方式 |
|--------|------|---------|
| `上交` / `东南` | 目标院校 | 替换为 `{TARGET_SCHOOL}` 或保留（看场景） |
| `常州市局` / `国网` | 职业目标 | 替换为 `{TARGET_EMPLOYER}` 或保留 |
| `集创赛` / `ICAN` | 竞赛名 | 通用化为「某竞赛」或保留 |
| `wxid_` / 微信 ID | 社交账号 | 删除 |
| `飞书` / `feishu.cn` | 飞书链接 | 判断是否为内部链接，是则删除 |
| `牛马AI` / `牛马` | 平台名 | 视客户群体决定是否保留 |
| `opc` / `OPC` | 社群名 | 替换为 `{COMMUNITY}` 或保留 |
| `niuma-voice-dna` | Skill 名 | 保留（产品名称，非个人信息） |
| `li-improve` / `li-*` | Skill 名 | 保留 |

### T3 注意级（检查即可）

| 关键词 | 类型 | 处理方式 |
|--------|------|---------|
| `git config` 中的 user.name/email | Git 配置 | 确认用公开信息 |
| GitHub token / API key | 凭证 | 绝对禁止出现 |
| `.env` 文件 | 环境变量 | 绝对禁止打包 |
| `memory/` 目录 | 记忆文件 | 绝对禁止打包 |

---

## 二、路径占位符映射表

| 原始路径 | 占位符 | 说明 |
|---------|--------|------|
| `E:\ai产出文件\牛马\创作\创作\` | `{WORKSPACE_ROOT}\` | 创作工作区根目录 |
| `C:\Users\13975\.newmax\` | `{NEWMAX_HOME}\` | Newmax 配置目录 |
| `C:\Users\13975\.newmax\skills\` | `{SKILLS_HOME}\` | Skill 安装目录 |
| `C:\Users\13975\` | `{USER_HOME}\` | 用户主目录 |
| `F:\work\` | `{WORK_ROOT}\` | 工作目录 |
| `F:\work\接单\` | `{WORK_ROOT}\接单\` | 接单工作区 |
| `D:\study\` | `{STUDY_ROOT}\` | 学习资料目录 |
| `E:\ai产出文件\牛马\个人\个人\百大认知书籍\` | `{COGNITION_BOOKS}\` | 百大认知书籍目录 |
| `E:\ai产出文件\牛马\日常学习\study-review-kit\` | `{STUDY_REVIEW_KIT}\` | study-review-kit 目录 |

---

## 三、文件级黑名单（禁止出现在任何交付包中）

```
memory/                    # 记忆文件（含对话记录、个人信息）
.newmax/                   # 平台配置
.telos/                    # 个人身份档案
*.env                      # 环境变量
.env.*                     # 环境变量变体
credentials*               # 凭证文件
secrets*                   # 密钥文件
CLAUDE.md                  # 工作区配置（含路径、个人规则）
AGENT.md                   # Agent 配置
AGENTS.md                  # Agent 配置（除非是专门为客户准备的）
*.log                      # 日志文件
.git/                      # Git 历史
__pycache__/               # Python 缓存
node_modules/              # Node 依赖
*.pyc                      # Python 字节码
```

---

## 四、脱敏脚本接口

```python
def sanitize_file(file_path: str, rules: list[SanitizationRule]) -> SanitizationResult:
    """
    对单个文件执行全量脱敏。

    参数：
        file_path: 文件路径
        rules: 脱敏规则列表（从本文件加载）

    返回：
        SanitizationResult:
            - replacements: int (替换总次数)
            - by_category: dict (按类别统计)
            - remaining_issues: list (二次扫描残留问题)
            - passed: bool (零残留 = True)
    """
```

---

## 五、脱敏日志格式

每次脱敏操作必须生成日志：

```
脱敏日志 - {产品名}
执行时间：{YYYY-MM-DD HH:MM}
规则版本：sanitization-rules v1.0

文件：{文件路径}
  [T1] 路径：E:\ai产出文件\ -> {WORKSPACE_ROOT} (3次)
  [T1] 人名：小黎 -> {USER_NAME} (2次)
  [T2] 学校：上海电力大学 -> {UNIVERSITY} (1次)
  合计：6次替换

二次扫描：OK（零残留）
```
