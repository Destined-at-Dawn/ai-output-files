# Content Creation Toolbox (Mode B)

> From li-content Mode B. Commercial commentary + viral topic cards.

# Mode B: Content Creation Toolbox

## B.1: Commercial Commentary

Long-form business commentary in dontbesilent's cold/philosophical style with iterative rule optimization.

### Folder Structure

| Path | Purpose |
|:---|:---|
| 1_prompts/v{n}.md | Version n writing style rules |
| 2_outputs/v{n}/output_xx.md | Outputs from version n rules |
| 3_feedback/v{n}_feedback.md | Human feedback on version n |
| golden_rules.md | Permanent rules from all feedback |

### Skills

**Initialize**: Check existing -> create folders -> v1.md + golden_rules.md
**Generate**: Read latest rules + golden_rules -> ask topic -> generate -> save + feedback template
**Iterate**: Evaluate all versions/feedback -> distill rules -> create v{n+1}.md
**Status**: Scan versions, feedback status, golden_rules count

### Workflow
```
Initialize -> Generate -> Feedback -> Iterate -> Generate -> ...
```

### Constraints
- Never delete historical version files
- Always follow dontbesilent style: sharp, counter-intuitive, colloquial, pain-point focused, metaphorical
- Read golden_rules.md before writing

## B.2: Viral Topic Cards

Mine the dontbesilent tweet library for viral topic cards.

### Usage
```
Viral topics: [theme]  -> Generate based on theme
Viral topics: random   -> Random generation
```

### Flow: Theme Mode

1. Search tweet library for theme, select 3-5 most relevant
2. Process: found -> read full content; not found -> recommend closest
3. Extract core viewpoint: common themes -> sharp/counter-intuitive/colloquial
4. Match viral framework:

| Viewpoint Feature | Content Pillar |
|---|---|
| Challenge common sense | Cognitive disruption |
| Specific method | Methodology/case |
| Reveal truth | Insider info |
| Simplify path | Shortcuts/tools |
| Critique phenomena | Event-driven + satire |

5. Generate topic card in standard format

### 5 Content Pillars

1. **Cognitive Disruption**: counter-intuitive断言 / commands / reattribution
2. **Methodology/Cases**: result-oriented / quick-start tutorials
3. **Insider Info**: dramatic numbers / "victim" confessions
4. **Shortcuts/Tools**: shortcut commands
5. **Event-Driven + Satire**: "I" + verb + "big shots/strange phenomena"

### Output Format
```
[Topic Card]
- Content Pillar: [...]
- Viral Formula: [...]
- Core Viewpoint: [...]
- Title Ideas: 1. ... 2. ... 3. ...
- Source: [Tweet #XXX] "..."
```

### Absolute Principles

1. Must quote original text
2. Viewpoints must be sharp
3. Titles must be specific
4. Match dontbesilent style
5. Topics must have value