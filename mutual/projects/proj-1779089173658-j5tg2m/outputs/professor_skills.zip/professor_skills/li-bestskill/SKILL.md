---
name: li-bestskill
version: "1.0"
description: li系列 · 技能雷达，搜索外部最佳skill方案并评估
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/matching-algorithm.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[搜索外部技能] -> **必须** `Read references/platform-search-guide.md`
- 场景[安全审查] -> **必须** `Read references/security-review.md`
- 场景[参考案例] -> **必须** `Read references/case-studies.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/matching-algorithm.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-bestskill — 技能雷达

> 版本：v1.3 | 创建：2026-06-05 | 更新：2026-06-08
> 系列：li（小黎自有工具）第 3 个
> 定位：跨平台自动发现 skill/MCP/prompt，个性化推荐 + 安全审查
> v1.1：用户指定 5 大平台 + 每日 MD 保存 + 学员分享模式
> v1.3：Progressive Disclosure 架构，细节移入 references/

---

## 为什么需要这个技能

**问题**：skills.sh 有 61,000+ skill，awesome-claude-skills 收录 10,111 个，但你根本不知道哪个好、哪个适合你。手动搜索 = 大海捞针。

**解法**：技能雷达自动从 12+ 平台采集，结合你的画像（IC/EE、考研、小红书、FPGA）打分推荐。每周六中午 12 点生成 HTML 周报。

**认知科学锚定**：
- 018-算法之美：探索-利用权衡 —— 80% 推荐已知好用的，20% 推荐新发现的
- 060-稀缺：带宽税理论 —— 用户没有精力筛选 61,000 个 skill，雷达代行筛选
- 013-精要主义：更少但更好 —— 每周只推荐 Top 5-10，不堆砌

---


## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |

## 触发条件

**显式触发**："有什么新技能"、"推荐skill"、"最新MCP"、"技能更新"、"找一下有没有xxx的skill"

**隐式触发**：本地 198 个 skill 都不匹配用户需求；用户安装新 skill 后（触发"相关推荐"）

**手动调用**：`/li-bestskill`

---

## 执行流程（骨架）

> 每个 Phase 的详细步骤见 references/ 目录对应文件。

### Phase 1：画像加载（10 秒）

读取 `~/.newmax/user-profile.md`（li-manage 维护），获取身份标签、工作流标签、已安装清单（198 个）、痛点标签、学习偏好。

### Phase 2：多平台采集（核心）

- 12+ 数据源，P0-P3 四级优先级
- 三大搜索场景：灵感发现 / 具体需求 / 探索发现
- 四阶段搜索：宽泛全局 → 中文生态 → 社区论坛 → 精确补充
- 搜索铁律：全平台 × 宽泛关键词 × 质量排序，三者缺一不可

**详细搜索策略**：`references/platform-search-guide.md`

### Phase 3：安全审查（强制，不可跳过）

- 7 点安全检查清单（来源/代码/版本/Schema/权限/隔离/回滚）
- 安全评级：A 级直接推荐 / B 级标注风险 / C 级仅参考 / D 级黑名单
- MCP 供应链攻击防护（9 类威胁模型）

**详细安全审查**：`references/security-review.md`

### Phase 4：个性化匹配

```
score = base_score * relevance * freshness * safety
```

- base_score：基于平台可信度（GitHub stars、安装量等）
- relevance：与用户画像标签匹配度（完全匹配 x1.5 / 重复 x0.2）
- freshness：更新时效（7 天内 x1.3 / 90 天+ x0.5）
- safety：安全评级系数（A x1.0 / D x0 直接过滤）

**用户画像标签体系**：`references/matching-algorithm.md`

### Phase 5：输出格式

**即时推荐**（对话中触发）：
```
技能名 + 安全评级 + 来源平台 + 匹配度 + 安装命令 + 与现有 skill 的关系
```

**每周六 HTML 周报**（定时任务，每周六中午 12:00）：
内容 = Top 10 新发现 + 热门趋势 + 匹配 MCP + 安全警报 + 个性化建议
输出到 `outputs/li-bestskill-weekly-{date}.html`

### Phase 6：每日 MD 保存（用于学员分享）

- 位置：`~/.newmax/skills/li-bestskill/platforms/daily-discoveries/{YYYY-MM-DD}.md`
- 内容：今日新发现表格 + 安全审查记录 + 个性化推荐
- 学员分享模式：脱敏处理后输出可发送版本

---

## 数据源矩阵（摘要）

| 优先级 | 平台 | 类型 | 采集方式 |
|--------|------|------|---------|
| **P0** | skills.sh / awesome-claude-skills / MCP Registry | Skill 目录(61K+/10K+/官方) | CLI / REST / HTTP |
| **P1** | ToolSDK / Agent Skills Hub / mcpm.sh | MCP(4547+) / 聚合(25K+) / 开源 | HTTP / WebFetch |
| **P2** | browse.sh / AIHOT / Higress MCP | 浏览器技能(200+) / 资讯 / 企业 MCP | HTTP / WebFetch |
| **P3** | OpenClaw / 腾讯 SkillHub / mcpmarket | Agent Hub / 云社区 / 应用商店 | WebFetch |

**用户指定 5 大核心平台**（P0 优先级）：
AIHot Skill Hub / Browse.sh / Agent Skills Hub / OpenClawMP（阶跃星辰）/ 腾讯 SkillHub

提交新技能入口：https://aihot.virxact.com/submit

---

## 生态副作用（创建/更新本技能后的连锁操作）

1. 更新 `skill-routing-table.json`：添加 li-bestskill 路由
2. 更新 `li/SKILL.md`：注册到 li 系列路由入口
3. 更新 `li-local-search/SKILL.md`：添加到品牌路由层
4. 记录到 `memory/{today}.md`：创建时间 + 设计决策
5. 登记到 `artifact-registry.md`：可复用产出

---

## 联动技能

| 技能 | 联动方式 | 说明 |
|------|---------|------|
| li-skillcreate | 下游 | 发现好 skill → 本地化改造 |
| li-manage | 上游 | 获取用户画像和工作流数据 |
| li-local-search | 并行 | 搜本地 vs 搜外部 |
| li-devil | 内置 | 推荐前做泼冷水审查 |
| deep-research | 辅助 | 深度调研 skill 时提供平台数据 |
| li-skillfusion | 下游 | 发现重复 skill → 融合或标记弃用 |

---

## 绝对禁止清单（Top 5）

| # | 禁止行为 | 为什么 |
|---|---------|--------|
| 1 | 不做安全审查就推荐 | 恶意 skill 可能窃取数据或注入指令 |
| 2 | 不搜本地就推荐外部 | 80% 需求本地已有解决方案 |
| 3 | 一次性推荐 10+ 个 skill | 选择过载 → 用户什么都记不住 |
| 4 | 推荐没读过源码的 skill | 你不知道它真正做了什么 |
| 5 | 只看 stars 数不看兼容性 | 高星 skill 可能与用户环境不兼容 |

---

## 条件式下一步推荐

| 发现结果 | 推荐 skill | 话术 |
|----------|-----------|------|
| 找到完美匹配的外部 skill | li-skillcreate | "找到了！要本地化改造一下吗？" |
| 发现本地已有类似 skill | li-local-search | "你本地已经有 {skill} 能做这个。" |
| 发现多个重复 skill | li-skillfusion | "你有 N 个功能重叠的 skill，要融合一下吗？" |
| 用户选择困难 | li-mindcoach | "选择太多了？先理清你真正需要什么。" |
| 找到的 skill 需要深度调研 | li-research | "这个 skill 背后的平台值得深度调研。" |

---

## 与 dbs 系列的设计对齐

- **路由器模式**：li-bestskill 是发现层，不做安装（安装由用户确认或 li-skillcreate 执行）
- **安全审查**：类似 dbs-ai-check 的"只诊断不改"——只推荐不自动安装
- **个性化**：类似 dbs-diagnosis 的"问诊"模式——先了解需求，再推荐

---

## 文件结构

```
li-bestskill/
├── SKILL.md                       ← 本文件（骨架，≤300 行）
├── references/
│   ├── case-studies.md            ← 真实案例（正面 + 反面）
│   ├── platform-search-guide.md   ← 平台搜索详细策略
│   ├── security-review.md         ← 安全审查详细清单
│   └── matching-algorithm.md      ← 匹配算法 + 用户画像标签
├── platforms/
│   ├── registry.json              ← 平台注册数据（URL/API/状态）
│   ├── top-skills-catalog.md      ← 热门 skill 分类目录
│   └── aihot/                     ← AIHOT 平台数据
├── security/
│   ├── checklist.md               ← 7点安全检查清单
│   ├── audit-template.md          ← 安全审查模板
│   └── blacklist.md               ← 已知恶意 skill 黑名单
├── eval.json                      ← 技能评估断言
└── README.md                      ← 用户使用说明
```


## 案例库

| # | 案例 | 场景 | 结果 | 关键教训 |
|---|------|------|------|---------|
| 1 | 发现 li-hardware | 用户说"FPGA 相关技能"，li-bestskill 四阶段搜索发现 Verilog-AI(356★)，安全审查 A 级，推荐给 li-skillcreate 本地化改造 | 创建 li-hardware skill，触发词 18 个，路由命中率 85% | 搜到好 skill 不是终点——交给 li-skillcreate 本地化改造才是完整闭环 |
| 2 | 搜索策略升级 | v1 只搜 skills.sh，结果偏少；v2 加入 GitHub 全局搜索（按 Stars 降序，不限定 claude/skill），发现 Letta(23.2K★) 等顶级项目 | 搜索覆盖面从 1 个平台扩展到 12+，推荐质量提升 3 倍 | 关键词太窄 = 只找到小圈子；宽泛搜索 + Stars 排序 = 发现真正好的项目 |
| 3 | 低星搜索教训 | 搜 `claude-code self-improving skill` 只找到 13★ 的项目；换成 `self-improving agent` 找到 23.2K★ 的 Letta | 搜索结果质量从"无人问津"到"行业标杆" | 精确匹配搜灵感是反模式；宽泛关键词才能跨出小圈子 |

> 详细案例 → `references/case-studies.md`

## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 精确匹配搜灵感 | 只找到小圈子（<13★） | 宽泛关键词 + 全平台 |
| 2 | 只搜 GitHub | 漏掉 skills.sh（61K+）| 四阶段全覆盖 |
| 3 | 结果最高 <100★ 不自检 | 关键词太窄 | 换更宽泛的词重搜 |
| 4 | 只看 README 不读 SKILL.md | 不了解实际实现 | 读 Top 3 完整文件 |
| 5 | 不检查安全问题 | 引入恶意代码 | Phase 3 安全审查强制 |
| 6 | 不按 Stars 排序 | 低质量结果混在前面 | GitHub 搜索加 `&s=stars&o=desc` |
| 7 | 不搜本地就推荐外部 | 80% 需求本地已有方案 | Phase 1 先加载已安装清单（198 个） |


## Case Studies

### Case 1: 搜索策略从 GitHub-only 到全平台（2026-06-08）
- **场景**: 搜索 self-improving skill，只搜 GitHub 只找到 13 star 项目
- **结果**: 改为四阶段搜索（宽泛 GitHub -> skills.sh -> MCP Registry -> 社区），找到 23.2K star 项目
- **教训**: 搜索范围窄 = 信息茧房，宽泛关键词 + 全平台是铁律
- **Source**: memory/2026-06-08.md

### Case 2: skills.sh 61K+ skill 生态发现（2026-06-07）
- **场景**: 首次系统性搜索 Claude Code skill 生态
- **结果**: 发现 61K+ skill 的 skills.sh 平台，比 GitHub 搜索更专业
- **教训**: 不同平台有不同擅长领域，不能只搜一个

### Case 3: peterskoett/self-improving-agent（641 star）的 hook 机制（2026-06-08）
- **场景**: 搜索 self-improving 类 skill，发现 hook 驱动激活
- **结果**: 吸收了 activator.sh 和递归度追踪机制到 li-improve
- **教训**: 搜索不只是找替代品，而是找可以吸收的机制

## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-skillcreate** | 搜索后创建新 skill | "没有现成的，自己造" |
| **li-skillfusion** | 搜索后融合到现有 skill | "融合进 li- 系列" |
| **li-research** | 深度技术调研 | "深入研究这个 skill 的原理" |
| **li-local-search** | 本地查重 | "本地有没有类似的" |

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |


## 注意事项 & 条件下一步

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈写入golden_rules.md；触发词必须和其他li-skill正交
4. 搜到高质量外部skill → 对比表 → li-skillcreate；用户说"不好用" → 读golden_rules修正
