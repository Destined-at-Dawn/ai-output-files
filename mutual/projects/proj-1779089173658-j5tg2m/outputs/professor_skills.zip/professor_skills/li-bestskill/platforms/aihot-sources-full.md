# AIHOT 信源完整列表

> 来源：aihot.virxact.com/submit
> 保存时间：2026-06-05
> 用途：AI 信息提取 skill 和自动化任务的信源基础

---

## 一、AIHOT 主站
- https://aihot.virxact.com/aihot-skill/ — AIHOT 技能库
- https://aihot.virxact.com/submit — 技能提交入口

## 二、技能发现平台
| 平台 | URL | 规模 |
|------|-----|------|
| SkillsMP | https://skillsmp.com/zh | 1.64M+ SKILL.md |
| skills.pub | https://skills.pub/zh | 1,700+ |
| agentskillshub.top | https://agentskillshub.top | 55,000+ repos |
| awesomeskill.ai | https://awesomeskill.ai/ | — |
| claudemod.com | https://www.claudemod.com/browse | — |
| skills.fan | https://www.skills.fan/docs/using-skills/manage-skills | — |
| claudeskills.cc | https://claudeskills.cc/tutorials | — |
| skl.bz | https://skl.bz/skill/news-aggregator-skill | — |
| buildwithclaude.com | https://buildwithclaude.com/marketplaces | — |
| claude-plugins.dev | https://claude-plugins.dev/skills | — |
| OpenClaw | https://openclawmp.cc | 15,725+ |
| clawskills.site | https://clawskills.site/ | — |
| browse.sh | https://browse.sh/ | — |
| stepfun openclaw | https://openclawmp.stepfun.com/explore | — |
| tencent skillhub | https://skillhub.cloud.tencent.com/ | — |

## 三、GitHub 精选仓库
| 仓库 | Stars | 链接 |
|------|-------|------|
| awesome-claude-skills (travisvn) | 13.2k | https://github.com/travisvn/awesome-claude-skills |
| superpowers (obra) | 40.9k | https://github.com/obra/superpowers |
| marketingskills (coreyhaines31) | 12.9k | https://github.com/coreyhaines31/marketingskills |
| karpathy-skills (multica-ai) | 144k | https://github.com/multica-ai/andrej-karpathy-skills |
| awesome-mcp-servers (punkpeye) | 最大合集 | https://github.com/punkpeye/awesome-mcp-servers |
| claude-code-skills-zh | — | https://github.com/laolaoshiren/claude-code-skills-zh |
| xiaohongshu-skills (vivy-yi) | — | https://github.com/vivy-yi/xiaohongshu-skills |
| ai-workflow (nicepkg) | — | https://github.com/nicepkg/ai-workflow |
| awesome-skills (gmh5225) | — | https://github.com/gmh5225/awesome-skills |

## 四、MCP 生态
| MCP 列表 | 链接 |
|----------|------|
| awesome-mcp-servers (punkpeye) | https://github.com/punkpeye/awesome-mcp-servers/ |
| awesome-mcp-servers (hustcc) | https://github.com/hustcc/awesome-mcp-servers |
| mcp.so | https://github.com/chatmcp/mcpso |
| MCP Registry | https://github.com/toolsdk-ai/awesome-mcp-registry |
| mcp.aibase.com | https://mcp.aibase.com/ |

## 五、中文内容生态技能
| 技能 | 平台 | 链接 |
|------|------|------|
| humanizer-zh | GitHub | https://github.com/op7418/humanizer-zh |
| wechat-writing-skill | GitHub | https://github.com/Qson8/wechat-writing-skill |
| content-pipeline | GitHub | https://github.com/OrangeViolin/content-pipeline |
| content-collector-skill | GitHub | https://github.com/vigorX777/content-collector-skill |
| TrendRadar | GitHub | https://github.com/sansan0/TrendRadar |
| Claude-to-IM-skill | GitHub | https://github.com/op7418/Claude-to-IM-skill |
| Wechatsync | GitHub | https://github.com/wechatsync/Wechatsync |
| xhs-images | GitHub | https://github.com/manwithshit/xhs-images |
| xiaohongshu-mcp | GitHub | https://github.com/xpzouying/xiaohongshu-mcp |
| wenyan-mcp | GitHub | https://github.com/caol64/wenyan-mcp |

---
*下次扫描时间：2026-06-12（周六中午 12:00）*
