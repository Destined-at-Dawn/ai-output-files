# 热门 Skills 目录（Top 20 + 分类框架）

> 来源：awesome-claude-skills + skills.sh + Agent Skills Hub
> 更新日期：2026-06-05
> 用途：li-bestskill 推荐参考 + 百大认知分析素材

---

## 2026 年热门 Skills Top 20

| # | 名称 | 安装量/Stars | 类别 | 安全评级 | 小黎匹配度 |
|---|------|-------------|------|---------|-----------|
| 1 | vercel-react-best-practices | 223.8K/周 | 前端最佳实践 | 🟢A | 🟡中 |
| 2 | web-design-guidelines (Vercel) | 177.9K/周 | UI设计规范 | 🟢A | 🟡中 |
| 3 | frontend-design (Anthropic) | 172.8K/周 | 前端设计 | 🟢A | 🟡中 |
| 4 | remotion-best-practices | 155K/周 | 视频开发 | 🟢A | 🟢高(视频创作) |
| 5 | Grill Me (Matt Pocock) | 156.2K总 | 编码前质询 | 🟢A | 🟢高(决策质量) |
| 6 | Karpathy's Guidelines | 144K | 编码四原则 | 🟢A | ✅已装 |
| 7 | Caveman | 68.1K | Token压缩65% | 🟢A | 🟢高(省token) |
| 8 | Superpowers (obra) | 61.9K | 多Agent工作流 | 🟢A | 🟢高(项目管理) |
| 9 | Context Mode | 16.3K | 会话状态恢复 | 🟡B | 🟢高(跨对话) |
| 10 | colleague-skill | 5.4K(3天) | 复刻沟通风格 | 🟡B | 🟡中 |
| 11 | ui-ux-pro-max-skill | 16.9K | 多平台UI/UX | 🟡B | 🟡中 |
| 12 | Corey Haines Marketing | 12.9K | 32个营销技能 | 🟡B | 🟢高(小红书) |
| 13 | GitNexus | 23.4K | 代码知识图谱 | 🟡B | 🟡中 |
| 14 | planning-with-files | 9.7K | Markdown规划 | 🟡B | ✅类似已有 |
| 15 | UniversalCodeReviewer | 4.8K | 跨语言代码审查 | 🟡B | 🟡中 |
| 16 | Handoff (Matt Pocock) | — | 会话交接文档 | 🟡B | 🟢高(上下文) |
| 17 | Firecrawl | — | 网页抓取 | 🟡B | 🟢高(调研) |
| 18 | Trail of Bits Security | — | 安全审计 | 🟢A | 🟡中 |
| 19 | Document Skills (Anthropic) | — | PDF/DOCX/XLSX | 🟢A | ✅类似已有 |
| 20 | Skill Creator (Anthropic) | — | 交互式构建Skills | 🟢A | ✅li-skillcreate |

---

## 分类框架

### 1. 开发工作流
- TDD、代码审查、规划、调试
- 代表：Superpowers, UniversalCodeReviewer, planning-with-files

### 2. 前端/UI
- 设计规范、React 最佳实践、UI/UX
- 代表：frontend-design, vercel-react-best-practices, web-design-guidelines

### 3. 文档处理
- Office 文件创建/解析、PDF、Markdown
- 代表：Document Skills, PDF Master, baoyu-markdown-to-html

### 4. 网页自动化
- 抓取、搜索、浏览器操控
- 代表：Firecrawl, browse.sh, web-access

### 5. 安全审计
- 漏洞检测、代码安全、供应链安全
- 代表：Trail of Bits Security

### 6. 营销/内容
- SEO、文案、社交媒体、小红书
- 代表：Corey Haines Marketing, xhs-content-strategist

### 7. 代理编排
- 多 Agent 协作、会话管理
- 代表：Superpowers, Handoff, Context Mode

### 8. 编码行为
- 编码规则、输出优化、token 压缩
- 代表：Karpathy's Guidelines, Caveman, Grill Me

### 9. 会话管理
- 压缩、交接、状态恢复、记忆
- 代表：Context Mode, Handoff, session-summary

### 10. 元技能
- 生成/优化/管理 Skills
- 代表：Skill Creator, li-skillcreate, find-skills

---

## 与小黎画像的匹配分析

### 高优先推荐（待安装）

| Skill | 匹配理由 | 安全评级 | 建议 |
|-------|---------|---------|------|
| Caveman | Token压缩65%，节省上下文 | 🟢A | 建议安装试用 |
| Superpowers | 多Agent工作流，提升并行效率 | 🟢A | 建议安装试用 |
| Grill Me | 编码前质询，减少盲目执行 | 🟢A | 与li-devil互补 |
| Handoff | 会话交接文档，解决跨对话上下文 | 🟡B | 与li-manage互补 |
| Firecrawl | 网页抓取，增强调研能力 | 🟡B | 与deep-research互补 |
| Corey Haines | 32个营销技能，增强小红书变现 | 🟡B | 需审查具体内容 |

### 已覆盖（不需要重复安装）

| Skill | 本地对应 |
|-------|---------|
| Karpathy's Guidelines | ✅ karpathy-guidelines (5工作区已装) |
| Document Skills | ✅ pdf/xlsx/docx skills |
| Skill Creator | ✅ li-skillcreate |
| planning-with-files | ✅ writing-plans |

---

## 百大认知视角：为什么这些 skill 火？

**018-算法之美**：探索-利用权衡 —— 热门 skill 是"利用"阶段的最优解（经过大量用户验证）

**006-原子习惯**：习惯四大定律 —— 好 skill 降低"让它显而易见"的门槛（自动触发）和"让它令人愉悦"的门槛（好用的输出格式）

**025-认知负荷理论**：图式自动化 —— Caveman（token压缩）和 Context Mode（状态恢复）本质上都在减少认知负荷

**013-精要主义**：更少但更好 —— Grill Me 的核心价值是"在开始前质疑是否需要做"，这正是精要主义的实践

**046-反脆弱**：杠铃策略 —— Superpowers 的多 Agent 模式天然支持杠铃：80% 保守 Agent + 20% 激进探索 Agent
