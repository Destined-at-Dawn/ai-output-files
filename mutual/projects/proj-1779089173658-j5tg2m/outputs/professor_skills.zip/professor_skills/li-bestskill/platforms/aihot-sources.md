# AI HOT 信源列表（aihot.virxact.com/submit）

> 来源：用户粘贴自 aihot.virxact.com/submit 页面
> 采集日期：2026-06-05
> 用途：li-bestskill 信源参考 + AI 热点追踪

---

## 一、职场、自媒体系列

| # | 名称 | GitHub 链接 | 简介 |
|---|------|------------|------|
| 1 | 同事.skill | https://github.com/titanwings/colleague-skill | 把真实同事蒸馏成AI（SKILL流火爆起点） |
| 2 | 女娲.skill | https://github.com/alchaincyf/nuwa-skill | 能自动蒸馏任何人的终极工具（想蒸谁蒸谁） |
| 3 | X导师.skill | https://github.com/alchaincyf/x-mentor-skill | X/Twitter运营导师，能分析账号数据、写推文、给诊断报告 |
| 4 | 老板.skill | https://github.com/vogtsw/boss-skills | 把老板炼入token，把生产力的解放留给自己 |
| 5 | 前任.skill | https://github.com/therealXiaomanChu/ex-skill | 把前任蒸馏成 AI Skill，用ta的方式跟你说话 |
| 6 | 自己.skill | https://github.com/notdog1998/yourself-skill | 把你自己蒸馏成AI，数字永生/第二大脑 |
| 7 | 博主.skill | https://github.com/YourongZhou/chat_with_me | 把公开社交媒体语料整理成Persona Skill（支持推特和小红书） |
| 8 | 蒸馏.skill | https://github.com/YIKUAIBANZI/forge-skill | 人格蒸馏引擎，蒸馏自己看清自己，蒸馏亲友留住余温与回声 |
| 9 | 反蒸馏.skill | https://github.com/leilei926524-tech/anti-distill | 公司让你写Skill文档时"投毒"，核心知识自己留着（打工人自保神器） |

---

## 二、名人系列

| # | 名称 | GitHub 链接 | 简介 |
|---|------|------------|------|
| 10 | 乔布斯.skill | https://github.com/alchaincyf/steve-jobs-skill | 思维模型 + 现实扭曲力场 + 决策风格 |
| 11 | 马斯克.skill | https://github.com/alchaincyf/elon-musk-skill | 第一性原理、硬核执行力、推文风格 |
| 12 | 芒格.skill | https://github.com/alchaincyf/munger-skill | 多元思维模型、反向思考、投资决策神器 |
| 13 | 费曼.skill | https://github.com/alchaincyf/feynman-skill | 教你怎么讲课、拆解复杂问题、讲物理/学习方法 |
| 14 | 纳瓦尔.skill | https://github.com/alchaincyf/naval-skill | 财富、幸福、人生哲学，播客级智慧 |
| 15 | 塔勒布.skill | https://github.com/alchaincyf/taleb-skill | 黑天鹅、反脆弱、风险评估专家 |
| 16 | 张雪峰.skill | https://github.com/alchaincyf/zhangxuefeng-skill | 接地气吐槽 + 升学实用建议 |
| 17 | Paul Graham.skill | https://github.com/alchaincyf/paul-graham-skill | 创业思维、写作、产品哲学 |
| 18 | 张一鸣.skill | https://github.com/alchaincyf/zhang-yiming-skill | 算法思维、组织管理、产品迭代 |
| 19 | Karpathy.skill | https://github.com/alchaincyf/karpathy-skill | AI/深度学习教学 + 技术直觉 |
| 20 | Ilya Sutskever.skill | https://github.com/alchaincyf/ilya-sutskever-skill | AI前沿思考 + 模型哲学 |
| 21 | MrBeast.skill | https://github.com/alchaincyf/mrbeast-skill | YouTube现象级创作者，内容病毒式传播 + 增长黑客 |
| 22 | 特朗普.skill | https://github.com/alchaincyf/trump-skill | 谈判风格、推文艺术、现实扭曲（已验证超像） |

---

## 三、玄学系列

| # | 名称 | GitHub 链接 | 简介 |
|---|------|------------|------|
| 23 | 赛博算命.skill | https://github.com/jinchenma94/bazi-skill | 八字排盘与命理分析工具 |
| 24 | 月老·姻缘测算.skill | https://github.com/Ming-H/yinyuan-skills | 姻缘测算技能，用中华传统术数帮你算姻缘 |
| 25 | 奇门遁甲、紫微斗数.skill | https://github.com/FANzR-arch/Numerologist_skills | 减少幻觉、固定排盘步骤的奇门遁甲与紫微斗数 AI skills |
| 26 | 大师.skill | https://github.com/xr843/Master-skill | 基于佛教经典文献的汉传祖师大德教学角色生成器 |

---

## 统计

- 总计：26 个 AI 信源
- 职场/自媒体：9 个
- 名人系列：13 个
- 玄学系列：4 个

## 关键观察

1. **蒸馏类 skill 是当前最火品类**：同事/女娲/自己/前任/蒸馏/反蒸馏 = 6 个，占总数 23%
2. **alchaincyf 是最大 skill 作者**：名人系列 13 个中 12 个出自同一作者
3. **名人 skill 潜力巨大**：张雪峰（升学）、纳瓦尔（财富）、芒格（投资）对小黎有直接价值
4. **玄学赛道意外热门**：4 个玄学 skill 说明"赛博算命"是真实需求
