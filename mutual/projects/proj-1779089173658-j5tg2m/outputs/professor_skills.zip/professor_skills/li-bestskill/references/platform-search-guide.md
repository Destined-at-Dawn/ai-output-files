# 平台搜索详细指南

> li-bestskill Phase 2 的完整搜索策略。SKILL.md 仅保留骨架，本文件包含全部细节。
> 更新日期：2026-06-08

---

## 数据源完整矩阵

| 优先级 | 平台 | URL | 类型 | API | 采集方式 |
|--------|------|-----|------|-----|---------|
| **P0** | skills.sh | skills.sh | Skill 目录(61K+) | `npx skills find` | CLI |
| **P0** | awesome-claude-skills | github.com/anthropics/skills | GitHub 目录(10K+) | GitHub API | REST |
| **P0** | MCP Registry | modelcontextprotocol.io/registry | 官方 MCP(Preview) | REST API | HTTP |
| **P1** | ToolSDK Registry | toolsdk.ai/mcp | MCP(4547+) | JSON-RPC | HTTP |
| **P1** | Agent Skills Hub | agentskillshub.top | 聚合(25K+) | 无公开API | WebFetch |
| **P1** | mcpm.sh | mcpm.sh | 开源 MCP 注册表 | 开源 | WebFetch |
| **P2** | browse.sh | browse.sh | 浏览器技能(200+) | llms.txt | HTTP |
| **P2** | AIHOT | aihot.virxact.com | AI 资讯 API | REST(无需Key) | HTTP |
| **P2** | Higress MCP | github.com/alibaba/higress | 阿里企业 MCP(50+) | 网关API | HTTP |
| **P3** | OpenClaw | openclawmp.stepfun.com/explore | 阶跃星辰 Agent Hub | 待确认 | WebFetch |
| **P3** | 腾讯 SkillHub | skillhub.cloud.tencent.com | 腾讯云社区 | 待确认 | WebFetch |
| **P3** | mcpmarket | mcpmarket.com | MCP 应用商店 | 无 | WebFetch |

---

## 用户指定的 5 大核心平台（P0 优先级）

> 以下平台由小黎手动筛选，li-bestskill 必须优先监控。

| 平台 | URL | 类型 | 采集方式 |
|------|-----|------|---------|
| **AIHot Skill Hub** | https://aihot.virxact.com/aihot-skill/ | AI 技能聚合 | WebFetch / REST |
| **Browse.sh** | https://browse.sh/ | 浏览器自动化技能 | llms.txt |
| **Agent Skills Hub** | https://agentskillshub.top/best/ | Agent 技能排行 | WebFetch |
| **OpenClawMP（阶跃星辰）** | https://openclawmp.stepfun.com/explore | 官方 MCP/Skill | WebFetch |
| **腾讯 SkillHub** | https://skillhub.cloud.tencent.com/ | 官方技能市场 | WebFetch |

**提交新技能**：https://aihot.virxact.com/submit

---

## 信源文件引用

完整的 AI 信源网站列表保存在：
- 项目级：`公众号/自己/AI信源网站合集.md`（持续性参考资源，位于创作工作区根目录）
- 本 Skill：`references/ai-sources.md`

---

## 三大搜索场景

| 场景 | 触发条件 | 关键词策略 | 搜索范围 |
|------|---------|-----------|---------|
| **灵感发现** | 用户要造新 skill / 融合 / 寻找方案 | 宽泛概念词（`li-improve agent`，不加平台限定） | 全平台（按 P0→P3 优先级） |
| **具体需求** | 用户明确要某功能的 skill（如"思维导图"） | 功能词 + 同义词（`mindmap`, `思维导图`, `thought map`） | 全平台 |
| **探索发现** | 周报/定期扫描，无明确需求 | 各平台热门/trending/新增列表 | 全平台 |

---

## 采集策略

**首次发现**（用 WebFetch 浏览器模式）：
1. 访问平台首页，提取分类和热门列表
2. 下载对应的 SKILL.md / server.json / llms.txt
3. 保存到 `~/.newmax/skills/li-bestskill/platforms/{platform}/`

**后续监控**（直接接入 API）：
1. 用平台 API 定时查询新增/更新
2. 对比上次采集结果，标记差异
3. 每日保存一次到本地 md 文件

**搜索引擎兜底**（WebFetch + mcp__web-search__web_search）

---

## 搜索铁律（2026-06-08 教训）

> 搜索 = **全平台 x 宽泛关键词 x 质量排序**。三者缺一不可。
> 之前只写 GitHub 策略 = 其他 12+ 平台随缘 = 漏掉大部分优质 skill。
> 精确匹配思维 = 过滤掉所有跨生态的高质量项目。

---

## 全平台搜索策略（4 阶段）

```
=== 阶段 1：宽泛全局搜索（必须先做）===
1. GitHub 全局搜索
   - 关键词："{核心概念}" + sort:stars（不加"claude"/"skill"/"MCP"等限定词）
   - 排序：&s=stars&o=desc
   - 看 Top 10，记录 stars、最近更新时间

2. skills.sh 搜索
   - CLI：npx skills find "{关键词}"
   - Web：WebFetch https://skills.sh/search?q={关键词}
   - 排序：默认（按安装量）

3. Agent Skills Hub
   - WebFetch https://agentskillshub.top/best/
   - 按分类浏览 + 关键词搜索

4. MCP Registry + ToolSDK
   - https://modelcontextprotocol.io/registry（官方）
   - https://toolsdk.ai/mcp（4547+ server）
   - 关键词搜索 + 按类型筛选

=== 阶段 2：中文生态搜索（不可跳过）===
5. AIHot Skill Hub
   - WebFetch https://aihot.virxact.com/aihot-skill/
   - 中文关键词优先（"技能"/"工作流"/"自动化"）

6. 腾讯 SkillHub
   - WebFetch https://skillhub.cloud.tencent.com/
   - 搜索功能词

7. 阶跃星辰 OpenClawMP
   - WebFetch https://openclawmp.stepfun.com/explore
   - MCP/Skill 双搜

=== 阶段 3：社区/论坛搜索（补充发现）===
8. GitHub Topics/Discussions
   - github.com/topics/claude-code-skill
   - github.com/topics/mcp-server
   - github.com/topics/ai-agent

9. Reddit / HackerNews
   - site:reddit.com "{关键词}" claude
   - site:news.ycombinator.com "{关键词}"

10. 微信公众号 / 知乎
    - "{关键词}" skill 工具 Claude
    - 中文生态的独特发现

=== 阶段 4：精确补充（宽泛搜索后才用）===
11. "Claude Code skill {核心概念}"
12. "MCP server {功能}"
13. "awesome claude code {关键词}"
```

---

## 各平台质量指标

| 平台 | 质量指标 | "高质"阈值 | 搜索方式 |
|------|---------|-----------|---------|
| GitHub | Stars + 最近更新 | >100 stars（优秀 >1K） | API/搜索，按 stars 排序 |
| skills.sh | 安装量 | >1K 安装（优秀 >10K） | CLI/Web |
| Agent Skills Hub | 排行/评分 | Top 100 | WebFetch 浏览 |
| MCP Registry | 官方认证 | 已验证 > 未验证 | REST API |
| ToolSDK | 下载量 + 评分 | >100 下载 | 搜索 |
| AIHot | 热度 + 收录 | 首页推荐 | WebFetch |
| 腾讯 SkillHub | 官方认证 | 已上架 > 社区 | 搜索 |
| OpenClawMP | 阶跃官方 | 官方 > 社区 | 浏览 |

---

## 搜索质量自检（3 条铁律）

1. **宽泛优先**：先搜核心概念，不加平台限定词。如果结果少（<5 条）或最高星 <100 → 换更宽泛的词重搜
2. **全平台覆盖**：阶段 1-3 都要执行。只搜 GitHub 不搜其他平台 = 漏掉 70% 的优质 skill（skills.sh 有 61K+，GitHub 搜不到的多了去了）
3. **质量质疑**：任何平台的结果都很差（无高星/无好评/无活跃维护）→ 说明搜索词有问题，或者这个领域确实没有成熟方案，需要反馈给用户而不是凑合推荐
