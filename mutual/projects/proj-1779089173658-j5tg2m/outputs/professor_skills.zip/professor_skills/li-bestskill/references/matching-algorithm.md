# 匹配算法与用户画像

> li-bestskill Phase 4 的完整匹配逻辑和用户画像标签体系。SKILL.md 仅保留公式摘要。
> 更新日期：2026-06-08

---

## 匹配算法完整公式

```
final_score = base_score * relevance * freshness * safety * diversity_bonus
```

### base_score（平台可信度）

```
base_score:
  - GitHub stars > 1000 → 0.9
  - GitHub stars > 100 → 0.7
  - GitHub stars > 10 → 0.5
  - 未知来源 → 0.3

  加分项：
  - 官方认证（MCP Registry / GitHub Org verified）→ +0.1
  - 有 lockfile → +0.05
  - 文档完整度 > 80% → +0.05
```

### relevance（与用户画像匹配度）

```
relevance:
  - 标签完全匹配 → ×1.5
  - 标签部分匹配 → ×1.0
  - 新领域（用户未覆盖） → ×0.8（探索价值，Explore-Exploit 中的 Explore）
  - 与已安装 skill 重复 → ×0.2（几乎不推荐，除非新版本有重大改进）
```

### freshness（更新时效）

```
freshness:
  - 7天内更新 → ×1.3
  - 30天内更新 → ×1.0
  - 90天内更新 → ×0.8
  - 90天+未更新 → ×0.5
  - 已归档/只读 → ×0.1（几乎不推荐）
```

### safety（安全评级系数）

```
safety:
  - A级 → ×1.0
  - B级 → ×0.7
  - C级 → ×0.3
  - D级 → ×0（直接过滤，不进入推荐列表）
```

### diversity_bonus（多样性加成）

```
diversity_bonus:
  - 推荐列表中来自不同平台 → ×1.1
  - 推荐列表中覆盖不同功能域 → ×1.05
  - 推荐列表中全部来自同一平台 → ×0.9（避免信息茧房）
```

---

## 排序与过滤规则

1. **过滤**：safety = D 级的直接移除
2. **排序**：按 final_score 降序
3. **截取**：Top 5-10（精要主义：更少但更好）
4. **去重**：同一功能域只保留得分最高的 1 个
5. **探索注入**：每 5 个推荐中至少 1 个来自用户未覆盖的领域（Explore-Exploit）

---

## 用户画像标签体系

```yaml
identity:
  - 大一 IC/EE 上海电力大学
  - GPA 3.9/4.0
  - 威泊机器人研发实习
  - FPGA 硬件开发
  - 具身智能技术储备

work_domains:
  - 小红书变现（电气/AI/学习方向）
  - 公众号创作
  - 考研（上交/东南电气）
  - 竞赛（电赛/集创赛/大创）
  - OPC 超级个体

tech_stack:
  - FPGA/Verilog/VHDL/RTL
  - Python/MATLAB
  - Claude Code/Newmax
  - 飞书 API
  - GitHub

learning_style:
  - 百大认知体系（63本）
  - 认知科学驱动
  - 实操优先于理论
  - 一鱼多吃（一个产出多场景复用）

pain_points:
  - 跨工作区记忆碎片化
  - skill 路由不精准
  - 自动化任务不够智能
  - 新 skill 发现效率低
```

---

## 画像匹配示例

### 示例 1：高匹配

**用户画像**：FPGA 硬件开发 + Python
**发现 skill**：`verilog-lint`（Verilog 静态检查，GitHub 500 stars，A 级）

```
base_score = 0.7 (stars > 100)
relevance = 1.5 (FPGA/Verilog 完全匹配)
freshness = 1.0 (30天内更新)
safety = 1.0 (A级)
final_score = 0.7 * 1.5 * 1.0 * 1.0 = 1.05 → 推荐！
```

### 示例 2：中等匹配

**用户画像**：小红书变现 + 内容创作
**发现 skill**：`seo-optimizer`（SEO 优化，GitHub 200 stars，B 级）

```
base_score = 0.7 (stars > 100)
relevance = 1.0 (内容创作部分匹配)
freshness = 1.0 (30天内更新)
safety = 0.7 (B级)
final_score = 0.7 * 1.0 * 1.0 * 0.7 = 0.49 → 低优先级推荐
```

### 示例 3：重复检测

**用户画像**：已有 `li-review`（代码审查）
**发现 skill**：`code-review-ai`（代码审查，GitHub 1000 stars，A 级）

```
base_score = 0.9 (stars > 1000)
relevance = 0.2 (与 li-review 重复)
freshness = 1.0
safety = 1.0
final_score = 0.9 * 0.2 * 1.0 * 1.0 = 0.18 → 不推荐（本地已有）
```

---

## 探索-利用权衡（Explore-Exploit）

基于 018-认知科学：算法之美

**利用（Exploit）**：80% 推荐已知好用的，与用户画像高度匹配的 skill
**探索（Explore）**：20% 推荐用户未覆盖的领域，发现新可能性

**探索触发条件**：
- 用户工作域中没有覆盖的领域（如：用户没有"视频编辑"标签 → 推荐一个视频相关 skill）
- 跨领域 skill（如：FPGA + AI 的交叉领域）
- 新兴平台上的高增长 skill（虽然 stars 不高但增速快）

**探索风险控制**：
- 探索型推荐必须通过安全审查（不能因为"探索"就降低安全标准）
- 每次最多推荐 2 个探索型 skill（避免信息过载）
- 探索型推荐标注"[探索推荐]"标签，让用户知道这是新领域
