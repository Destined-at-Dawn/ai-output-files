# li-bestskill 黄金规则

## GR-001：宽泛关键词优先
搜索技能时先用核心概念词（如 self-improving），不加平台限定（如 claude skill）。
- 来源：搜索质量问题复盘（13★→23.2K★）
- 反模式：claude-code self-improving skill 太窄，只找到小圈子

## GR-002：Stars 排序必须
GitHub 搜索必须加 &s=stars&o=desc。不排序 = 看到的是最新发布的而不是最好的。
- 来源：搜索策略铁律
- 反模式：默认排序，结果前 10 页全是 0 星新项目

## GR-003：结果质量自检
搜索结果最高 Stars <100 → 说明关键词太窄，必须换更宽泛的词重搜。
- 来源：搜索策略 v1.2
- 反模式：搜到几个低星项目就觉得没有好的

## GR-004：每个平台都要搜
全平台不是 P0-P3 优先级排序——每个平台都要有明确搜索方法。只搜 GitHub = 放弃其他所有平台。
- 来源：用户批评只写 GitHub 策略
- 反模式：搜完 GitHub 就停了，skills.sh（61K+）没看

## GR-005：读 SKILL.md 不读 README
评估技能质量必须读完整 SKILL.md/主文件，不读 README 摘要。
- 来源：li-skillcreate Phase 1
- 反模式：只看 README 就判断这个 skill 不行
