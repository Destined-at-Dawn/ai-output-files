# Golden Rules - li-infra

## GR-001: mutual 是唯一权威源
- 规则：路由表/共享规则只有 mutual 版本是权威，其他工作区是副本
- 来源：SSOT 原则 (T8)
- 反模式：直接改其他工作区的路由表副本

## GR-002: 第三方仓库绝对只读
- 规则：git clone 下来的仓库绝不修改任何文件
- 来源：第三方仓库误改事故（4 个仓库被改）
- 反模式：把第三方仓库当用户工作区同步

## GR-003: 先备份后修改
- 规则：修改 CLAUDE.md / memory / SOP 前必须 git checkpoint
- 来源：git-recovery.md
- 反模式：直接 Write 覆写，无法恢复

## GR-004: 全递归扫描
- 规则：找 CLAUDE.md 必须 os.walk() 全递归，不靠硬编码列表
- 来源：深度嵌套工作区漏扫事故（12->66 个 CLAUDE.md）
- 反模式：只扫顶层目录

## GR-005: SOP 编排优于单 skill 堆砌
- 规则：复杂流程拆成 SOP 编排多个 skill，而非一个 skill 塞所有
- 来源：li-transcript 2039 行膨胀事故
- 反模式：一个 skill 做所有事
