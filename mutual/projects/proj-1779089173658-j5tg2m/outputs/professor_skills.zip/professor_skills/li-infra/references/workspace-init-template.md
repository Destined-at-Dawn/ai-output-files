# 工作区初始化模板

## Step 1: 创建目录结构
CLAUDE.md + memory/ + SOPs/ + self-evolution/ + outputs/ + .claude/rules/ + skill-routing-table.json

## Step 2: CLAUDE.md 模板
启动强制读取序列 + Step 4.5 路由加载 + 技能自动激活规则

## Step 3: 注入共享规则引用
从知识中枢/02-共享规则/ 引用必要规则

## Step 4: 验证
- [ ] CLAUDE.md 启动序列完整
- [ ] memory/ 目录存在
- [ ] 路由表版本与 mutual 一致
- [ ] 无 rules/ 目录残留
