# CLAUDE.md 诊断清单

## 7 项强制检查
1. 启动序列完整性（Step 0-4.5）
2. 读取顺序正确
3. 无 rules/ 目录残留
4. 无已弃用 skill 引用
5. 有路由加载指令
6. 有防回退铁律
7. 有 No Blind Overwrite

修复方式：Edit 精确替换
