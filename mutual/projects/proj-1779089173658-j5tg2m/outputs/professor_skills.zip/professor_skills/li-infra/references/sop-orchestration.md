# SOP 编排详解

## SOP-A: 文章深度分析编排
li-analyze Phase 0 -> li-research -> li-analyze Phase 1 -> Phase 2 -> li-devil -> Phase 3 -> li-improve

## SOP-B: 新 skill 创建编排
li-skillcreate Phase 0 -> li-bestskill -> li-skillcreate Phase 1 -> li-devil -> Phase 2 -> Phase 3.5 -> li-sync -> li-improve

## SOP-C: 工作区健康检查编排
li-infra Phase 5 -> li-sync -> li-manage -> li-infra Phase 6
