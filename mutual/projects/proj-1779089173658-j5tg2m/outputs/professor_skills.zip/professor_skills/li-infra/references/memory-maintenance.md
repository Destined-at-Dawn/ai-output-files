# 记忆系统维护指南

## long-term.md 维护
- 30 天未更新 -> [需刷新]
- 90 天低置信 -> 归档
- 矛盾检测 -> 提示用户

## {today}.md 维护
- 每日任务记录格式
- 90 天后压缩归档

## session checkpoint
- PreCompact hook 自动写入
- SessionStart(compact) hook 自动恢复
