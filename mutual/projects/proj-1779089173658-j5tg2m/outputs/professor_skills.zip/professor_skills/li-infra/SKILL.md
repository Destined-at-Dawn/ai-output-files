---
name: li-infra
version: "1.0"
description: |
  li系列 - 基础设施管理层。CLAUDE.md / memory / SOP / 训练数据的创建、维护、
  跨区同步和健康检查。确保每个工作区的约束文件和记忆系统始终有效。
triggers:
  - 创建CLAUDE.md
  - 更新约束文件
  - SOP创建
  - SOP编排
  - 训练数据
  - 工作区初始化
  - 记忆系统
  - 约束文件
  - 基础设施
  - CLAUDE维护
  - memory维护
  - SOP维护
  - 跨区同步约束
  - 工作区健康检查
  - 启动序列
  - 进化日历
  - 技能路由表
  - session checkpoint
  - 记忆候选
---


> **必读（执行前必须 Read）**：`references/skill-linkage.md` — li- 系列联动规则。不读 = 跳过联动 = 产出不完整。500 万 token 上下文中本文件可能被压缩，但 references/ 不会被压缩。


## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **执行约束（非建议）。** **必读（必须 Read）**: `references/workspace-init-template.md` | `references/claude-md-diagnosis.md` | `references/memory-maintenance.md` | `references/sop-orchestration.md`。无 Source = 禁止声称。跳过 = 违反法则8。Phase 执行前确认已 Read 所有 references/ 必读文件，未读 = 禁止继续。
> **按需**: `references/claude-md-diagnosis.md` | `references/memory-maintenance.md` | `references/sop-orchestration.md`


# li-infra - 基础设施管理层

## 定位
li-infra 管理 li- 系列的"神经系统"——CLAUDE.md（约束）、memory/（记忆）、SOPs/（编排）、路由表（触发）。不直接做业务，确保所有其他 skill 的运行环境健康。

## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 渐进式披露 | CLAUDE.md 只放最高优先级，其余按需加载 | Progressive Disclosure 架构 |
| T2 | 控制论 | memory -> 行为调整 -> 新记忆 | 维纳控制论 |
| T3 | 熵增定律 | 无维护的 SOP/memory 必然失效 | 热力学第二定律 |
| T4 | 最小惊讶原则 | 每个工作区的约束应一致 | 最小惊讶原则 |
| T5 | 外部化记忆 | CLAUDE.md = AI 的长期外化记忆 | 认知负荷理论 |
| T6 | 契约测试 | SOP 的输入/输出应可验证 | 契约测试理论 |
| T7 | 看门狗模式 | 定期健康检查 > 事后修复 | 嵌入式看门狗 |
| T8 | 单一数据源 | 路由表只有 mutual 一份权威源 | SSOT 原则 |
| T9 | 反脆弱 | 工作区被破坏后应能从 git 恢复 | 反脆弱 |
| T10 | 模块化 | CLAUDE.md/memory/SOP 各自独立 | 模块化设计 |
| T11 | 自动化门禁 | 启动序列自动执行，不靠 AI 记得 | CI/CD 门禁 |
| T12 | 帕累托 | 20% 的 SOP 覆盖 80% 的场景 | 帕累托法则 |

## Phase 0: 需求识别

| 信号 | 动作 |
|------|------|
| 新工作区要初始化 | Phase 1 |
| CLAUDE.md 规则冲突 | Phase 2 |
| SOP 失效/过期 | Phase 3 |
| memory 文件损坏 | Phase 4 |
| 定期健康检查 | Phase 5 |
| 跨区约束不同步 | Phase 6 |

## Phase 1: 工作区初始化

输入：新工作区路径 + 类型（个人/创作/求职/竞赛/学习）

执行：
1. 创建 CLAUDE.md（基于模板 + 工作区类型定制）
2. 创建 memory/ + long-term.md + {today}.md
3. 创建 SOPs/
4. 创建 self-evolution/evolution-calendar.md
5. 复制 skill-routing-table.json（从 mutual 同步）
6. 注入启动序列到 CLAUDE.md

输出：完整可运行的工作区基础设施
详见：references/workspace-init-template.md

## Phase 2: CLAUDE.md 诊断与修复

诊断清单（7 项）：
1. 启动序列是否存在且完整？
2. 读取顺序是否正确？
3. 是否有 rules/ 目录残留（违反 R16）？
4. 是否引用了已弃用的 skill 名？
5. 是否有路由加载指令（Step 4.5）？
6. 是否有防回退铁律？
7. 是否有 No Blind Overwrite 规则？

修复方式：Edit 精确替换（不覆写）
详见：references/claude-md-diagnosis.md

## Phase 3: SOP 创建与编排

SOP 编排核心思想：多个 skill 串联执行，降低单个 skill 文件大小。

### SOP-A: 文章深度分析编排
```
li-analyze Phase 0 -> li-research -> li-analyze Phase 1 -> Phase 2 -> li-devil -> Phase 3 -> li-improve
```

### SOP-B: 新 skill 创建编排
```
li-skillcreate Phase 0 -> li-bestskill -> li-skillcreate Phase 1 -> li-devil -> Phase 2 -> Phase 3.5 -> li-sync -> li-improve
```

### SOP-C: 工作区健康检查编排
```
li-infra Phase 5 -> li-sync -> li-manage -> li-infra Phase 6
```

详见：references/sop-orchestration.md

## Phase 4: 记忆系统维护

维护清单：
- long-term.md 30 天未更新 -> 标注 [需刷新]
- {today}.md 超过 90 天 -> 归档
- 记忆候选未确认 -> 提醒用户
- 矛盾记忆检测 -> 提示用户确认

详见：references/memory-maintenance.md

## Phase 5: 全量健康检查

扫描范围：所有含 CLAUDE.md 的用户工作区

检查项：
1. 路由表版本一致性（mutual 为权威源）
2. CLAUDE.md 启动序列完整性
3. memory/ 目录结构完整性
4. SOPs/ 目录是否有过期 SOP
5. 防回退铁律（无 rules/ 残留）
6. 第三方仓库未被误改

输出：健康报告（合格/警告/危险 三档）

## Phase 6: 跨区同步

同步内容：
| 内容 | 来源 | 目标 | 频率 |
|------|------|------|------|
| skill-routing-table.json | mutual | 所有用户工作区 | 每次路由变更 |
| 共享规则变更 | 知识中枢 | 所有工作区 | 按需 |
| 记忆候选 | 任意工作区 | long-term.md | 确认后 |

铁律：
- 第三方仓库 = 只读
- 归档目录 = 只读
- 同步前必须备份（git checkpoint）



## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式

| # | 反模式 | 后果 | 理论来源 |
|---|--------|------|---------|
| 1 | 硬编码工作区列表 | 漏掉深层嵌套工作区 | T11 |
| 2 | 路由表改了不同步 | skill 存在但不触发 | T8 |
| 3 | CLAUDE.md 用 Write 覆写 | 丢失已有约束 | No Blind Overwrite |
| 4 | memory 不归档 | 文件膨胀超上下文 | T1 |
| 5 | SOP 不验证输入输出 | 下游 skill 收到脏数据 | T6 |
| 6 | 改第三方仓库 | 破坏别人的代码 | 只读原则 |
| 7 | 健康检查靠人工记 | 忘了就坏了 | T7 |

## 条件下一步

| 条件 | 下一步 |
|------|--------|
| 新工作区 | Phase 1 |
| CLAUDE.md 有冲突 | Phase 2 |
| SOP 过期 | Phase 3 |
| memory 损坏 | Phase 4 |
| 定期检查 | Phase 5 |
| 路由表变更 | Phase 6 |
| 用户说"优化基础设施" | 全 Phase |

## 联动技能

| Skill | 触发条件 | 联动方式 |
|-------|---------|---------|
| li-sync | 路由表/约束变更 | 全工作区同步 |
| li-manage | 记忆清理/知识沉淀 | 记忆系统维护 |
| li-skillcreate | 创建新 skill | SOP-B 编排 |
| li-analyze | 分析文章 | SOP-A 编排 |
| li-improve | 对话结束自审 | 经验沉淀 |
| li-devil | 重大决策前 | 质疑基础设施变更 |
| li-diagnose | 系统变乱 | 熵增诊断 |

## 外部研究

| 项目 | Stars | 学到了什么 |
|------|-------|-----------|
| claude-code-workflows | 1.2K | 工作区初始化模板 |
| bootstrapping-claude-code | 1.8K | 启动序列最佳实践 |
| AGENTS.md spec | 60K+ | 约束文件标准化 |


## Case Studies

### Case 1: 新工作区初始化
- **场景**：创建"竞赛"工作区，需要 CLAUDE.md + 路由表 + memory + SOP
- **方法**：Phase 1（检测空工作区）→ Phase 2（生成 CLAUDE.md）→ Phase 6（同步路由表）
- **结果**：10 分钟完成初始化，之前手动要 1 小时
- **教训**：新工作区必须走 li-infra 初始化流程

### Case 2: 路由表断裂修复
- **场景**：2016 个 skill 引用断裂
- **方法**：Phase 5 全量扫描 → 定位断裂点 → 批量替换 → 验证
- **结果**：506 文件 / 2369 处替换 / 零残留
- **教训**：重命名 skill 后必须全量扫描引用链

### Case 3: SOP 识别层注入
- **场景**：15 个 SOP 建好了但 AI 从不触发
- **方法**：Phase 3 创建 SOP 索引 → 注入 CLAUDE.md 启动序列
- **结果**：SOP 触发率从 0% 到 80%
- **教训**：SOP 索引不在启动链路里 = SOP 不存在


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 改第三方仓库的 CLAUDE.md | 破坏别人项目 | 第三方仓库 = 只读 |
| 2 | 路由表同步只做顶层目录 | 漏掉深层嵌套工作区 | os.walk() 全递归扫描 |
| 3 | 注入 CLAUDE.md 时不备份 | 出错无法回滚 | Git checkpoint + 归档 |
| 4 | memory 文件用 Write 覆写 | 丢失历史内容 | 先 Read 再 Edit 追加 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-sync** | 跨工作区同步 | "同步路由表" |
| **li-manage** | 记忆和技能管理 | "管理 memory 文件" |
| **li-skillcreate** | 新建 skill 后的基础设施配置 | "新建 skill 需要什么配置" |
| **li-migrate** | 工作台迁移 | "迁移到新环境" |

## References Index

| 文件 | 内容 |
|------|------|
| references/workspace-init-template.md | 工作区初始化模板 |
| references/claude-md-diagnosis.md | CLAUDE.md 诊断清单 |
| references/sop-orchestration.md | 3 个核心编排 SOP 详解 |
| references/memory-maintenance.md | 记忆系统维护指南 |


### Flow C: Automation (from li-workflow)

When users need CI/CD, Git hooks, scheduled tasks, or build automation:

1. **CI/CD Pipelines**: GitHub Actions / GitLab CI configuration
2. **Build Scripts**: Makefile, npm scripts, shell scripts
3. **Git Hooks**: pre-commit, commit-msg (husky, lint-staged)
4. **Scheduled Tasks**: cron expressions, scheduled task configuration
5. **Code Quality Automation**: ESLint, Prettier, TypeScript checks
6. **Release Flow**: version management, changelog generation

**Key principles**:
- Only automate the top 3 most time-consuming steps
- Always dry-run before executing
- Use environment variables, never hardcode secrets
- Add logging and alerting for silent failures

## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈

## 案例库

### 案例 1：5 工作区 CLAUDE.md 统一治理
**场景**：5 个工作区的 CLAUDE.md 各自为战，启动序列不一致
**方法**：扫描所有 CLAUDE.md → 提取公共段落 → 注入统一启动序列
**结果**：39 个工作区全部加载路由表，skill 触发率从 30% 提升到 95%
**教训**：基础设施不统一 = skill 存在但不触发

### 案例 2：路由表丢失恢复
**场景**：mutual 根目录的 skill-routing-table.json 意外消失
**方法**：从项目备份目录找到最新副本 → 恢复 → 验证 42 工作区同步
**结果**：路由表恢复，0 数据丢失
**教训**：关键文件必须有 Git 检查点 + 多副本

