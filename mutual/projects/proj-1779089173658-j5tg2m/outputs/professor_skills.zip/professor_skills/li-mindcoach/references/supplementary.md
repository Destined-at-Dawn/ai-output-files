## Case Studies

### Case 1: 竞赛焦虑
- **场景**：竞赛 deadline 还有 1 周，完成度只有 40%
- **方法**：Phase 1 看清结构（真正必须完成的是什么）→ Phase 2 信念切换（40% 里有 80% 是核心功能）→ Phase 4 外部跳（先交付核心，演示加分项留空）
- **结果**：按时提交核心功能，获得省奖
- **教训**：焦虑时先做减法，砍到最小可行版本

### Case 2: 考研方向迷茫
- **场景**：上交 vs 东南，选哪个
- **方法**：Phase 1 结构化（两个选择的真实成本/收益/风险）→ Phase 3 语言重置（"选不了"→"我有 2 个好选择"）
- **结果**：做出明确决策，不再内耗
- **教训**：迷茫的本质是信息不够，不是能力不够

### Case 3: 创作瓶颈
- **场景**：公众号连续 3 篇帖子数据差
- **方法**：Phase 2 信念切换（"我不行了"→"我的方法需要调整"）→ Phase 4 外部跳（研究竞品爆款）
- **结果**：下一篇突破 1000 阅读
- **教训**：创作瓶颈是信号，不是终点


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 只给鸡汤不给结构 | 用户感觉"没用" | Phase 1 必须先看清结构 |
| 2 | 同会话触发超过 2 次 | 用户疲劳 | 频次控制：同会话 ≤2 次 |
| 3 | 忽略用户说"我没事" | 强行教练引起反感 | 尊重边界，只提供一个锚点 |
| 4 | 只给安慰不给行动 | 情绪缓解但问题没解决 | 每个阶段必须有可执行的下一步 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-devil** | 决策质疑（和教练互补） | "这个决定对吗" |
| **li-plan** | 焦虑后的任务重排 | "重新规划一下" |
| **li-research** | 信息不足时的调研 | "帮我查一下这个方向" |
| **li-improve** | 教练经验沉淀 | "这个方法有效" |


## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 案例库

### 案例 1：考研方向焦虑
**场景**：小黎在上交/东南电气之间纠结，焦虑到影响学习
**四阶段**：感受映射（"选择焦虑"）→ 认知松动（锚定效应 WYSIATI）→ 替代框架（期望值决策）→ 行动锚点（"先准备两个，12 月再决定"）
**结果**：焦虑从 8/10 降到 3/10，恢复学习节奏
**关键**：不是帮选方向，是帮处理选择焦虑本身

### 案例 2：FPGA 项目连续失败想放弃
**场景**：Vivado 7 连败后产生"我不适合搞硬件"的想法
**四阶段**：感受映射（"习得性无助"）→ 认知松动（固定型思维 vs 成长型思维）→ 替代框架（反脆弱——挫折是信息不是判决）→ 行动锚点（"只做最小可验证的 RTL 模块"）
**结果**：第 8 次尝试成功，写入 7 个血泪教训

### 案例 3：内容创作灵感枯竭
**场景**：小红书连续 3 篇数据差，怀疑方向错误
**四阶段**：感受映射（"创作倦怠"）→ 认知松动（间隔效应——休息不是放弃）→ 替代框架（杠铃策略——90% 稳定内容 + 10% 实验性内容）→ 行动锚点（"这周只看不做，下周写一篇实验性帖子"）
**结果**：休息一周后灵感回归，实验帖数据翻倍