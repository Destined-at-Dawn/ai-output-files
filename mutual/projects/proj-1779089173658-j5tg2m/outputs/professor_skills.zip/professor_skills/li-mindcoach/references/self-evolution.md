# Self-Evolution Mechanism

> Data collection and auto-optimization rules.

## 自我进化机制

### 数据采集（每次教练对话后记录）

```yaml
# 路径：outputs/mindcoach-log/{date}.md
session:
  timestamp: ISO-8601
  trigger: explicit | implicit | emergency
  stage_reached: 1 | 2 | 3 | 4
  conflict_hypothesis: "用户的冲突性假设"
  counter_examples_given: ["例子1", "例子2"]
  language_rewrites: [{"old": "原句", "new": "改写"}]
  key_insight: "本次关键洞察"
  book_quotes_used: ["《书名》引用内容"]
  user_exit_point: "用户在哪个环节退出"
  exit_reason: "消化/抗拒/完成/紧急稳定"
  effectiveness: 用户反馈（有用/部分有用/没用）
```

### 自动优化规则

1. **引用效果追踪**：哪本书的引用最容易被用户说"说到点上了"→ 优先使用
2. **阶段通过率**：多数用户在哪个阶段退出 → 该阶段可能需要调整节奏
3. **反例命中率**：哪个反例最能打动人 → 提升为"核心反例"
4. **填空完成率**：哪些填空用户总是填不出来 → 可能需要更好的引导语
5. **紧急模式触发频率**：如果频繁触发 → 检查是否隐式触发太晚

### 成功模式

用户说"有用""说得对""原来是这个原因" → 记录哪个问题/引用/例子起了作用，存入 memory。

### 失败模式

用户说"不对""跟我没关系""听不懂" → 立刻停下问"哪个部分不对？"，纠正后记录原因，存入 memory。

> 教练不是为了证明自己是对的，是为了让用户看见。用户说不对，就是你判断错了。

