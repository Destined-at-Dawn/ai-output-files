# Golden Rules - li-hardware

## GR-001: ROM > 10KB -> BMG IP Core
Source: 竞赛 LCD, 7-synthesis-fail chain. Never $readmemh for large ROM.

## GR-002: ROM Depth -> 2^n Aligned
Source: 竞赛 OOM explosion. Pad to power-of-2.

## GR-003: Chinese Windows -> env(USERNAME)
Source: D:\AMD 7-hour waste. First line of every TCL.

## GR-004: Servo Power != Arduino USB
Source: C919 puppet. External 5V 3A+, common GND, 100uF cap.

## GR-005: I2C Bandwidth Before Sample Rate
Source: D:\AMD I2C analysis. Calculate bit slots first.

## GR-006: XDC <-> Top.v <-> README Triple Sync
Source: D:\AMD SOP. Update all three after any pin change.

## GR-007: Three-Layer for FPGA
Source: D:\AMD 3 deliveries. top/ctrl/master. No logic in top.

## GR-008: Scene-Based for Multi-Actuator
Source: C919 (18 servos). >=4 servos -> ActionFrame/ActionGroup/Scene.

## GR-009: Delivery = Code + DOCX + ZIP
Source: D:\AMD SOP. Hardware PASS is not closure.

## GR-010: Debug = Environment First
Source: 竞赛 7-fail + 17-bug audit. Env -> path -> encoding -> code.

## GR-011: CRC = 3 Dimensions
Source: 竞赛 17-bug audit (CRC family, ~6h). Polynomial x bit-order x byte-order. Use Python independent verification.

## GR-012: Debug Fast-to-Slow
Source: 竞赛 17-bug audit. $display(5s) -> state(10s) -> handshake(30s) -> waveform(10min). Never start at waveform.

## GR-013: E-Stop = Output + State
Source: RM infantry. PID integral must be cleared on e-stop, otherwise motor surges on release.

## GR-014: Limit at Target Source
Source: RM infantry. Clamp target angle immediately after update, not just output.

## GR-015: Difference != Bug
Source: SOP-08 vendor porting. Code comparison finds differences, not bugs. Real HW decides.

## GR-016: IP via TCL not .xci
Source: 竞赛 IP lock. Manual .xci edit -> stale content error. Always use set_property.

## GR-017: XSIM = Verilog-2001 Only
Source: 竞赛. No fork/join_any, no break, no always_comb, no logic.

## GR-018: Batch Delete $display -> Diff Review
Source: 竞赛. Empty if/else after batch deletion -> wrong logic, silent failure.

## GR-019: 3-2-1 Backup Rule
Source: 竞赛 D盘 disaster (124K files lost). 3 copies, 2 media, 1 offsite.

## GR-020: Analysis != Modification
Source: 竞赛 I2C. User asks "analyze why it fails" -> give report, don't change code.

## GR-021: CAN Debug = Physical Layer First
Source: RM infantry. Check CANH/CANL wiring -> baud rate -> filter -> ESC ID.

## GR-022: I2C SDA Must Be Open-Drain
Source: SOP-06 iron law. assign sda = (sda_oe & ~sda_out) ? 1'b0 : 1'bz;
