# CRC 三维度调试链

> 来源：集创赛安全通信系统 17 Bug 审计（CRC 家族 3 Bug，~6h 调试）
> 核心教训：CRC 校验失败时，99% 的人只查多项式，忽略位序和字节序

## CRC 三维度

| 维度 | 选项 | 常见默认 |
|------|------|---------|
| 多项式/初始值 | Modbus 0x8005 vs CCITT-FALSE 0x1021 | 看协议文档 |
| 位序方向 | MSB-first vs LSB-first | 硬件通常 MSB-first |
| 字节输出顺序 | 原始 vs 交换 {crc[7:0],crc[15:8]} | 看协议文档 |

**任一维度不匹配都失败，症状完全相同（CRC 错误）。**

## 排查速查表

| 症状 | 可能原因 | 检查点 |
|------|----------|--------|
| CRC=0x29B1 通过但系统失败 | TB CRC 函数与硬件不一致 | 对比 data[7-i] vs data[i] |
| HELLO 通过但 AUTH_RSP 卡住 | CRC 字节交换错误 | calc_frame_crc 末尾是否有 {crc[7:0],crc[15:8]} |
| frame_parser 报 ERR_CRC | 三维度之一不匹配 | Python 独立计算后比对 |

## Python 参考验证（独立于硬件代码）

```python
def crc16_ccitt(data: bytes) -> int:
    crc = 0xFFFF
    for byte in data:
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc
```

## 调试方法论

1. **建立独立参考标准**：用 Python 算 CRC，不要用错误代码验证错误代码
2. **逐维度验证**：先固定多项式，验证位序；再固定位序，验证字节序
3. **参数化解耦**：三维度一次性验证所有组合（2x2x2=8 种）
4. **不要停在中间原因**：HELLO 通过不代表 CRC 函数对了，可能是巧合

## 反模式

- 只查多项式就声称"CRC 已验证"
- 用 DUT 的 CRC 函数验证 DUT 的 CRC 输出（循环论证）
- 发现一个维度匹配就停止排查
