# FPGABuilder Build Automation Patterns

> Source: FPGABuilder (65 star, CC BY-NC-SA 4.0)
> Value: hand-written TCL -> config-driven + template + automation

## Pattern 1: Config-Driven Build

YAML defines project, toolchain generates TCL:

```yaml
project: { name: my_project }
fpga: { vendor: xilinx, family: artix-7, part: xc7a35tftg256-1 }
source:
  hdl: [src/hdl/*.v]
  constraints: [src/constraints/*.xdc]
build:
  synthesis: { strategy: "Vivado Synthesis Defaults" }
  hooks: { pre_synth: "scripts/pre_synth.tcl" }
```

## Pattern 2: TCL Template System

6 templates: BasicProject / BDRecovery / BuildFlow / Clean / GUI / ProgramDevice

## Pattern 3: Hook System

6 hook points: pre_build -> pre_synth -> [synth] -> post_synth -> pre_impl -> [impl] -> post_impl

Auto-detect: .tcl -> source, .py/.bat/.sh -> subprocess.

## Pattern 4: Version Adapter

```python
VersionAdapterRegistry.register("vivado", r"2023\..*", Vivado2023Adapter)
adapter = VersionAdapterRegistry.get_adapter(tool_info)
```

3 methods: adapt_command / adapt_config / adapt_output

## Pattern 5: Device Programming

JTAG template: open_hw_manager -> connect -> program -> refresh -> close

## Pattern 6: Three-Level Cleanup

| Level | Action | Use |
|-------|--------|-----|
| soft | reset_runs + delete logs | Daily |
| hard | delete project dir | Rebuild |
| all | delete everything | Full reset |

## Pattern 7: Path Handling

TCL paths: always forward slash, never backslash.
