# FSM Design Patterns

> Source: hardware-design v5.0

## Core: Separate Register from Next-State Logic

```systemverilog
typedef enum logic [1:0] { IDLE, RUN, DONE } state_t;

state_t state, state_next;

always_comb begin
    state_next = state;
    case (state)
        IDLE: if (start) state_next = RUN;
        RUN:  if (finish) state_next = DONE;
        DONE: state_next = IDLE;
        default: state_next = IDLE;
    endcase
end

always_ff @(posedge clk) begin
    state <= state_next;
end
```

## Rules

1. state_next computed in always_comb
2. state assigned in always_ff
3. Every case branch has default
4. Use enum for readable state encoding
