# Vivado Lessons - 3 Real XC7A35T Deliveries

> Source: D:\AMD (vivado_rtl_lessons_global_skill.md + rtl_code_lessons.md)
> All verified on Vivado 2020.1 + XC7A35Tfgg484-2

## Iron Rules

### IR-01: ROM > 10KB MUST Use BMG IP Core
- Symptom: Vivado silent crash or OOM killer
- Root Cause: $readmemh creates distributed RAM (LUTs), not BRAM
- Fix: Block Memory Generator IP + .coe init file
- Verified: 29583 x 16-bit -> 20.5/50 BRAM (41%)

### IR-02: ROM/RAM Depth MUST Be 2^n
- Symptom: Enormous boundary-check mux logic
- Fix: Pad to next power-of-2 (29583 -> 32768)

### IR-03: Chinese Windows -> env(USERNAME)
- Symptom: 7 consecutive synth failures, 7 hours wasted
- Fix: First line of every TCL: `set ::env(USERNAME) "vivado_user"`

### IR-04: TCL Paths Use Forward Slashes
- Symptom: Random file-not-found or tab corruption
- Fix: `C:/Users/xxx` not `C:\Users\xxx`

### IR-05: XDC Pins Sync After Any Correction
- Rule: XDC <-> top.v ports <-> README pinout (triple sync)

### IR-06: Source Files ASCII-Only
- Rule: Comments in English, no Chinese in .v files

### IR-07: DRC Severity Downgrade Before reset_run
- Fix: `set_property SEVERITY {WARNING} [get_drc_checks NSTD-1]`

### IR-08: XSIM = Verilog-2001 Strict
- Fix: .sv for SystemVerilog, .v must be Verilog-2001

### IR-09: IP Files - Don't Manual add_files
- Fix: Let .xci auto-manage IP files

### IR-10: $display -> simulate.log
- Fix: Check simulate.log, not TCL Console

## AT21CS01 Protocol (NOT Dallas 1-Wire)

1. Defaults to HIGH-SPEED after reset (not standard)
2. Needs discovery (address scan 0..7)
3. Warm reset: 600us reset-low, 50ms DQ recharge, 200us release
4. LED: D0 = done & pass, D1 = done & fail

## I2C/ADC/DAC System

1. Calculate bus bandwidth BEFORE waveform params
2. 400kHz SCL: 77 bit slots/pair = ~5.2 kSPS max
3. Board mapping > logical names (verify with scope)
4. ILA window: 4096 @ 50MHz = 81.92us
5. Stable delivery > risky speed claims

## 7-Synthesis-Failure Chain (2026-05-13)

7 hours, 5 root causes - ALL from $readmemh OOM:
1. No BRAM attribute -> distributed RAM explosion
2. Non-2^n depth -> boundary mux explosion
3. Chinese COMPUTERNAME -> .Xil path corruption
4. IP files manually added -> dependency confusion
5. DRC severity not downgraded -> synth blocked

Lesson: env vars -> path -> encoding -> code logic

## ILA Debug Procedure

When CLI ILA fails:
1. Open Vivado GUI
2. Tcl Console: open_hw_manager
3. Use setup_ila_current_project.tcl
4. Or regenerate via IP Catalog
