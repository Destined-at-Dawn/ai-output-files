# Yosys + Verilator Compatibility

> Source: hardware-design v5.0

## Yosys: Constructs to Avoid

| Avoid | Use instead |
|-------|-------------|
| return expr in functions | func_name = expr |
| interface / modport | Explicit port lists |
| unique case / priority case | Plain case with default |
| Multi-dim packed arrays in ports | Flatten to single vectors |

## Verilator Lint

```sh
verilator --lint-only -Wall module.sv
```

Fix all warnings. Key: WIDTH, UNUSED, UNDRIVEN.

## Verilator Simulation

```sh
verilator --binary -Wall -j 0 --assert --timing --trace-fst module_tb.sv module.sv
```

## Testbench Template

```systemverilog
module counter_tb;
    logic clk = 1'b0, rst_n;
    logic [7:0] count;
    counter dut (.*);
    always #5 clk = ~clk;
    initial begin
        rst_n = 1'b0; #20 rst_n = 1'b1;
        #100; $display("count=%d", count); $finish;
    end
endmodule
```
