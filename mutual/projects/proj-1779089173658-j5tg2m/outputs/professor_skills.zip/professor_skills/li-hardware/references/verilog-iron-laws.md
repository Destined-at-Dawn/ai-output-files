# Verilog 编码铁律（10 条）

> 来源：竞赛区 SOP-06 硬件设计与验证 SOP v1.9 + 17 Bug 审计
> 违反任何一条 = 事故级

## 1. 位宽精确匹配
`localparam` 位宽必须与被比较 `reg` 精确一致。

## 2. 循环变量隔离
内外层 for 循环必须用不同变量名（`i`/`j`）。

## 3. disable 命名块规则
`disable` 必须写成 `begin : label ... disable label; end`。

## 4. 跨时钟域同步
外部/异步输入必须经至少两级同步器（三级更安全）。

## 5. 边沿检测
持续高电平检测必须用 `sig && !sig_dly` 检测上升沿。

## 6. 避免悬空 if
移除 debug $display 后检查是否留空 if。批量删除后必须执行 Diff Review。

## 7. I2C SDA 必须 Open-Drain
```verilog
// 错误：被综合成 push-pull
assign sda = sda_oe ? sda_out : 1'bz;
// 正确：Open-Drain
assign sda = (sda_oe & ~sda_out) ? 1'b0 : 1'bz;
```

## 8. 多模块 CMD 编码一致性
所有共享命令编码必须逐一比对，禁止假设一致。推荐 `include` 文件。

## 9. 禁止全局错误检测
禁止在状态机外"每个周期检查"错误。必须在 case 分支内就地检查。

## 10. ROM 深度对齐 2 的幂
ROM > 10KB 时禁止非 2 的幂次方深度。Vivado 会生成巨大边界检查 MUX 导致 OOM。

## ROM > 16K 专项铁律
- 禁止用 $readmemh，必须用 BMG IP
- create_ip 前必须 file mkdir
- 禁止写死 IP 版本号
- IP 核必须禁用 OOC

## XSIM 不支持的 SystemVerilog 语法

| SV 语法 | XSIM 替代方案 |
|---------|-------------|
| fork/join_any | fork : block ... disable block ... join |
| disable fork | disable 块名 |
| break | disable |
| always_comb | always @(*) |
| always_ff | always @(posedge clk) |
| logic | reg / wire |
