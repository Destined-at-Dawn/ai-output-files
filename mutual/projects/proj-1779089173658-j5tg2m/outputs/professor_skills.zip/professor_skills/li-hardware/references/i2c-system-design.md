# I2C System Design - Bandwidth-First

> Source: D:\AMD I2C_ADC采样率理论分析_20260602.md
> Verified: XC7A35T + ADC081C021 + DAC081C085

## Bandwidth Calculation

### Step 1: Bit Slots Per Transaction

I2C transaction: START(1) + ADDR(8) + ACK(1) + DATA(8) + ACK(1) + STOP(1) = 20 bits

ADC read + DAC write (shared bus):
- ADC: ~28 bits (START + 0x55 + ACK + DATA_H + ACK + DATA_L + ACK + STOP)
- DAC: ~28 bits (START + 0x54 + ACK + DATA_H + ACK + DATA_L + ACK + STOP)
- Overhead: ~21 bits
- Total: ~77 bit slots per ADC+DAC pair

### Step 2: Max Sample Rate

| SCL | Bit Slots/sec | Max SPS |
|-----|--------------|---------|
| 100kHz | 100,000 | ~1,300 |
| 400kHz | 400,000 | ~5,200 |
| 1.7MHz | 1,700,000 | ~22,000 |
| 3.4MHz | 3,400,000 | ~44,000 |

### Step 3: Safety Check

```
required_rate <= max_rate x 0.8
Example: 4kHz at 400kHz SCL: 5200 x 0.8 = 4160 > 4000 OK
Example: 4kHz at 100kHz SCL: 1300 x 0.8 = 1040 < 4000 FAIL
```

## Common Pitfalls

1. Address conflict: same bus = unique addresses
2. Pull-up: R = (Vcc - VOL) / IOL, typically 4.7k for 400kHz
3. Bus capacitance: max 400pF standard, 100pF fast
4. Level shifting: 3.3V <-> 5V needs bidirectional shifter
5. Multi-master: only one master at a time

## Multi-Device Topology

```
VCC(3.3V) -- [4.7k] -- SDA --+--+--[ADC 0x55]
                               |  +--[DAC 0x54]
              [4.7k] -- SCL --+--+--[ADC 0x55]
                               |  +--[DAC 0x54]
                               +--[FPGA Master]
```
