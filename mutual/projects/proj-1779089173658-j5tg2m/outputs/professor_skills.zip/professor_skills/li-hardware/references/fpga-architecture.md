# FPGA Architecture - Three-Layer Pattern

> Source: D:\AMD 3 deliveries (ADC/DAC, AT21CS01)
> Target: Xilinx XC7A35T, Vivado 2020.1

## Three-Layer Hierarchy

```
*_top.v    (Layer 3: Wiring - NO logic)
  +-- *_ctrl.v  (Layer 2: FSM + Timing)
  |     +-- *_master.v  (Layer 1: Bus Driver)
  +-- Direct connections (clk, reset, LEDs)
```

### Layer 1: Bus Master
- I2C: START -> WRITE_ADDR -> WRITE_DATA -> ACK -> STOP
- SPI: CS_LOW -> SHIFT_OUT -> CS_HIGH
- UART: START_BIT -> DATA_BITS -> STOP_BIT
- Output: done signal + data byte

### Layer 2: Controller
- Multi-byte transaction orchestration
- Protocol FSM: S_IDLE -> S_CMD -> S_DATA -> S_DONE
- Timing delays (reset pulse, init sequences)
- Parameterized (sample rate, address, etc.)

### Layer 3: Top Module
- Instantiate ctrl + master
- Wire internal signals
- Map FPGA pins
- NO logic, NO calculations

## Naming Conventions

| Category | Convention | Example |
|----------|-----------|---------|
| Modules | lowercase + _ | lcd_ctrl, spi_master |
| Signals | lowercase + _ | pixel_x, logo_addr |
| Parameters | ALL_CAPS + _ | LOGO_W, T_10MS |
| States | S_ prefix | S_IDLE, S_SEND |
| Clocks | clk prefix | sys_clk |
| Resets | rst_n suffix | sys_rst_n |
| TB | tb_ prefix | tb_lcd_ctrl |

## TCL Build Automation

### Standard Scripts
```
build_project.tcl    - Create project from scratch
run_synth.tcl        - Synthesis (jobs=4)
run_bitstream.tcl    - Implementation + bitstream
setup_ila.tcl        - ILA debug probes
```

### Template
```tcl
set ::env(USERNAME) "vivado_user"
create_project proj_1 ./vivado_project -part xc7a35tfgg484-2 -force
set_property target_language Verilog [current_project]
add_files [glob ./rtl/*.v]
add_files [glob ./xdc/*.xdc]
set_property STEPS.SYNTH_DESIGN.ARGS.FLATTEN_HIERARCHY none [get_runs synth_1]
```

## Resource Budget (XC7A35T)

| Resource | Available | Typical | Warn At |
|----------|-----------|---------|---------|
| LUT | 20,800 | 1-5% | >80% |
| FF | 41,600 | <1% | >80% |
| BRAM (36Kb) | 50 | 20.5/50 for 29Kx16 ROM | >40 |
| DSP | 90 | 0-2 | >70 |
| IO | 200 | 10-30 | >150 |
