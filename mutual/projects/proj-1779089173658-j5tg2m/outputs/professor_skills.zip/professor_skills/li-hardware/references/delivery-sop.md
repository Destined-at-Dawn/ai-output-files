# FPGA RTL Delivery - One-Pass SOP

> Source: D:\AMD 12_FPGA_RTL客户交付一把过SOP.md

## Before RTL Edit

1. Read memory/rtl_code_lessons.md (if exists)
2. Archive: cp -r rtl/ rtl_backup_$(date +%Y%m%d)/
3. Classify: new feature / bug fix / optimization / refactor

## During Edit

1. ASCII-only in .v files
2. XDC <-> top.v <-> README triple sync
3. ILA debug signals for key paths
4. Three-layer: top / ctrl / master
5. ROM > 10KB -> BMG IP
6. ROM depth -> 2^n

## After Edit

1. Synthesis PASS
2. Implementation PASS (no timing violations)
3. Bitstream generated
4. Testbench PASS
5. ILA verified on hardware

## Delivery Checklist

### RTL Package
- [ ] .v compile clean
- [ ] XDC = schematic = README
- [ ] TCL clean-build works
- [ ] README: arch + pinout + build + limitations

### Documentation
- [ ] DOCX from template (7 sections)
- [ ] A4, correct headers/fonts
- [ ] Images embedded

### Packaging
- [ ] ZIP: function_name.zip
- [ ] Structure: rtl/ + xdc/ + sim/ + docs/ + TCL + README
- [ ] No Vivado project files (rebuild from TCL)
- [ ] No temp files (.Xil/, .cache/, .runs/)
- [ ] Originals preserved (delivery = copy)

## Handoff

1. Customer can rebuild from TCL
2. Document remaining risks
3. Archive delivery version
4. Append lesson to golden_rules.md
