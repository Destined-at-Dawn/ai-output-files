# Debug Methodology - From 17-Bug FPGA Audit

> Source: 竞赛 2026-04-24_audit-and-fix-reflection.md (1652 lines, 17 bugs, 4 families)

## 8-Step Debug Checklist

1. Read error COMPLETELY (every word matters)
2. Check environment FIRST (env vars, paths, encoding, version)
3. Classify: compile / sim mismatch / timing / hardware
4. Isolate layer: top / ctrl / master?
5. Reproduce minimally
6. Check recent changes (git diff)
7. Verify assumptions (check schematic, calculate timing)
8. Document fix -> golden_rules.md immediately

## CRC Multi-Dimensional Check

| Dimension | Options | Common Error |
|-----------|---------|-------------|
| Polynomial | CRC-8/16/32/custom | Wrong poly |
| Bit order | MSB-first / LSB-first | Reversed |
| Byte order | Big-endian / Little-endian | Swapped |

All 3 must match sender/receiver. Mismatch in ANY = valid-looking wrong CRC.

## UART RX Cascade (4 bugs)

1. Baud rate mismatch -> garbage
2. Oversampling off-by-one -> bit errors
3. Start bit too sensitive -> false triggers
4. No debounce -> FIFO corruption

Check ALL 4 layers simultaneously.

## Verilog Coding Rules

| Rule | Description |
|------|-------------|
| CR-01 | CRC: verify poly + bit-order + byte-order independently |
| CR-02 | UART: check baud + oversample + start-bit + debounce together |
| CR-03 | Reset: active-low async, sync deassert |
| CR-04 | Clock: explicit CDC for cross-domain signals |
| CR-05 | Width: explicit wire width, never implicit 1-bit |
| CR-06 | Sensitivity: `always @(posedge clk or negedge rst_n)` for seq |
| CR-07 | Latch: complete if-else or case with default (combinational) |

## Negative Results

| Failure | Root Cause | Lesson |
|---------|-----------|--------|
| 7-fail chain | Chinese COMPUTERNAME | Env vars FIRST |
| ROM OOM | No BRAM attr | rom_style="block" mandatory |
| ROM explosion | Non-2^n depth | Pad to power-of-2 |
| CRC 17 bugs | 3-dim inconsistency | Verify poly+bit+byte |
| UART cascade | Oversampling chain | Check all 4 layers |
| $readmemh 29K | Should use BMG | $readmemh max ~16K |
| ILA too small | 4096@50MHz=82us | Window vs event period |
