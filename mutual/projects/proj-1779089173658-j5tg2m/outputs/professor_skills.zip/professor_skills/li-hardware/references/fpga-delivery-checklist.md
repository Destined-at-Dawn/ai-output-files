# FPGA 交付检查清单

> 来源：SOP-12 + SOP-13
> 核心原则：硬件通过不等于交付完成

## 修改前检查

- [ ] 读 README、top、XDC、Tcl、核心 RTL、历史交接记录
- [ ] 找最新老板反馈（优先级高于旧 README 和旧 AI 假设）
- [ ] 确认 reset 极性、LED 有效电平、I2C 地址
- [ ] 先归档，不直接覆盖可用版本

## RTL 验证清单

- [ ] Synthesis：0 error，0 critical warning
- [ ] Implementation：bitstream completed successfully
- [ ] Timing：all constraints met
- [ ] `.bit` 和 `.ltx` 均存在
- [ ] RTL/Tcl/XDC 无乱码（ASCII 注释）
- [ ] 单总线器件：验证冷启动和 warm reset

## 文档交付清单

- [ ] 文件名能说明实验功能
- [ ] 工程路径真实存在
- [ ] 管脚表与 XDC 一致
- [ ] 原理图来自真实工程资料
- [ ] 实验现象不伪造未验证的结果

## 打包检查

- [ ] 每个实验单独 ZIP，中文功能命名
- [ ] ZIP 内：DOCX、README、rtl/、xdc/、Tcl、.bit、.ltx
- [ ] 不包含过期 .bit/.ltx
- [ ] 压缩后打开 ZIP 核验

## 故障分类体系（debug 前先分类）

| 类型 | 典型症状 |
|------|---------|
| board mapping | 引脚不对、LED 不亮 |
| peripheral protocol | I2C 无应答、SPI 时序错 |
| bus throughput | 波形粗糙、数据丢失 |
| analog range | 削波、噪声大 |
| reset/result | 复位后状态不对 |
| timing | 建立/保持违例 |
| source encoding | 中文乱码 |

## 板级固定信息（XC7A35T-2FGG484I）

- 时钟：W19, 50MHz | 复位：Y19, 低有效
- I2C：SCL=W21, SDA=AA18 | 1-Wire：DQ=Y6
- ADC1: 0x55 | ADC2: 0x56 | DAC1: 0x0a | DAC2: 0x09
