# SPI 设备模板

> OLED / SD 卡 / RFID 通用模板

---

## SPI 引脚定义

| 开发板 | MOSI | MISO | SCK | CS |
|--------|------|------|-----|-----|
| Arduino Uno | 11 | 12 | 13 | 10 |
| Arduino Mega | 51 | 50 | 52 | 53 |
| ESP32 | 23 | 19 | 18 | 5 |

---

## SSD1306 OLED（SPI 模式）

```cpp
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_CS    5
#define OLED_DC    16
#define OLED_RESET 17

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT,
  &SPI, OLED_DC, OLED_RESET, OLED_CS);

void setup() {
  if (!display.begin(SSD1306_SWITCHCAPVCC)) {
    Serial.println("SSD1306 init failed");
    while (1);
  }
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Hello World!");
  display.display();
}
```

---

## SD 卡读写

```cpp
#include <SPI.h>
#include <SD.h>

#define SD_CS 10

void setup() {
  Serial.begin(115200);
  if (!SD.begin(SD_CS)) {
    Serial.println("SD init failed");
    return;
  }
  Serial.println("SD initialized");
  
  // 写文件
  File f = SD.open("/test.txt", FILE_WRITE);
  if (f) {
    f.println("Hello SD!");
    f.close();
  }
  
  // 读文件
  f = SD.open("/test.txt");
  if (f) {
    while (f.available()) Serial.write(f.read());
    f.close();
  }
}
```

---

## 常见 SPI 设备

| 设备 | CS 引脚 | SPI 模式 | 时钟频率 |
|------|---------|----------|---------|
| SD 卡 | 10 | Mode 0 | 4MHz (初始化 400KHz) |
| SSD1306 OLED | 5 | Mode 0 | 8MHz |
| MFRC522 RFID | 10 | Mode 0 | 4MHz |
| MAX7219 LED | 10 | Mode 0 | 10MHz |
| W5500 以太网 | 10 | Mode 0 | 8MHz |
