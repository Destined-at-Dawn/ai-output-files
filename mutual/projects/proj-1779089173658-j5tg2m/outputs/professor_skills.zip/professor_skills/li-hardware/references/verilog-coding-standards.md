# Verilog/SystemVerilog Coding Standards

> Source: hardware-design v5.0

## 1. always_ff: Simple Assignments Only

`always_ff` blocks: ONLY simple non-blocking assignments. No logic, no expressions.

```systemverilog
always_ff @(posedge clk) begin
    count <= count_next;
    state <= state_next;
end
```

Exceptions: memory inference and async reset synchronizers.

## 2. always_comb: All Logic Here

```systemverilog
always_comb begin
    count_next = count + 8'd1;
    state_next = enable ? RUNNING : IDLE;
end
```

## 3. Naming

- Active-low: `_n` suffix (rst_n)
- Clocks: `clk` or `clk_<domain>`
- Modules: lowercase, Params: ALL_CAPS, States: S_IDLE

## 4. Formatting

- One statement per line
- Explicit bit widths on all literals
- Start files with `default_nettype none`
- Always use begin/end for if/else/case
- Keep modules < 500 lines

## 5. Module Instantiation: Named Ports Only

```systemverilog
counter #(.WIDTH(16)) u_counter (
    .clk(clk), .rst_n(rst_n), .count(count_value)
);
```

## 6. Avoiding Latches

Default assignments at start of always_comb:

```systemverilog
always_comb begin
    data_next = data_reg;
    valid_next = 1'b0;
    case (state)
        IDLE: data_next = 8'd0;
        LOAD: data_next = data_in;
        default: data_next = data_reg;
    endcase
end
```

## 7. Reset

- Prefer synchronous reset
- External async reset -> 2-FF synchronizer first
