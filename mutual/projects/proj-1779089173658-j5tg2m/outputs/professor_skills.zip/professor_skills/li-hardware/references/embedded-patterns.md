# 嵌入式调试模式库

> 来源：RoboMaster 步兵电控项目实战
> 适用：Arduino/ESP32/STM32/任何 MCU 控制系统

## PID 调参铁律

1. **先只开 P**，用很小 kp 验证输出方向
2. 方向反了先改电机方向或角度符号，不要调 PID
3. 再逐步加 D 抑制震荡
4. **调参前先确认反馈方向**（陀螺仪 vs 编码器，正方向定义）

## 急停 = 输出归零 + 状态清零

```c
// 错误：只清输出
void Emergency_Stop() { motor_out = 0; }

// 正确：清输出 + 清 PID 内部状态
void Emergency_Stop() {
    motor_out = 0;
    PID_Reset(&pid_chassis);
    PID_Reset(&pid_gimbal);
}
```

## 限位从目标源头做

```c
// 错误：只限输出
motor_out = clamp(motor_out, -100, 100);

// 正确：在更新目标角后立即限位
pitch_target = Robot_LimitFloat(pitch_target, -20.0f, 30.0f);
motor_out = PID_Calc(&pid_pitch, pitch_target, pitch_actual);
```

## CAN 通信排查优先级

排查顺序（从物理层往上）：
1. **物理层**：CANH/CANL 接反？上电了？
2. **波特率**：两端波特率一致？
3. **过滤器**：CAN 过滤器配置正确？
4. **电调 ID**：电调 ID 与代码中一致？

## 按键消抖

```c
#define REMOTE_DEBOUNCE_MS 50

void Button_Update() {
    if (GPIO_Read() != last_state) {
        last_state = GPIO_Read();
        debounce_timer = REMOTE_DEBOUNCE_MS;
    }
    if (debounce_timer > 0) debounce_timer--;
    else confirmed_state = last_state;
}
```

## 实车调试清单

- [ ] 四轮悬空 -> 单轮小输出 -> 确认编号
- [ ] PID 调参前反馈方向确认
- [ ] 急停/复位是否清了 PID 内部状态
- [ ] 限位是否从目标源头做
- [ ] CAN 问题从物理层开始排查
- [ ] 文档中哪些功能真正上板测试过，是否明确标注
