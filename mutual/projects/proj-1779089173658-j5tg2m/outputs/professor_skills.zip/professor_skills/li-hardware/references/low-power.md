# 低功耗设计指南

> 电池供电场景的功耗优化

---

## ESP32 低功耗模式

| 模式 | 电流 | 唤醒源 | 适用场景 |
|------|------|--------|---------|
| Active | 80mA | — | 正常运行 |
| Modem Sleep | 20mA | 定时器 | WiFi 连接但不传输 |
| Light Sleep | 0.8mA | 定时器/外部中断 | 周期性测量 |
| Deep Sleep | 10μA | 定时器/外部中断 | 长时间休眠 |
| Hibernation | 2.5μA | RTC 定时器 | 极低功耗 |

---

## Deep Sleep 模板（ESP32）

```cpp
#define uS_TO_S 1000000
#define SLEEP_TIME 60 // 秒

void setup() {
  Serial.begin(115200);
  
  // 读取唤醒原因
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
  if (cause == ESP_SLEEP_WAKEUP_TIMER) {
    Serial.println("Wakeup from timer");
  }
  
  // 传感器测量
  float temp = readSensor();
  sendData(temp);
  
  // 配置定时唤醒
  esp_sleep_enable_timer_wakeup(SLEEP_TIME * uS_TO_S);
  
  // 进入 Deep Sleep
  Serial.println("Going to sleep...");
  esp_deep_sleep_start();
}

void loop() {
  // 不会执行到这里
}
```

---

## Arduino 低功耗

### 库：LowPower

```cpp
#include <LowPower.h>

void loop() {
  readSensor();
  sendData();
  
  // 休眠 8 秒（最长单次休眠）
  LowPower.powerDown(SLEEP_8S, ADC_OFF, BOD_OFF);
}
```

### 硬件优化

| 优化 | 效果 | 方法 |
|------|------|------|
| 降频 | 减少 50% 电流 | `clock_prescale(2)` / `clock_prescale(4)` |
| 关 ADC | 减少 0.3mA | `ADCSRA &= ~(1<<ADEN)` |
| 关 BOD | 减少 0.1mA | `sleep_bod_disable()` |
| 关 LED | 减少 5-20mA | 移除板载 LED 限流电阻 |

---

## 电源管理电路

### 锂电池 + LDO

```
锂电池(3.7V) → LDO(3.3V) → ESP32
                ↓
           充电管理(TP4056)
```

### 锂电池 + 升压

```
锂电池(3.7V) → 升压模块(5V) → Arduino
                ↓
           充电管理(TP4056)
```

---

## 功耗计算公式

```
电池寿命(天) = 电池容量(mAh) / 平均电流(mA) / 24

例：1000mAh 电池，平均 1mA → 1000/1/24 = 41.6 天
```
