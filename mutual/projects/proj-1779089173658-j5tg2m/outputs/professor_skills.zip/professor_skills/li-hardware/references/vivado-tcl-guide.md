# Vivado TCL 速查表 + 陷阱清单

> 来源：竞赛区 LCD 驱动项目实战 + 安全通信系统项目
> 更新：2026-06-09

## 工程管理

- 路径用正斜杠：`D:/AMD/tft_logo`（反斜杠 `\t` 会被解释为 tab）
- 综合：`launch_runs synth_1 -jobs 16` -> `wait_on_run synth_1`
- 代码改了必须先 `reset_run synth_1` 再跑
- 实现+比特流一步到位：`launch_runs impl_1 -to_step write_bitstream -jobs 16`

## IP 核操作铁律

1. `create_ip` 前必须 `file mkdir` 输出目录
2. `generate_target` 后必须 `add_files` wrapper
3. 禁止写死 IP 版本号（不同 Vivado 版本 IP 版本不同）
4. IP 核文件不用手动 add_files（.xci 自动管理）
5. 修改 IP 配置不要手动改 .xci，用 `set_property -dict`
6. IP 单独综合必须先跑完再跑顶层综合（`wait_on_run`）
7. IP 核必须 `set_property generate_synth_checkpoint false` 禁用 OOC

## 中文 Windows 环境铁律

TCL 脚本开头必须覆写环境变量：
```tcl
set ::env(COMPUTERNAME) "PC"
set ::env(USERNAME) "user"
```

原因：`.Xil/Vivado-PID-USERNAME/` 被中文用户名污染 -> OOC 子进程 parameters.tcl 创建失败 -> 静默崩溃

## DRC 降级（先生成 bit 再补约束）

```tcl
set_property SEVERITY {Warning} [get_drc_checks NSTD-1]
set_property SEVERITY {Warning} [get_drc_checks UCIO-1]
```

必须在 reset_run 之前跑。

## 仿真

- Vivado 2020.1 不支持 `launch_simulation -behavioral`
- `$display` 输出不在 TCL Console，而在 `sim_1/behav/xsim/simulate.log`
- 仿真默认只跑 1000ns，要在 xsim 控制台 `run all`
- TB 的 module 名要和 `set_property top` 一致

## 踩过的坑（12 条）

| # | 陷阱 | 后果 | 正确做法 |
|---|------|------|---------|
| 1 | 路径用反斜杠 | `\t` 被解释为 tab | 一律用正斜杠 |
| 2 | launch_simulation -behavioral | 2020.1 不支持 | 不加该参数 |
| 3 | $display 输出看 TCL Console | 看不到 | 去 simulate.log |
| 4 | generate_synth_checkpoint 在 IP 文件前调用 | 报错 | 先 generate_target |
| 5 | 手动 add_files IP 核文件 | 重复/冲突 | .xci 自动管理 |
| 6 | TB module 名不一致 | 仿真找不到 top | 确认 set_property top |
| 7 | 仿真默认 1000ns | 信号没跑完 | run all |
| 8 | wrapper 文件没 add_files | 综合找不到 | generate_target 后 add_files |
| 9 | DRC 降级在 reset_run 后 | 不生效 | 在 reset_run 前跑 |
| 10 | 手动改 .xci | IP 锁死 | set_property -dict |
| 11 | IP 和顶层同时综合 | 竞态 | 先 IP 后顶层，wait_on_run |
| 12 | TB 用 SystemVerilog 语法 | XSIM 报错 | 纯 Verilog-2001 |
