## References Index

| File | Content | Lines |
|------|---------|-------|
| vivado-tcl-guide.md | 12 TCL traps + create_project.tcl template | 64 |
| crc-debugging.md | CRC 3-dimension + Python verification | 51 |
| simulation-debug-9step.md | Debug fast-to-slow 9 steps | 35 |
| embedded-patterns.md | PID/CAN/e-stop/debounce from RM | 68 |
| verilog-iron-laws.md | 10 iron laws + XSIM limits | 56 |
| fpga-delivery-checklist.md | RTL+DOCX+ZIP delivery checklist | 53 |
| uart-rx-patterns.md | UART RX 4 common errors | 41 |
| vendor-code-porting.md | Vendor code diff != bug | 30 |
| gpio-safety-checklist.md | GPIO 6-category safety | existing |
| case-studies.md | Real project cases | existing |
| templates/ | Servo/PCA9685/I2C/SPI templates | existing |
| verilog-coding-standards.md | always_ff/always_comb/naming/formatting/latches | new |
| fsm-patterns.md | enum + separated register/next-state logic | new |
| cdc-synchronizers.md | 2-FF sync + gray code + async FIFO | new |
| yosys-verilator.md | Yosys avoid list + Verilator lint/sim/tb | new |
| fpgabuilder-patterns.md | 7 patterns: config-driven/TCL template/hook/version adapter | new |
| i2c-touchscreen-pitfalls.md | FT6336U 12 bugs, iron rules 8-15, I2C checklist | new |

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |


## 联动技能

- **li-debug, li-research, li-devil, li-sync, li-improve, li-local-search**
- 联动方式：上游skill决定何时调用本skill，本skill专注核心能力
- 联动触发条件：上游skill的Phase中明确写了调用本skill的步骤
- 联动验证：联动成功后由li-memory记录事实，li-improve记录教训


## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈

## 案例库

### 案例 1：XC7A35T FPGA 项目 ROM OOM
**场景**：Vivado 综合时报 Block RAM 不足，但代码只用了少量 ROM
**诊断**：`$readmemh` 加载的 .hex 文件超过 10KB，自动推断为 BRAM 但未声明 `(* rom_style = "block" *)`
**结果**：手动声明 BRAM 属性 + 优化 hex 文件大小，综合通过
**教训**：ROM > 10KB 必须显式声明 BRAM，不能靠 Vivado 自动推断

### 案例 2：PCA9685 16 路舵机场景编排
**场景**：C919 皮影项目 18 舵机，需要编排复杂的动作序列
**诊断**：逐个控制舵机无法实现同步动作
**结果**：设计 ActionFrame/ActionGroup/Scene 三层架构，16 路同步
**教训**：多舵机协同必须用场景编排架构，不能逐个控制

### 案例 3：Vivado 中文环境 TCL 脚本失败
**场景**：Windows 中文系统下 Vivado TCL 脚本执行报编码错误
**诊断**：Vivado TCL 解析器不支持 GBK 编码的中文注释
**结果**：所有 TCL 文件用纯 ASCII + 英文注释，路径用短路径
**教训**：Vivado TCL 文件禁止中文，包括注释和路径