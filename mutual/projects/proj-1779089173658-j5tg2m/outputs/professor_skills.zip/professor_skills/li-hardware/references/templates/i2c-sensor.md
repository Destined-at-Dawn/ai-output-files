# I2C 传感器模板

> 温湿度 / 距离 / 加速度传感器通用模板

---

## I2C Scanner（调试必备）

```cpp
#include <Wire.h>

void setup() {
  Wire.begin();
  Serial.begin(115200);
  Serial.println("I2C Scanner");
}

void loop() {
  byte count = 0;
  for (byte addr = 1; addr < 127; addr++) {
    Wire.beginTransmission(addr);
    if (Wire.endTransmission() == 0) {
      Serial.print("Found device at 0x");
      Serial.println(addr, HEX);
      count++;
    }
  }
  Serial.print("Total devices: ");
  Serial.println(count);
  delay(3000);
}
```

---

## DHT20 温湿度传感器（I2C）

```cpp
#include <Wire.h>

#define DHT20_ADDR 0x38

void setup() {
  Wire.begin();
  Serial.begin(115200);
  delay(100);
}

void loop() {
  // 触发测量
  Wire.beginTransmission(DHT20_ADDR);
  Wire.write(0xAC);
  Wire.write(0x33);
  Wire.write(0x00);
  Wire.endTransmission();
  
  delay(80); // 等待测量完成
  
  // 读取 7 字节
  Wire.requestFrom(DHT20_ADDR, 7);
  if (Wire.available() == 7) {
    byte data[7];
    for (int i = 0; i < 7; i++) data[i] = Wire.read();
    
    // 解析温湿度
    uint32_t humi = ((uint32_t)data[1] << 12) | ((uint32_t)data[2] << 4) | (data[3] >> 4);
    uint32_t temp = (((uint32_t)data[3] & 0x0F) << 16) | ((uint32_t)data[4] << 8) | data[5];
    
    float humidity = humi * 100.0 / 1048576.0;
    float temperature = temp * 200.0 / 1048576.0 - 50.0;
    
    Serial.printf("Temp: %.1f°C, Humi: %.1f%%\n", temperature, humidity);
  }
  delay(2000);
}
```

---

## MPU6050 加速度计/陀螺仪

```cpp
#include <Wire.h>
#include <MPU6050_tockn.h>

MPU6050 mpu(Wire);

void setup() {
  Serial.begin(115200);
  Wire.begin();
  mpu.begin();
  mpu.calcGyroOffsets(true); // 自动校准
}

void loop() {
  mpu.update();
  Serial.printf("AccX:%.2f AccY:%.2f AccZ:%.2f\n",
    mpu.getAccX(), mpu.getAccY(), mpu.getAccZ());
  delay(10);
}
```

---

## 常见 I2C 设备地址表

| 设备 | 地址 | 备注 |
|------|------|------|
| DHT20 | 0x38 | 固定地址 |
| MPU6050 | 0x68 | AD0=LOW, 0x69=HIGH |
| BMP280 | 0x76 | SDO=LOW, 0x77=HIGH |
| SSD1306 OLED | 0x3C | 128×64, 0x3D=128×32 |
| PCA9685 | 0x40 | A0-A5 可改 |
| ADS1115 | 0x48 | ADDR=GND |
| VL53L0X | 0x29 | 固定地址 |
