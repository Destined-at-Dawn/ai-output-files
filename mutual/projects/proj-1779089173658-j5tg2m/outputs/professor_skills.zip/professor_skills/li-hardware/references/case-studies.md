# Case Studies - Real Delivery Projects

## Case 1: ADC1+DAC1 Loopback (D:\AMD)

ADC081C021 via I2C -> DAC081C085 replay. Three-layer arch.
Key: Sample rate limited by I2C bandwidth, not ADC (150kSPS vs 5.2kSPS at 400kHz).
4kSPS default, 100Hz shows staircase (Nyquist).

## Case 2: AT21CS01 EEPROM (D:\AMD)

NOT Dallas 1-Wire! High-speed default after reset.
Warm reset: 600us low, 50ms recharge, 200us release.
Address scan 0..7 (don't hardcode).
LED feedback: D0=done&pass, D1=done&fail.

## Case 3: C919 Shadow Puppet - 18 Servos (竞赛)

Arduino + 2x PCA9685 + 18 DF9GMS. Scene-based choreography:
- ActionFrame = {charID, jointID, targetAngle, duration}
- ActionGroup = parallel frames
- Scene = groups + LED settings
- Smooth interpolation: max steps across group, time-proportional
- Power: separate 5V 3A (NOT Arduino USB)

## Case 4: LCD ST7796S SPI (竞赛)

480x320 TFT, 9-bit SPI (8 data + D/C). 10-state FSM.
RGB888 in ROM, truncate to RGB565 at output (future-proof).
29583x16 ROM needed BMG IP ($readmemh OOM).

## Case 5: FT6336U Touchscreen (竞赛)

I2C capacitive touch + 7-segment display.
Extensive ILA with MARK_DEBUG on all I2C signals.
Tri-state SDA control.

## Case 6: RoboMaster Infantry (竞赛)

STM32 HAL: app/remote/chassis/gimbal/pid/safety/bsp_port.
X-type mecanum kinematics. PID with windup limit + output clamp.
BSP abstraction = platform-independent control code.
