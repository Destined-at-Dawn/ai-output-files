# I2C Touchscreen Driver Pitfalls (FT6336U, 12 Bugs)

> Source: hardware-design v5.0 (XC7A35T, 50MHz, ~8 hours debug)
> Iron Rules 8-15

## Rule 8: Multi-module Shared Constants Must Match

touch_ctrl CMD_START(=1) vs i2c_master CMD_WRITE(=1). Off by 1 = entire I2C fails.

Fix: grep all localparam CMD_, build comparison table before integration.

## Rule 9: I2C SDA Must Be Open-Drain

```verilog
// WRONG: push-pull (bus contention with slave)
assign i2c_sda = sda_oe ? sda_out : 1'bz;

// RIGHT: open-drain (FPGA only drives LOW)
assign i2c_sda = (sda_oe & ~sda_out) ? 1'b0 : 1'bz;
```

XDC: set_property PULLTYPE PULLUP [get_ports i2c_sda]

## Rule 10: No Global Error Detection Outside case

Check errors inside each case branch, not globally. Stale ack_err causes false positives.

## Rule 11: Hardware-default Signals Need No FPGA Pins

RST/BL/INT/VCC/GND: hardware handles. Only export communication and display lines.

## Rule 12: Chinese-comment .v Files Must Be GBK

Vivado Chinese Windows: UTF-8 = garbled. Convert to GBK after writing.

## Rule 13: C->Verilog I2C Port: Byte-by-byte Alignment

i2c_master is a byte engine. Device addr and register addr = two separate CMD_WRITE.

## Rule 14: Coordinate Mapping Constants: Hand-calc 3 Boundary Values

After writing mapping constant, verify: min(0), mid(max/2), max.

## I2C Design Checklist

- [ ] CMD encoding consistent across modules
- [ ] SDA open-drain
- [ ] Error detection local (not global)
- [ ] Watchdog timeout
- [ ] done pulse consumed only once
- [ ] rd_data latched only on READ done
- [ ] Coordinate mapping hand-verified
- [ ] No hardware-default signals exported
- [ ] GBK encoding for Chinese .v files
- [ ] Git init on day 1
