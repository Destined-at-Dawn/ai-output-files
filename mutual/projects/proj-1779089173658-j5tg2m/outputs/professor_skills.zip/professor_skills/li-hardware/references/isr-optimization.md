# ISR 优化指南

> 中断服务程序（Interrupt Service Routine）设计原则

---

## 核心原则

1. **ISR 必须尽可能短**：执行时间 < 10μs
2. **禁止在 ISR 中使用 delay()**：会阻塞整个系统
3. **禁止在 ISR 中使用 Serial.print()**：太慢
4. **用 volatile 标记共享变量**：防止编译器优化

---

## 模板：按键中断

```cpp
#define BUTTON_PIN 2
volatile bool buttonPressed = false;

void IRAM_ATTR buttonISR() {
  buttonPressed = true; // 只设标志，不做处理
}

void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), buttonISR, FALLING);
}

void loop() {
  if (buttonPressed) {
    buttonPressed = false;
    // 在主循环中处理，不在 ISR 中
    Serial.println("Button pressed!");
    delay(50); // 消抖
  }
}
```

---

## 模板：编码器中断

```cpp
#define ENC_A 2
#define ENC_B 3
volatile long encoderCount = 0;

void IRAM_ATTR encoderISR() {
  if (digitalRead(ENC_B)) {
    encoderCount++;
  } else {
    encoderCount--;
  }
}

void setup() {
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENC_A), encoderISR, RISING);
}

void loop() {
  long count;
  noInterrupts(); // 关中断读取（原子操作）
  count = encoderCount;
  interrupts();   // 开中断
  
  Serial.println(count);
  delay(100);
}
```

---

## ESP32 特殊注意

| 项目 | Arduino | ESP32 |
|------|---------|-------|
| ISR 标记 | `void isr()` | `void IRAM_ATTR isr()` |
| 中断引脚 | 仅 2, 3 | 所有 GPIO |
| 中断类型 | CHANGE/RISING/FALLING | 同左 |
| FreeRTOS 影响 | 无 | ISR 不能调用 FreeRTOS API（除非带 FromISR 后缀） |

---

## 常见错误

| 错误 | 后果 | 正确做法 |
|------|------|---------|
| ISR 中做复杂计算 | 阻塞其他中断 | 只设标志，主循环处理 |
| ISR 中用 Serial | 阻塞数十 ms | 用 volatile 标志 + 主循环打印 |
| 共享变量不加 volatile | 读到旧值 | 所有 ISR 共享变量加 volatile |
| 共享变量多字节不加锁 | 读到半更新值 | 用 noInterrupts()/interrupts() 包裹 |
