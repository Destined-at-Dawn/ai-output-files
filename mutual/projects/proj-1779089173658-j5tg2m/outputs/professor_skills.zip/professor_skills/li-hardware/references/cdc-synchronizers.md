# Clock Domain Crossing (CDC)

> Source: hardware-design v5.0

## Single-bit: 2-FF Synchronizer

```systemverilog
logic [1:0] sync_reg;
always_ff @(posedge clk_dst) begin
    sync_reg <= {sync_reg[0], signal_src};
end
assign signal_sync = sync_reg[1];
```

## Multi-bit: Gray Coding

```systemverilog
function automatic logic [W-1:0] bin2gray(input logic [W-1:0] bin);
    bin2gray = bin ^ (bin >> 1);
endfunction
```

Use for FIFO read/write pointers across clock domains.

## General: Async FIFO or Handshake

- Async FIFO: data streaming (high throughput)
- Handshake: control signals (low throughput, high reliability)

## Iron Rules

| # | Rule | Violation |
|---|------|-----------|
| 1 | External signals: min 2-FF sync | Metastability propagation |
| 2 | Edge detect AFTER sync | sig_d1 & ~sig_d2, never raw |
| 3 | Never sync multi-bit directly | Bit skew -> data corruption |
