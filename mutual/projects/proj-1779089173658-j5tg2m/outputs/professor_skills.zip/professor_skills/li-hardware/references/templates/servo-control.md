# Servo Control Templates

## DF9GMS / SG90 / MG996R PWM

| Servo | Min | Max | Freq | Resolution |
|-------|-----|-----|------|-----------|
| SG90 | 500us | 2400us | 50Hz | 10-bit |
| MG996R | 500us | 2500us | 50Hz | 10-bit |
| DF9GMS | 500us | 2500us | 50Hz | 12-bit (PCA9685) |

PCA9685 12-bit: 500us=102, 1500us=307(center), 2500us=512 at 20ms period.

## Arduino Scene Architecture (C919 pattern)

```cpp
struct ServoMapping { uint8_t pcaBoard, channel, homeAngle; };
struct ActionFrame { uint8_t charID, jointID, targetAngle; uint16_t duration; };
struct ActionGroup { ActionFrame frames[MAX]; uint8_t count; };
struct Scene { ActionGroup groups[MAX]; uint8_t count; uint16_t led[3]; };
```

Smooth interpolation: find max steps, time-proportional stepping.
Power: external 5V 3A+, common GND, 100uF decoupling.

## FPGA PWM Verilog

```verilog
module servo_pwm #(parameter CLK_FREQ=50000000, PWM_FREQ=50)(
  input clk, rst_n, input [7:0] angle, output reg pwm_out
);
  localparam PERIOD = CLK_FREQ/PWM_FREQ;
  localparam MIN_PULSE = PERIOD*500/20000;
  localparam MAX_PULSE = PERIOD*2500/20000;
  reg [19:0] counter, pulse_width;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin counter<=0; pulse_width<=MIN_PULSE; end
    else begin
      counter <= (counter<PERIOD-1) ? counter+1 : 0;
      pulse_width <= MIN_PULSE + (MAX_PULSE-MIN_PULSE)*angle/180;
      pwm_out <= (counter < pulse_width);
    end
  end
endmodule
```
