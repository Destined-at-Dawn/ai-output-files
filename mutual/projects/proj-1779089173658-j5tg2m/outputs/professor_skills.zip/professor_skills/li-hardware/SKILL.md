---
name: li-hardware
version: "3.1"
description: "Embedded hardware engineering - FPGA RTL + Arduino/ESP32 + servo control + RoboMaster. Grounded in real XC7A35T delivery projects, 17-bug audit, SOP-06 iron laws, and RM infantry control."
---
## [LIGHTNING] 执行协议（强制 - 禁止跳过）
> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**
### [RED] 必读（执行前必须读取，不可跳过）
- 执行前**必须** `Read references/verilog-iron-laws.md` - 不读 = 不了解核心方法论 = 产出不合格
- 执行前**必须** `Read references/delivery-sop.md` - 不读 = 不了解核心方法论 = 产出不合格
### [YELLOW] 按需（匹配场景时必须读取）
- 场景[FPGA架构] -> **必须** `Read references/fpga-architecture.md`
- 场景[I2C设计] -> **必须** `Read references/i2c-system-design.md`
- 场景[I2C触摸屏踩坑] -> **必须** `Read references/i2c-touchscreen-pitfalls.md`
- 场景[UART接收] -> **必须** `Read references/uart-rx-patterns.md`
- 场景[FSM模式] -> **必须** `Read references/fsm-patterns.md`
- 场景[CDC同步] -> **必须** `Read references/cdc-synchronizers.md`
- 场景[CRC调试] -> **必须** `Read references/crc-debugging.md`
- 场景[仿真调试9步] -> **必须** `Read references/simulation-debug-9step.md`
- 场景[Vivado经验] -> **必须** `Read references/vivado-lessons.md`
- 场景[Vivado TCL] -> **必须** `Read references/vivado-tcl-guide.md`
- 场景[Yosys/Verilator] -> **必须** `Read references/yosys-verilator.md`
- 场景[低功耗] -> **必须** `Read references/low-power.md`
- 场景[嵌入式模式] -> **必须** `Read references/embedded-patterns.md`
- 场景[ISR优化] -> **必须** `Read references/isr-optimization.md`
- 场景[GPIO安全] -> **必须** `Read references/gpio-safety-checklist.md`
- 场景[PCB基础] -> **必须** `Read references/pcb-basics.md`
- 场景[FPGA Builder模式] -> **必须** `Read references/fpgabuilder-patterns.md`
- 场景[调试方法论] -> **必须** `Read references/debug-methodology.md`
- 场景[交付检查清单] -> **必须** `Read references/fpga-delivery-checklist.md`
- 场景[代码规范] -> **必须** `Read references/verilog-coding-standards.md`
- 场景[厂商代码移植] -> **必须** `Read references/vendor-code-porting.md`
- 场景[补充材料] -> **必须** `Read references/supplementary.md`
- 场景[排障] -> **必须** `Read references/troubleshooting.md`
- 场景[案例] -> **必须** `Read references/case-studies.md`
### [STOP] 门禁
- Phase 执行前：确认已读取 references/verilog-iron-laws.md, references/delivery-sop.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）
# li-hardware v3.0
> Phase 0(safety) -> 1(questions) -> 2(design) -> 3(implement) -> 4(verify) -> 5(deliver)
> References loaded on-demand. This file <= 300 lines.
## Before You Start
- User asks "is there a library/IC for X" -> search DigiKey/Mouser/Adafruit first
- User asks "how does X work" -> read datasheet, don't guess
- All hardware advice must reference a datasheet, app note, or real measurement
## Theory Anchors
| ID | Principle | Source | Use |
|----|-----------|--------|-----|
| T1 | Fail-Safe Defaults | IEC 61508 | GPIO -> input/high-Z on reset |
| T2 | Three-Layer Arch | D:\AMD 3 deliveries | top=wire / ctrl=FSM / master=bus |
| T3 | Bandwidth First | D:\AMD I2C calc | Calculate bus budget before sample rate |
| T4 | Scene-Based Control | C919 puppet (18 servo) | ActionFrame/ActionGroup/Scene |
| T5 | One-Pass Delivery | D:\AMD SOP | RTL+DOCX+ZIP+cleanup in one pass |
| T6 | CRC Three-Dimension | 竞赛 17-bug audit | polynomial x bit-order x byte-order |
## Design Philosophy
1. Safety First: GPIO check before code
2. Real-Work Grounded: templates from actual deliveries
3. Three-Layer: top(wiring) / ctrl(FSM) / master(bus)
4. Bandwidth Calc: I2C/SPI budget before commit to rate
5. Progressive Disclosure: this file <= 300 lines
6. Platform-Aware: Arduino + ESP32 + FPGA parallel
7. External Search: "is there a library?" beats "let me write one"
8. Debug Fast-to-Slow: $display first, waveform last (refs/simulation-debug-9step.md)
9. Difference != Bug: vendor code diff needs HW verification (refs/vendor-code-porting.md)
10. E-Stop = Output + State: always clear PID integrals (refs/embedded-patterns.md)
## Phase 0: Safety Gate (MUST complete before any code)
```
1. Voltage: VCC=?V, signal=?V, abs max=?V
2. Current: source/sink per pin <= datasheet limit
3. ESD: external IC? Pull-ups correct?
4. Short: any pin directly to VCC/GND?
5. Thermal: continuous > 100mA? Heatsink?
6. Cross-ref: D:\AMD lessons apply?
FAIL any -> STOP, inform user, propose fix.
```
Details: references/gpio-safety-checklist.md
## Phase 1: Requirement Clarification
| Question | Why | Options |
|----------|-----|---------|
| Target platform? | Code path | Arduino/ESP32/STM32/FPGA |
| FPGA device? | Resources | XC7A35T/Cyclone10 LP/DE2-115 |
| Peripherals? | Interface | I2C/SPI/UART/ADC/DAC/PWM |
| Power supply? | Budget | USB 5V / External 12V / Battery |
| Real-time? | ISR vs poll | Hard(ISR) / Soft(poll) / Best-effort |
| Delivery? | Package | Code / Code+DOCX+ZIP / Full Vivado |
| Multi-servo? | Architecture | Single(direct) / Multi(scene) / 18+(C919) |
## Phase 2: Design
### FPGA: Three-Layer (from 3 XC7A35T deliveries)
```
*_top.v    -- Wiring only. NO logic.
*_ctrl.v   -- FSM + timing + protocol sequencing
*_master.v -- Bus driver (I2C/SPI/UART byte-level)
```
Naming: modules=lowercase, params=ALL_CAPS, states=S_IDLE, resets=rst_n, tb=tb_xxx
TCL: references/fpga-architecture.md
### Arduino/ESP32
```
config.h      -- I2C addresses, PWM params, pin assignments
characters.h  -- Device/character definitions (ServoMapping)
scenes.h      -- Motion choreography (ActionFrame/ActionGroup/Scene)
main.ino      -- Setup + loop + mode (auto/debug/demo)
```
Scene arch (C919, 18 servos):
- ActionFrame = {deviceID, jointID, targetAngle, duration}
- ActionGroup = parallel frames
- Scene = ordered groups + LED settings
### I2C: Bandwidth-First
```
At 400kHz SCL: 77 bit slots/ADC+DAC pair = ~5.2 kSPS max
At 100kHz: ~1.3 kSPS max
```
Details: references/i2c-system-design.md
## Phase 3: Implementation
1. Generate code per template (references/templates/)
2. Safety checks from Phase 0
3. FPGA: ROM > 10KB -> `(* rom_style = "block" *)` (IRON RULE)
4. FPGA: ROM depth -> 2^n aligned (IRON RULE)
5. FPGA: TCL set env(USERNAME) for Chinese Windows
6. Arduino: Servos separate 5V 3A power, NOT USB
7. Add ILA/debug signals (FPGA), Serial.print (Arduino)
## Phase 4: Verification
### FPGA Checklist (from D:\AMD SOP)
- [ ] Synthesis PASS
- [ ] Testbench PASS
- [ ] XDC pins = README = top.v ports
- [ ] ILA probes on key signals
- [ ] Source ASCII-only
- [ ] TCL clean-build works
- [ ] Resource utilization OK
### Arduino Checklist
- [ ] Compiles for target board
- [ ] I2C scan finds devices
- [ ] Servo PWM within mechanical limits
- [ ] Peak current < supply capacity
- [ ] Serial debug working
### Delivery Checklist
- [ ] RTL/Code complete
- [ ] README with arch + pinout + build
- [ ] XDC verified against schematic
- [ ] TCL scripts (build/synth/bitstream)
- [ ] ZIP function-named
- [ ] DOCX lab manual (if required)
## Phase 5: Deliver
1. Package: code + constraints + build scripts + README
2. ZIP name by function: `ADC1采样_DAC1回放.zip`
3. Workspace: copy to delivery dir, never delete originals
4. Append lesson to case-studies.md + golden_rules.md
## Li-Series Integration
| Trigger | Route |
|---------|-------|
| Arduino/舵机/servo | li-hardware P0-3 |
| FPGA/Verilog/Vivado | li-hardware P0-4 (three-layer) |
| I2C bandwidth/采样率 | li-hardware -> refs/i2c-system-design.md |
| debug/sim fail/synth error | li-hardware -> refs/debug-methodology.md |
| deliver/pack/发给老板 | li-hardware P5 -> refs/delivery-sop.md |
## 反模式
| # | Pattern | Source | Consequence |
|---|---------|--------|-------------|
| AP1 | ROM>10KB no BRAM attr | 竞赛 OOM | Vivado crash |
| AP2 | ROM depth non-2^n | 竞赛 OOM | Mux explosion |
| AP3 | Chinese env vars | D:\AMD 7-fail | .Xil corruption |
| AP4 | Servo shares USB power | C919 | Brownout jitter |
| AP5 | I2C rate without calc | D:\AMD | Missed deadline |
| AP6 | XDC not synced | D:\AMD | Pin mismatch |
| AP7 | Skip delivery checklist | D:\AMD SOP | No DOCX/ZIP |
| AP8 | $readmemh for ROM>16K | D:\AMD 7-fail | OOM |
| AP9 | TCL backslash paths | D:\AMD | Tab corruption |
| AP10 | Manual .xci edit | 竞赛 IP lock | stale content error |
| AP11 | XSIM + SystemVerilog | 竞赛 | fork/join_any/break all fail |
| AP12 | Guess encoding then bulk convert | 竞赛 3x犯错 | UTF-8->GBK->UTF-8 loop |
| AP13 | E-stop only clears output | RM infantry | PID integral -> motor surge |
| AP14 | Limit output not target | RM infantry | Mechanical collision |
| AP15 | Diff = Bug (vendor code) | SOP-08 | False positive, HW passes |
| AP16 | Analysis = Modification | 竞赛 I2C | User asked analysis, AI changed 4 files |
| AP17 | No backup = data disaster | 竞赛 D盘 | 124K files lost, 954GB bad sectors |
| AP18 | Batch delete $display | 竞赛 | Empty if -> wrong logic |
| AP19 | Debug starts at waveform | SOP-06 | 3-5x slower |
| AP20 | Multi-module constants assumed same | SOP-06 | Communication chaos |
| AP21 | Multi-phase task: verify only at end | 竞赛 SOP-14 | Dialog truncation -> 2 gaps undetected |
## 条件下一步
| Condition | Action |
|-----------|--------|
| Multi-servo (>4) | -> scene arch (refs/templates/servo-control.md) |
| FPGA synth fails | -> refs/vivado-tcl-guide.md FIRST (12 traps) |
| I2C contention | -> bandwidth calc (refs/i2c-system-design.md) |
| Chinese Windows+Vivado | -> env(USERNAME) in ALL TCL |
| ROM > 10KB | -> BMG IP core, NOT $readmemh |
| Customer delivery | -> refs/fpga-delivery-checklist.md |
| STM32/RoboMaster | -> refs/embedded-patterns.md (PID/CAN/e-stop) |
| CRC mismatch | -> refs/crc-debugging.md (3-dimension) |
| UART RX broken | -> refs/uart-rx-patterns.md (4 common errors) |
| Sim fails, don't know why | -> refs/simulation-debug-9step.md (fast-to-slow) |
| Vendor code comparison | -> refs/vendor-code-porting.md (diff != bug) |
| Verilog encoding issues | -> refs/verilog-iron-laws.md (iron law #6) |
| Batch code changes | -> Diff Review (check empty if/end) |
| I2C SDA open-drain | -> refs/verilog-iron-laws.md (iron law #7) |
| No backup strategy | -> 3-2-1 rule (3 copies, 2 media, 1 offsite) |
## 案例库
### Case 1: PCA9685 舵机控制板 I2C 地址冲突
- **场景**：C919 皮影戏 18 舵机项目，PCA9685 级联第二块板不响应
- **根因**：I2C 地址 0x40/0x41 只改了硬件跳线，没改代码里的地址常量
- **修复**：先用 `i2c_scanner` 确认地址，再修改 `#define PCA9685_ADDR 0x41`
- **教训**：硬件改动后必须同步验证软件配置
> More cases in references/case-studies.md
## 联动技能
| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-debug** | FPGA 仿真失败 → 纪律化调试循环 | "仿真不过""波形不对""timing fail" |
| **li-research** | 选型调研（MCU/传感器/驱动） | "选哪款芯片""比较 ESP32 和 STM32" |
| **li-skillcreate** | 项目特定模板提取为新 skill | "把这个硬件流程固化" |
| **li-sync** | 竞赛区经验同步到 li-hardware references/ | "竞赛区新经验同步" |
| **li-analyze** | datasheet 深度分析 | "分析这个 datasheet""寄存器详解" |
| **li-devil** | 硬件方案决策质疑（选型/架构） | "这个方案可行吗""有没有风险" |
## 外部参考
| Source | Key Learning |
|--------|-------------|
| D:\AMD 3 FPGA deliveries | Three-layer arch, TCL, I2C bandwidth |
| 竞赛 C919 puppet | 18-servo scene choreography |
| 竞赛 17-bug audit | CRC 3-dim, UART RX arch, sim debug 9-step |
| 竞赛 SOP-06 v1.9 | 10 iron laws, FPGA build automation, XSIM limits |
| 竞赛 SOP-08 | Vendor porting: diff != bug |
| 竞赛 SOP-12/13 | RTL one-pass delivery, customer handoff |
| 竞赛 Vivado TCL cheatsheet | 12 traps, create_project.tcl template |
| RM infantry control | PID tuning, CAN debug, e-stop, debounce |
| Jeffallan/embedded (459 star) | ISR/FreeRTOS templates |
| ezrover/ESP32 (7 star) | GPIO 6-category safety |
> 更多详细内容见 references/supplementary.md
