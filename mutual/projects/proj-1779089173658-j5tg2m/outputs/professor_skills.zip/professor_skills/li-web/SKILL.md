---
name: li-web
version: "1.0"
description: li系列 · 网页开发（React/HTML/Vercel/仪表盘）
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/tech-stack-guide.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[性能检查清单] -> **必须** `Read references/performance-checklist.md`
- 场景[反模式] -> **必须** `Read references/anti-patterns.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/tech-stack-guide.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-web

## 元数据
版本: 1.0 | 难度: 专业 | 预估时间: 15-60min | 频次控制: 无限

## 触发词
网页制作, 做网站, 落地页, landing page, 前端开发, web开发,
React, HTML, CSS, JavaScript, 部署, vercel, dashboard,
仪表盘, 数据可视化, 交互原型, web应用, 网站设计, lazyweb,
单页应用, SPA, 响应式设计, 前端组件

## Phase 0: 需求消解
1. 项目类型: 落地页/仪表盘/博客/工具应用/原型/展示页？
2. 技术栈: 纯HTML/CSS/React/Vue/Next.js？
3. 复杂度: 静态页面/有交互/全功能应用？
4. 部署: 本地预览/Vercel部署/GitHub Pages/其他？
5. 设计参考: 有参考截图/从零设计/使用现有组件库？
6. 数据: 静态内容/需要API/实时数据？

## Phase 1: 执行路径

### 路径A: 网页设计与构建 (web-design-engineer)
适用: 高质量视觉Web制品 — 页面/原型/幻灯片/动画/数据可视化
工具: web-design-engineer 设计工程师方法论
流程:
1. 理解需求 → 决定是否需要追问
2. 选择大胆美学方向(不是generic AI风格)
3. 实现代码: HTML/CSS/JS/React
4. 精细打磨: 每个像素有意为之

### 路径B: Web制品快速构建 (web-artifacts-builder)
适用: 快速构建Web页面/组件/交互制品
工具: web-artifacts-builder 工作流
流程: 需求确认 → 组件选择 → 快速搭建 → 迭代优化

### 路径C: Vercel生态开发
适用: Next.js/React/部署到Vercel
工具: vercel-* 系列技能(composition-patterns/deploy/react-best-practices等)
流程:
1. 项目初始化(create-next-app)
2. 组件开发(React最佳实践)
3. 页面路由(Next.js App Router)
4. 部署(vercel deploy)

### 路径D: 真实应用参考设计 (lazyweb)
适用: 需要参考真实应用截图进行设计
工具: lazyweb-skill MCP
流程: 获取真实应用截图 → 分析设计模式 → 应用到当前项目

## Phase 2: 质量验证
- 响应式？(手机/平板/桌面三端测试)
- 性能？(首屏加载<3s, Lighthouse分数)
- 可访问性？(键盘导航/屏幕阅读器/对比度)
- 跨浏览器？(Chrome/Firefox/Safari)
- SEO？(meta标签/语义化HTML/结构化数据)

## 理论锚点

| ID | 理论 | 来源 | 应用 |
|----|------|------|------|
| T1 | 认知负荷理论 | 001-学习之道 §概念1 | 页面布局降低用户认知负荷 |
| T10 | 反馈回路 | 005-系统之美 §概念2 | 用户行为数据 → 页面优化 → 更好体验 |
| T5 | 损失厌恶 | 046-反脆弱 §概念2 | 加载速度慢 = 用户流失（损失厌恶驱动） |

## 案例库
### 案例1: FPGA项目展示页
触发: "帮我做个FPGA项目展示网页" → li-web Phase 0(展示页, React) → 路径A + 路径C
流程: 暗黑科技风格 → 数据可视化组件 → Next.js实现 → Vercel部署
教训: 技术展示页需要live demo或GIF, 纯文字没人看

### 案例2: 小红书博主落地页
触发: "帮我做个个人落地页" → li-web Phase 0(落地页, 纯HTML) → 路径A
流程: 极简风格 → 单页设计 → 社交链接 → 移动优先
教训: 落地页核心是CTA(行动号召), 不要把所有信息都塞进去

### 案例3: 数据仪表盘
触发: "做个数据dashboard" → li-web Phase 0(仪表盘) → 路径A + li-analyze
流程: 数据结构设计 → 图表组件(Chart.js) → 实时更新 → 响应式布局
教训: 仪表盘信息层级最重要: 关键KPI放最上面, 详情可折叠



## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式
- ❌ Generic AI风格 — 紫色渐变+白色背景+Inter字体 = 千篇一律
- ❌ 不考虑移动端 — 只在桌面测试 = 手机上布局崩坏
- ❌ 过度动画 — 每个元素都有入场动画 = 用户等不及
- ❌ 不优化图片 — 原图直接放网页 = 加载慢5倍
- ❌ 忽略SEO — 没有meta标签/语义化 = 搜索引擎找不到

## 联动技能
- li-design: 视觉设计方向/品牌一致性
- li-image: 网页配图/图标生成
- li-analyze: 数据分析支撑仪表盘
- li-debug: 前端问题排查
- li-deploy: 部署与运维


## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 禁忌

- **禁止**：不设 viewport meta 就做移动端——`<meta name=viewport>` 是必须
- **禁止**：用 `!important` 解决所有 CSS 问题——这是懒惰不是技术
- **禁止**：不处理 API 错误——`catch` 块不能为空
