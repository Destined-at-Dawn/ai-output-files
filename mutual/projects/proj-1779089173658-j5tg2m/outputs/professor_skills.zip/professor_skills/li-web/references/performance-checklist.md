# Web性能优化清单

## 加载性能
- [ ] 首屏FCP < 1.8s
- [ ] LCP < 2.5s
- [ ] CLS < 0.1
- [ ] JS bundle < 200KB (gzipped)
- [ ] 图片: WebP/AVIF格式 + 懒加载
- [ ] 字体: font-display: swap + 预加载

## 渲染性能
- [ ] 无布局抖动(layout shift)
- [ ] 动画用transform/opacity(GPU加速)
- [ ] 长列表用虚拟滚动
- [ ] 避免forced synchronous layout

## 网络优化
- [ ] HTTP/2或HTTP/3
- [ ] CDN静态资源
- [ ] 缓存策略: 静态资源1年, HTML no-cache
- [ ] gzip/brotli压缩

## Lighthouse目标
- Performance: >= 90
- Accessibility: >= 90
- Best Practices: >= 90
- SEO: >= 90
