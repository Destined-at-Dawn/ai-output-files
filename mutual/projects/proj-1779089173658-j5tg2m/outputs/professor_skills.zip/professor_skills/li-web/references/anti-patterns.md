# Web开发反模式库

## AP-001: div soup
现象: 所有元素都用div, 没有语义化标签
根因: div最"灵活"
解决: 用header/nav/main/section/article/footer等语义标签

## AP-002: 内联样式泛滥
现象: style={{}} 到处写, 没有CSS变量/类名
根因: 觉得内联更快
解决: Tailwind CSS或CSS Modules, 样式可复用可维护

## AP-003: 不处理加载状态
现象: 数据加载时页面空白/闪烁
根因: 没有loading/skeleton状态
解决: Suspense + Loading UI / Skeleton Screen

## AP-004: 硬编码数据
现象: API地址/配置写死在代码里
根因: 开发时方便
解决: 环境变量(.env) + 配置文件

## AP-005: 不做错误边界
现象: 一个组件报错整个页面白屏
根因: 没有Error Boundary
解决: React Error Boundary + 降级UI

## AP-006: 图片不设尺寸
现象: 图片加载时页面布局跳动
根因: 没有width/height或aspect-ratio
解决: 图片标签必须设width+height或CSS aspect-ratio
