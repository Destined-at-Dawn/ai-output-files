# Web技术栈选型指南

## 按项目类型选型

| 项目类型 | 推荐栈 | 理由 |
|---------|--------|------|
| 静态展示页 | 纯HTML/CSS/JS | 简单直接, 无需构建 |
| 落地页 | HTML + Tailwind CSS | 快速搭建, 响应式 |
| 博客/内容站 | Next.js + MDX | SSG + SEO优化 |
| 仪表盘 | React + Chart.js | 组件化 + 数据可视化 |
| 全功能Web应用 | Next.js + TypeScript | 全栈能力 + 类型安全 |
| 快速原型 | React + shadcn/ui | 组件库加速开发 |

## Vercel部署速查
```bash
# 安装CLI
npm i -g vercel

# 部署
vercel

# 生产部署
vercel --prod

# 环境变量
vercel env add MY_VAR
```

## React最佳实践(摘要)
- 用Server Components减少客户端JS
- 组合模式(Composition)优于继承
- 状态最小化: 能不用state就不用
- Suspense + Loading UI提升感知性能
