# 黄金规则 — li-web

## GR-001: 拒绝Generic AI风格
- 来源: web-design-engineer 设计哲学
- 规则: 每个网页必须有明确的美学方向, 禁止紫色渐变+白底+Inter字体的默认组合
- 反模式: 直接用AI默认输出, 千篇一律

## GR-002: 移动优先设计
- 来源: vercel-react-best-practices 响应式规范
- 规则: 先设计手机端, 再扩展到平板和桌面
- 反模式: 先做桌面端然后"适配"手机, 结果手机上布局崩坏

## GR-003: 组件化思维
- 来源: vercel-composition-patterns 架构指南
- 规则: 每个UI元素封装为可复用组件, props控制变体
- 反模式: 每个页面从零写HTML, 相同元素重复代码

## GR-004: 性能预算
- 来源: vercel-deploy-to-vercel 部署经验
- 规则: 首屏加载<3s, JS bundle<200KB, 图片全部压缩+懒加载
- 反模式: 不压缩图片/不用懒加载, Lighthouse分数<50

## GR-005: 先原型再实现
- 来源: web-design-engineer 工作流
- 规则: 复杂页面先用HTML+CSS做静态原型确认布局, 再加交互逻辑
- 反模式: 直接写React组件+状态管理, 发现布局不对要重写

## GR-006: 真实参考优于凭空设计
- 来源: lazyweb-skill 设计方法论
- 规则: 设计前搜索同类型优秀网站作为参考, 不凭AI训练数据的"平均审美"
- 反模式: 闭门造车, 做出来和用户期望差距很大
