# 案例库与联动技能

**Case 1：半导体封装行业调研**（2026-06，li-research 调用链）
- 需求：了解 AMB 基板市场格局
- 流程：li-research Phase 1 多源搜索 → li-analyze 行业链分析 → li-memory 沉淀
- 关键发现：AMB vs DBC 技术路线差异，供应商集中度

**Case 2：AI 芯片行业竞品分析**
- 需求：对比寒武纪 vs 海光 vs 寒武纪的产品线
- 流程：li-research 学术搜索 → li-bestskill 寻找行业数据库 → li-devil 泼冷水
- 关键发现：算力指标不可直接对比，需考虑架构差异

**Case 3：人形机器人行业报告**
- 需求：为威泊机器人实习做技术储备
- 流程：li-research → 行业链梳理 → li-analyze 技术路线分析
- 关键发现：具身智能 vs 传统自动化的技术代差

## 联动技能（5 个）

| Skill | 触发条件 | 联动方式 |
|-------|---------|---------|
| li-research | 行业调研启动 | Phase 1 → li-research 多源搜索 |
| li-analyze | 需要深度分析 | 数据收集后 → li-analyze 道法术器拆解 |
| li-devil | 行业判断需泼冷水 | 结论前 → li-devil 预验尸 |
| li-memory | 沉淀行业知识 | 完成后 → li-memory 事实存储 |
| li-competition | 竞赛相关行业 | 竞赛场景 → li-competition SOP |
