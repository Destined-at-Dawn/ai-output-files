# Strategic Research Frameworks

This document provides strategic analysis frameworks for industry research.

## Porter's Five Forces

Use this framework to analyze competitive intensity and attractiveness of an industry.

### The Five Forces:

1. **Threat of New Entrants**
   - Capital requirements
   - Economies of scale
   - Brand loyalty
   - Access to distribution channels
   - Government regulations
   - Technology barriers

2. **Bargaining Power of Suppliers**
   - Number of suppliers
   - Uniqueness of their product/service
   - Switching costs
   - Forward integration potential

3. **Bargaining Power of Buyers**
   - Number of buyers
   - Volume of purchases
   - Switching costs
   - Backward integration potential
   - Price sensitivity

4. **Threat of Substitute Products**
   - Availability of substitutes
   - Relative price-performance
   - Switching costs
   - Buyer propensity to substitute

5. **Rivalry Among Existing Competitors**
   - Number of competitors
   - Industry growth rate
   - Product differentiation
   - Exit barriers
   - Strategic stakes

**Output**: Rate each force as High/Medium/Low and provide reasoning.

---

## PESTEL Analysis

Use this framework to analyze macro-environmental factors affecting the industry.

### The Six Factors:

1. **Political**
   - Government stability
   - Tax policies
   - Trade regulations
   - Labor laws
   - Political trends

2. **Economic**
   - Economic growth rate
   - Interest rates
   - Exchange rates
   - Inflation rate
   - Disposable income levels

3. **Social**
   - Demographics
   - Cultural attitudes
   - Lifestyle changes
   - Education levels
   - Health consciousness

4. **Technological**
   - R&D activity
   - Automation
   - Technology incentives
   - Rate of technological change
   - Digital transformation

5. **Environmental**
   - Climate change impacts
   - Environmental regulations
   - Sustainability trends
   - Carbon footprint concerns
   - Waste management

6. **Legal**
   - Consumer protection laws
   - Employment laws
   - Health and safety regulations
   - Data protection
   - Intellectual property laws

**Output**: Identify 3-5 key factors in each category that significantly impact the industry.

---

## Value Chain Analysis

Use this framework to understand how value is created in the industry.

### Primary Activities:
1. **Inbound Logistics**: Receiving, storing, distributing inputs
2. **Operations**: Transforming inputs into final products
3. **Outbound Logistics**: Collecting, storing, distributing products
4. **Marketing & Sales**: Inducing buyers to purchase
5. **Service**: Maintaining and enhancing product value

### Support Activities:
1. **Firm Infrastructure**: Management, planning, finance, legal
2. **Human Resource Management**: Recruiting, training, development
3. **Technology Development**: R&D, process automation
4. **Procurement**: Purchasing inputs

**Output**: Map the value chain for key players and identify where value is created/captured.

---

## Business Model Canvas

Use this framework to understand and compare business models in the industry.

### Nine Building Blocks:

1. **Customer Segments**: Who are the customers?
2. **Value Propositions**: What value do we deliver?
3. **Channels**: How do we reach customers?
4. **Customer Relationships**: What type of relationship?
5. **Revenue Streams**: How do we make money?
6. **Key Resources**: What assets are required?
7. **Key Activities**: What do we do?
8. **Key Partnerships**: Who are our partners?
9. **Cost Structure**: What are the costs?

**Output**: Create a business model canvas for 3-5 major players to compare strategies.

---

## Market Segmentation Framework

Use this framework to identify and analyze market segments.

### Segmentation Dimensions:

1. **Demographic**: Age, gender, income, education, occupation
2. **Geographic**: Country, region, city size, climate
3. **Psychographic**: Lifestyle, values, personality, interests
4. **Behavioral**: Usage rate, loyalty status, benefits sought, readiness stage

### Evaluation Criteria:
- **Measurable**: Can you measure the segment size?
- **Accessible**: Can you reach the segment?
- **Substantial**: Is the segment large enough?
- **Differentiable**: Does the segment respond differently?
- **Actionable**: Can you serve the segment effectively?

**Output**: Identify 3-5 key segments and evaluate their attractiveness.

---

## Opportunity Evaluation Matrix

Use this framework to prioritize opportunities.

### Evaluation Dimensions:

| Dimension | Weight | Score (1-10) | Weighted Score |
|-----------|--------|--------------|----------------|
| Market Size | 20% | | |
| Growth Rate | 15% | | |
| Competition Level (inverse) | 15% | | |
| Entry Barriers (inverse) | 10% | | |
| Profit Margins | 15% | | |
| Strategic Fit | 10% | | |
| Resource Requirements (inverse) | 10% | | |
| Risk Level (inverse) | 5% | | |
| **Total** | **100%** | | |

**Output**: Score each opportunity and rank by weighted total score.

---

## Competitive Positioning Map

Use this framework to visualize competitive positioning.

### Steps:

1. **Select Two Key Dimensions**: Choose the two most important competitive dimensions
   - Examples: Price vs Quality, Features vs Ease of Use, Innovation vs Reliability

2. **Plot Competitors**: Place each major player on the map

3. **Identify Gaps**: Look for empty spaces that represent opportunities

4. **Analyze Clusters**: Identify groups of competitors with similar positioning

**Output**: A 2x2 matrix showing competitive positioning and opportunity gaps.

---

## Trend Impact Assessment

Use this framework to evaluate the impact of trends.

### Assessment Matrix:

| Trend | Current Stage | Timeline | Impact Level | Certainty | Recommended Action |
|-------|---------------|----------|--------------|-----------|-------------------|
| [Trend name] | Emerging/Growing/Mature | 1-2y/3-5y/5+y | High/Med/Low | High/Med/Low | Monitor/Prepare/Act |

### Impact Categories:
- **Disruptive**: Fundamentally changes the industry
- **Transformative**: Significantly alters competitive dynamics
- **Incremental**: Gradual evolution of existing patterns
- **Cyclical**: Temporary fluctuation

**Output**: Prioritized list of trends with recommended actions.