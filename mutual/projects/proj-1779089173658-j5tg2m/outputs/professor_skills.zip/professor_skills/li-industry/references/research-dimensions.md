# Research Dimensions - Detailed Breakdown

This document provides detailed guidance on what to research in each of the six dimensions.

## Dimension 1: Market Overview

### Core Questions

#### Market Size & Growth
- What is the total addressable market (TAM)?
  - Global market size
  - Regional/country-specific market size
  - Market size by segment
- What is the serviceable addressable market (SAM)?
- What is the serviceable obtainable market (SOM)?
- Historical growth rate (past 3-5 years)
- Projected growth rate (next 3-5 years)
- CAGR (Compound Annual Growth Rate)

#### Market Structure
- How is the market segmented?
  - By customer type (B2B, B2C, B2B2C)
  - By price point (premium, mid-market, budget)
  - By geography
  - By use case
- What is the size of each segment?
- Which segments are growing fastest?

#### Market Maturity
- What stage is the market in?
  - Emerging (< 5 years old)
  - Growth (rapid expansion)
  - Mature (stable, incremental growth)
  - Declining (shrinking market)
- What are the indicators of this stage?

### Data Sources
- Market research reports (Gartner, Forrester, IDC, etc.)
- Industry associations
- Government statistics
- Company financial reports
- News articles and press releases

---

## Dimension 2: Competitive Landscape

### Core Questions

#### Market Players
- Who are the top 10-20 players?
- What is their market share?
- Who are the emerging players to watch?
- Are there any dominant players (>30% market share)?

#### Competitive Positioning
- How do competitors position themselves?
  - Premium vs budget
  - Full-service vs specialized
  - Technology-driven vs service-driven
  - B2B vs B2C focus
- What are their unique value propositions?
- What are their target customer segments?

#### Competitive Dynamics
- How intense is the competition?
- What are the key competitive factors?
  - Price
  - Quality
  - Brand
  - Innovation
  - Customer service
  - Distribution
- Are there any strategic alliances or partnerships?
- Recent M&A activities?

#### Barriers to Entry
- What are the barriers for new entrants?
  - Capital requirements
  - Regulatory approvals
  - Brand recognition
  - Network effects
  - Technology/IP
  - Distribution access
- How high are these barriers?

### Analysis Frameworks
- Porter's Five Forces (see research-frameworks.md)
- Competitive positioning map
- Market share analysis

---

## Dimension 3: User Needs & Pain Points

### Core Questions

#### Customer Segmentation
- Who are the primary customer segments?
- What are their demographics?
- What are their psychographics?
- What is their buying behavior?

#### Needs & Jobs-to-be-Done
- What are customers trying to accomplish?
- What are their functional needs?
- What are their emotional needs?
- What are their social needs?
- What outcomes do they seek?

#### Pain Points & Frustrations
- What problems do customers face?
- What are the biggest frustrations with current solutions?
- What are the unmet needs?
- What workarounds do customers use?
- What do customers complain about most?

#### Decision Criteria
- What factors influence purchase decisions?
- What is the decision-making process?
- Who are the decision-makers and influencers?
- What are the deal-breakers?

#### Customer Journey
- How do customers discover solutions?
- How do they evaluate options?
- What is the purchase process?
- What is the onboarding experience?
- What drives retention or churn?

### Research Methods
- Social media listening (Reddit, Twitter, forums)
- Review analysis (G2, Capterra, App Store, etc.)
- Customer interviews (if accessible)
- Survey data
- Support ticket analysis
- Community discussions

---

## Dimension 4: Business Models & Economics

### Core Questions

#### Business Model Types
- What are the common business models?
  - Subscription (SaaS, membership)
  - Transaction (marketplace, e-commerce)
  - Advertising (media, platforms)
  - Licensing (IP, software)
  - Service (consulting, agency)
  - Hybrid models
- Which models are most successful?

#### Revenue Streams
- What are the primary revenue sources?
- What are the secondary revenue sources?
- Revenue mix percentages
- Revenue per customer/user

#### Pricing Strategies
- What are the typical pricing models?
  - Freemium
  - Tiered pricing
  - Usage-based
  - Flat rate
  - Custom/enterprise
- What is the price range?
- How do prices compare across competitors?

#### Unit Economics
- Customer Acquisition Cost (CAC)
- Lifetime Value (LTV)
- LTV:CAC ratio
- Gross margins
- Operating margins
- Payback period
- Churn rate

#### Cost Structure
- What are the major cost drivers?
  - COGS (Cost of Goods Sold)
  - Sales & marketing
  - R&D
  - Operations
  - Customer support
- Fixed vs variable costs
- Economies of scale

### Data Sources
- Company financial statements (for public companies)
- Investor presentations
- Industry benchmarks
- Case studies
- Expert interviews

---

## Dimension 5: Trends & Drivers

### Core Questions

#### Technology Trends
- What new technologies are emerging?
- How is AI/ML impacting the industry?
- What is the pace of technological change?
- What technologies are becoming obsolete?

#### Consumer Behavior Trends
- How are customer preferences changing?
- What new behaviors are emerging?
- What generational shifts are occurring?
- How is digital adoption evolving?

#### Market Trends
- What are the growth drivers?
- What are the headwinds?
- What new market segments are emerging?
- What segments are declining?

#### Competitive Trends
- What new business models are emerging?
- How is the competitive landscape shifting?
- What consolidation is happening?
- What new entrants are disrupting?

#### Regulatory Trends
- What new regulations are coming?
- How is policy evolving?
- What compliance requirements are changing?

#### Macro Trends (PESTEL)
- Political factors
- Economic factors
- Social factors
- Technological factors
- Environmental factors
- Legal factors

### Trend Analysis
- Identify 5-10 key trends
- Assess impact (High/Medium/Low)
- Assess certainty (High/Medium/Low)
- Estimate timeline (1-2y, 3-5y, 5+y)
- Identify opportunities and threats

---

## Dimension 6: Regulatory & Risk Factors

### Core Questions

#### Regulatory Environment
- What are the key regulations?
- What licenses/permits are required?
- What compliance requirements exist?
- How strict is enforcement?
- What are the penalties for non-compliance?

#### Policy Changes
- What policy changes are proposed?
- What is the likelihood of passage?
- What would be the impact?
- When would they take effect?

#### Risk Categories

**Market Risks**:
- Market size smaller than expected
- Growth rate slower than projected
- Customer adoption challenges
- Competitive intensity increases

**Operational Risks**:
- Supply chain disruptions
- Talent shortage
- Technology failures
- Quality issues

**Financial Risks**:
- Funding challenges
- Unit economics don't work
- Cash flow problems
- Currency fluctuations

**Regulatory Risks**:
- New regulations
- Compliance failures
- Legal challenges
- Policy changes

**Reputational Risks**:
- Brand damage
- Customer trust issues
- PR crises
- Social media backlash

### Risk Assessment
- Identify 5-10 key risks
- Assess likelihood (High/Medium/Low)
- Assess impact (High/Medium/Low)
- Prioritize by likelihood × impact
- Identify mitigation strategies

---

## Research Depth Guidelines

### Quick Scan (2-3 hours)
- Focus on Dimensions 1, 2, 5
- Use secondary sources only
- High-level overview
- Key insights and opportunities

### Standard Research (1-2 days)
- Cover all six dimensions
- Mix of secondary and primary sources
- Moderate depth
- Actionable insights and recommendations

### Deep Dive (3-5 days)
- Comprehensive coverage of all dimensions
- Extensive primary and secondary research
- Deep analysis with multiple frameworks
- Detailed recommendations with implementation roadmap