---
name: li-industry
description: Comprehensive industry research skill for analyzing any industry systematically. Use when the user wants to research an industry (not specific platform content), understand market opportunities, competitive landscape, user needs, business models, trends, or find market gaps. Triggers include requests like "research the study abroad industry", "analyze the AI education market", "find opportunities in X industry", or "understand the competitive landscape of Y sector".
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/research-frameworks.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[研究维度] -> **必须** `Read references/research-dimensions.md`
- 场景[报告模板] -> **必须** `Read references/report-template.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/research-frameworks.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）

## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |

# Industry Research

## Overview

This skill guides systematic research of any industry to identify market opportunities, understand competitive dynamics, and uncover actionable insights. It combines multiple AI tools (Perplexity, Claude, Gemini, GPT, Manus) to conduct comprehensive analysis across six key dimensions.

## Research Workflow

### Step 1: Define Research Scope

Before starting research, clarify with the user:

1. **Target Industry**: Which specific industry or sector?
   - Example: "Study abroad consulting", "AI education", "Fitness tech"

2. **Research Purpose**: What's the goal?
   - Find content opportunities
   - Identify business opportunities
   - Understand competitive landscape
   - Validate a business idea
   - Enter a new market

3. **Geographic Scope**: Which market(s)?
   - China only, US only, global, specific regions

4. **Depth Level**: How deep should the research go?
   - Quick scan (2-3 hours)
   - Standard research (1-2 days)
   - Deep dive (3-5 days)

**Output**: Create a research brief document that captures these parameters.

### Step 2: Conduct Multi-Dimensional Research

Research the industry across six dimensions. Use the appropriate AI tool for each task:

- **Perplexity**: Real-time data, market statistics, recent news
- **Claude**: Deep analysis, synthesis, framework application
- **Gemini/GPT**: Alternative perspectives, cross-validation
- **Manus**: Platform-specific content research (when needed)

#### Dimension 1: Market Overview

**Research Questions**:
- What is the total addressable market (TAM)?
- What is the market growth rate (past 3-5 years, projected 3-5 years)?
- What are the key market segments?
- What is the market maturity stage (emerging, growth, mature, declining)?

**Tools**: Perplexity for market data, Claude for analysis

**Output**: Market size data, growth trends, segmentation map

#### Dimension 2: Competitive Landscape

**Research Questions**:
- Who are the major players (top 10-20)?
- What is the market share distribution?
- What are the competitive positioning strategies?
- What are the barriers to entry?
- Are there any recent M&A activities?

**Tools**: Perplexity for company data, Claude for competitive analysis using Porter's Five Forces (see [references/research-frameworks.md](references/research-frameworks.md))

**Output**: Competitor matrix, market share chart, positioning map

#### Dimension 3: User Needs & Pain Points

**Research Questions**:
- Who are the target users/customers?
- What are their primary needs and pain points?
- What are the current solutions and their limitations?
- What are the unmet needs?
- What do users complain about most?

**Tools**: Manus for social media listening, Perplexity for user research reports, Claude for synthesis

**Output**: User persona, pain point hierarchy, needs-solutions gap analysis

#### Dimension 4: Business Models & Economics

**Research Questions**:
- What are the common business models in this industry?
- What are the typical revenue streams?
- What are the unit economics (CAC, LTV, margins)?
- What are the key cost drivers?
- What are the monetization strategies?

**Tools**: Perplexity for financial data, Claude for business model analysis

**Output**: Business model canvas, unit economics breakdown, monetization strategy comparison

#### Dimension 5: Trends & Drivers

**Research Questions**:
- What are the key industry trends (technology, consumer behavior, regulation)?
- What are the growth drivers?
- What are the potential disruptors?
- What are the emerging opportunities?
- What external factors impact this industry (PESTEL)?

**Tools**: Perplexity for trend data, Claude for PESTEL analysis (see [references/research-frameworks.md](references/research-frameworks.md))

**Output**: Trend analysis, driver identification, opportunity radar

#### Dimension 6: Regulatory & Risk Factors

**Research Questions**:
- What are the key regulations and policies?
- What are the compliance requirements?
- What are the major risks (market, operational, regulatory)?
- Are there any recent policy changes?

**Tools**: Perplexity for regulatory information, Claude for risk analysis

**Output**: Regulatory landscape summary, risk matrix

### Step 3: Synthesize Findings

After completing research across all six dimensions, synthesize the findings:

1. **Identify Patterns**: Look for recurring themes, contradictions, and insights
2. **Apply Frameworks**: Use strategic frameworks to structure insights (see [references/research-frameworks.md](references/research-frameworks.md))
3. **Validate Insights**: Cross-check findings across multiple sources
4. **Prioritize Opportunities**: Rank opportunities by attractiveness and feasibility

**Tools**: Claude for synthesis and strategic analysis

### Step 4: Generate Deliverables

Create the following deliverables based on research findings:

#### 4.1 Structured Industry Research Report

Use the template in [references/report-template.md](references/report-template.md) to create a comprehensive report covering:
- Executive Summary
- Market Overview
- Competitive Landscape
- User Analysis
- Business Model Analysis
- Trends & Opportunities
- Risks & Challenges
- Recommendations

#### 4.2 Opportunity List

Create a prioritized list of opportunities with:
- Opportunity description
- Market size potential
- Competition level
- Entry barriers
- Required resources
- Risk level
- Priority score (High/Medium/Low)

Format as a table for easy scanning.

#### 4.3 Competitor Analysis Table

Create a detailed competitor comparison table with:
- Company name
- Market position
- Key offerings
- Pricing strategy
- Strengths
- Weaknesses
- Differentiation strategy

#### 4.4 Trend Predictions

Identify 3-5 key trends and predict their impact:
- Trend description
- Current stage
- Projected timeline
- Potential impact
- Recommended actions

### Step 5: Save and Organize

Save all deliverables to the appropriate location:

```
active/YYYYMMDD-[Industry Name]-行业调研/
├── 01-研究简报.md (Research brief from Step 1)
├── 02-调研报告.md (Main research report)
├── 03-机会清单.md (Opportunity list)
├── 04-竞品分析.md (Competitor analysis)
├── 05-趋势预测.md (Trend predictions)
└── 06-原始资料/ (Raw research materials)
```

## Research Tips

### Multi-Tool Strategy

- **Start with Perplexity**: Get the latest data and statistics
- **Use Claude for deep analysis**: Apply frameworks, synthesize insights
- **Cross-validate with Gemini/GPT**: Get alternative perspectives
- **Use Manus for content research**: When you need platform-specific insights

### Quality Checks

Before finalizing the research:
- [ ] All six dimensions covered
- [ ] Data sources cited
- [ ] Insights validated across multiple sources
- [ ] Opportunities prioritized and actionable
- [ ] Report structure clear and logical
- [ ] Deliverables saved to proper location

### Common Pitfalls to Avoid

1. **Surface-level research**: Don't just collect data, analyze and synthesize
2. **Confirmation bias**: Actively seek contradictory information
3. **Outdated data**: Verify data recency, especially for fast-moving industries
4. **Missing the "so what"**: Always connect findings to actionable insights
5. **Ignoring the user's context**: Tailor research to the user's specific goals

## References

This skill includes detailed reference materials:

- **[research-frameworks.md](references/research-frameworks.md)**: Strategic analysis frameworks (Porter's Five Forces, PESTEL, Value Chain, Business Model Canvas, etc.)
- **[research-dimensions.md](references/research-dimensions.md)**: Detailed breakdown of what to research in each dimension with example questions
- **[report-template.md](references/report-template.md)**: Structured template for the final industry research report

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |

> See references/ for details.

## 案例库 → 详见 `references/cases-and-linked.md`

## 禁忌

- **禁止**：引用行业数据不标注来源和时间——过期数据会误导决策
- **禁止**：只看一家的行业报告——至少 3 个来源交叉验证
- **禁止**：把预测当事实——"预计 2030 年市场规模"是推测不是事实
## 条件下一步

- 行业报告完成 → 调用 li-analyze 做道法术器拆解 → li-memory 存关键洞察
## 联动技能

- **li-research**：深度信息搜集和多平台搜索——行业研究的核心依赖
- **li-devil**：决策质疑——行业进入/退出决策的关键审查
- **li-analyze**：道法术器深度分析——行业案例的深层解构
- **li-diagnose**：系统熵增诊断——行业生态的系统性分析
- **li-memory**：行业洞察持久化——跨次研究的知识积累
- **li-bestskill**：搜索外部行业研究 skill——发现更优研究工具
