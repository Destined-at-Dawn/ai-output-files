# li-workflow 案例库

## 案例 1: Git Hooks 自动化
- 场景：每次 commit 自动检查格式
- 实现：pre-commit hook + lint-staged
- 结果：格式问题从 30% 降到 0%

## 案例 2: 定时任务编排
- 场景：每天 9:30 自动生成报告
- 实现：cron + Python 脚本 + 邮件通知
- 结果：从手动 30 分钟到自动 2 分钟
