# 工作流模式

## 模式1：管道（Pipeline）
A → B → C，串行执行
适用：数据处理、内容创作

## 模式2：扇出（Fan-out）
A → [B, C, D] 并行
适用：多源搜索、批量处理

## 模式3：条件分支（Router）
A → if X then B else C
适用：分流、路由

## 模式4：循环（Loop）
A → B → if not done → A
适用：迭代优化、质量检查

## 工具
- GitHub Actions：CI/CD
- Claude Code hooks：自动化触发
- Cron/定时任务：周期性工作
