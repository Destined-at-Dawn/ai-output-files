---
name: li-workflow
description: 自动化工作流编排，支持 CI/CD 配置、脚本生成、定时任务和 Git Hooks 设置。
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/workflow-patterns.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[案例] -> **必须** `Read references/case-studies.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/workflow-patterns.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）



## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |


# 自动化工作流

帮助用户设计和实现项目中的自动化工作流，减少重复性手动操作。

## 能力范围

1. **CI/CD 流水线** — GitHub Actions、GitLab CI 等配置文件生成和优化
2. **构建脚本** — Makefile、npm scripts、shell 脚本编写
3. **Git Hooks** — pre-commit、commit-msg 等钩子配置（husky、lint-staged）
4. **定时任务** — cron 表达式、scheduled tasks 配置
5. **代码质量自动化** — ESLint、Prettier、TypeScript 检查的自动化集成
6. **发布流程** — 版本管理、changelog 生成、自动发布脚本

## 工作流程

### 1. 了解项目现状

- 询问项目技术栈、代码托管平台、现有的自动化配置
- 读取 `package.json`、`.github/workflows/`、`Makefile` 等文件了解现状

### 2. 识别自动化机会

根据项目情况推荐可自动化的环节：
- 代码提交时自动检查（lint、format、type-check）
- PR 合并时自动测试和构建
- 版本发布时自动打包和部署
- 重复性操作的脚本封装

### 3. 实现自动化配置

- 生成配置文件，确保语法正确
- 提供必要的环境变量和密钥配置说明
- 编写清晰的注释说明每个步骤的作用

### 4. 验证和测试

- 检查配置文件语法
- 提供本地测试命令（如 `act` 测试 GitHub Actions）
- 列出验证清单确保配置正确

## 注意事项

- 优先使用项目已有的工具和配置，避免引入不必要的依赖
- 配置文件中的敏感信息（密钥、token）必须使用环境变量或 secrets
- 为每个自动化步骤添加清晰的注释
- 考虑失败情况的处理和通知机制


## Case Studies

### Case 1: 公众号发布自动化
- **场景**：每周 3 篇帖子，手动排版+发布耗时 2 小时/篇
- **方法**：识别 3 个自动化点（Markdown→公众号格式、封面生成、定时发布）
- **结果**：每篇从 2 小时降到 20 分钟
- **教训**：先识别最耗时的步骤，不追求全流程自动化

### Case 2: 竞赛项目 CI/CD
- **场景**：FPGA 项目每次修改都要手动综合+仿真
- **方法**：TCL 脚本自动化（综合→实现→比特流→仿真）
- **结果**：每次迭代从 30 分钟降到 5 分钟
- **教训**：硬件项目的自动化比软件更难但收益更大

### Case 3: 记忆文件自动归档
- **场景**：memory/ 目录文件越来越多，手动管理困难
- **方法**：识别模式（>30 天未更新 → 归档）→ 定时脚本
- **结果**：memory/ 目录保持干净
- **教训**：自动化的目标是"不用想"，不是"更方便"


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 全流程自动化 | 维护成本 > 手动成本 | 只自动化最耗时的 3 个步骤 |
| 2 | 不做 dry-run | 自动化脚本出错不可逆 | 先 dry-run 展示结果，确认后执行 |
| 3 | 硬编码路径 | 环境切换就失败 | 使用环境变量和配置文件 |
| 4 | 自动化后不监控 | 静默失败无人知 | 添加日志和告警 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-plan** | 工作流中的任务排期 | "这个步骤排到什么时候" |
| **li-debug** | 自动化脚本调试 | "脚本报错了" |
| **li-infra** | 工作流涉及基础设施变更 | "修改启动流程" |



| li- | 联动方式 | 触发时机 |
|-----|---------|---------|
| li-infra | 基础设施管理 | 需更新 CLAUDE.md 或 SOP |
| li-manage | 生命周期管理 | 工作流变更需同步 skill |
| li-sync | 跨区同步 | 工作流涉及多工作区 |
| li-debug | 调试工作流脚本 | 自动化脚本出错 |
## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |


## 联动技能

- **li-infra, li-manage, li-sync, li-improve, li-workspace**
- 联动方式：上游skill决定何时调用本skill，本skill专注核心能力
- 联动触发条件：上游skill的Phase中明确写了调用本skill的步骤
- 联动验证：联动成功后由li-memory记录事实，li-improve记录教训



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## 案例库

### 案例 1：Git Hooks 自动提交
**场景**：每次修改文件后需要手动 git commit
**方法**：配置 post-save hook → 自动 git add + commit
**结果**：零手动提交，历史自动记录
**教训**：重复操作必须自动化

### 案例 2：定时路由表同步
**场景**：路由表更新后需要手动同步到 40+ 工作区
**方法**：创建 auto task → 每天 10:00 自动同步
**结果**：路由表永远是最新的
**教训**：超过 3 次手动操作 = 应该自动化

### 案例 3：NiumaAutoCommit 定时任务
**场景**：长时间对话中的修改可能丢失
**方法**：每 2 小时自动 git commit（NiumaAutoCommit）
**结果**：最大数据丢失窗口从"无限"缩短到 2 小时
**教训**：自动化是数据安全的最后一道防线