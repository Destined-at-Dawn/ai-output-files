---
name: li-plan
description: |
  li-series task and project planning. Two modes:
  Mode A: Daily task management - natural language task recording, smart scheduling, Feishu calendar.
  Mode B: Long-term project planning - goal definition, milestone decomposition, task creation.
  Triggers: planning, task management, scheduling, project setup, milestones
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/planning-methods.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[案例] -> **必须** `Read references/case-studies.md`
- 场景[反模式] -> **必须** `Read references/anti-patterns.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/planning-methods.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-plan - Task & Project Planning

Two complementary modes for different planning needs.

## Mode Selection

| Signal | Mode |
|--------|------|
| "what to do today" "record task" "schedule" "postpone" "review" | **Mode A: Daily Task Management** |
| "long-term plan" "project planning" "milestones" "task decomposition" | **Mode B: Long-Term Project Planning** |
| "planning" (ambiguous) | Ask user which mode |

---

# Mode A: Daily Task Management

AI task butler. Natural language task recording, smart scheduling, Feishu calendar integration, reminders.

## Trigger Scenarios

**Recording**: "record a task" "tomorrow do X" "don't forget X" "remember X" "finish X by next week"
**Planning**: "what to do today" "schedule it" "plan today" "today's plan" "this week's plan"
**Adjusting**: "postpone to X" "change to X" "cancel X" "not doing this" "prioritize X"
**Reviewing**: "what did I finish this week" "review" "how's progress"
**Viewing**: "my tasks" "to-do list" "what's left undone"

## Flow 1: Record Task

1. **Parse task info** (AI auto-infer, don't ask user):
   - Task name: extract from user's words
   - Deadline: infer from time words, default 1 week
   - Priority: infer from tone (urgent -> P1, not urgent -> P3, default P2)
   - Duration: infer from complexity (simple 30min, writing 2h, big project 4h)
   - Energy type: high (writing/planning/architecture) / low (reply/organize/simple ops)
2. **Create Feishu task**: call lark-task skill
3. **Smart scheduling**: execute Flow 3
4. **Confirm**: one sentence summary

## Flow 2: Today/Week Plan

1. Get calendar: lark-calendar +agenda
2. Get tasks: lark-task +get-my-tasks
3. Smart sort by scoring model
4. Output plan with priority tiers (Must/Should/Nice to Have/Fixed Schedule)

## Flow 3: Smart Scheduling Algorithm

Scoring model (0-100):

| Dimension | Weight | Calculation |
|-----------|--------|-------------|
| Urgency | 40% | Days to deadline: <=1d=100, 2-3d=80, 4-7d=50, >7d=20 |
| Priority | 25% | P0=100, P1=80, P2=50, P3=20 |
| Energy match | 20% | High+morning=100, High+afternoon=40, Low+any=70 |
| Duration fit | 15% | Slot>=task=100, Slot<task=0 |

Time block rules:
- Work hours: 09:00-12:00, 14:00-18:00 (customizable)
- Lunch: 12:00-14:00 (no tasks)
- Morning: high-energy tasks first
- 15min buffer between blocks
- Don't overlap existing calendar events

## Flow 4: Task Adjustment

"postpone" "change time" "cancel" -> identify task -> update Feishu -> sync calendar -> auto-reschedule

## Flow 5: Weekly Review

Get completed tasks + calendar events -> stats -> output review report with time allocation breakdown.

## Habit Learning

Track: peak energy periods, task duration deviation, common task types, procrastination patterns.
Store in memory file for dynamic scheduling adjustment.

## Safety

- Read-only: no confirmation for viewing
- Write confirmation: show plan before creating calendar events
- Quick record exception: direct task creation when user says "record a task"

## Dependencies

- **lark-task**: create/update/query Feishu tasks
- **lark-calendar**: query/create calendar events

---

# Mode B: Long-Term Project Planning

Structured multi-turn dialogue for long-term project plans with milestones and task decomposition.


## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |

## Phase 0: Environment Check (execute first)

Already in project context (has create_tasks / update_plan_document) -> skip to Phase 1.
Not in project: if convert_to_project tool available, call it first.

## Phase 1: Define Goals

Guide user: What is the goal? Time range? Current level? Known constraints?
Output: clear project title + core goal description.

## Phase 2: Break Down Milestones

Suggest 3-5 key milestones with measurable output, reasonable intervals, dependency awareness.
Use update_plan_document to create plan document.

## Phase 3: Decompose Tasks

Use create_tasks to batch-create tasks:
- Clear, actionable titles
- Set scheduled_date, auto/manual, estimated_minutes
- Use depends_on_titles for dependencies
- Set priority (0=normal, 1=important, 2=urgent)

## Phase 4: Confirm & Launch

Show overview: task count, auto/manual ratio, time distribution, critical path.
After confirmation, auto tasks begin per schedule.

## Task Classification

**Auto-suitable**: research, doc drafting, data collection, template building, report generation
**Manual-suitable**: user decisions, external platform ops, subjective review, third-party coordination


## Case Studies

### Case 1: FPGA 竞赛项目排期
- **场景**：3 周完成 LCD 驱动开发，包含 RTL/仿真/上板/文档
- **方法**：Mode B 长期规划 → 里程碑分解 → 每日任务 → 一把过 SOP
- **结果**：按时交付，中间无返工
- **教训**：硬件项目必须留 30% buffer 给调试

### Case 2: 考研+实习+竞赛三线并行
- **场景**：大一下同时推进 3 个目标
- **方法**：Mode A 日常排期 → 时间块分配 → 优先级矩阵
- **结果**：GPA 3.9 + 实习 offer + 竞赛省奖
- **教训**：三线并行时每条线只做"最小可行进度"，不追求完美

### Case 3: 小红书内容日历
- **场景**：每周 3 篇帖子，需要提前规划选题
- **方法**：Flow 2 周计划 → 选题库 → 排期 → 批量创作
- **结果**：内容产出稳定，不再"今天写什么"焦虑
- **教训**：内容创作需要生产线思维，不是灵感驱动


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 计划太细（精确到小时） | 一环脱节全盘崩 | 里程碑级规划 + 每日微调 |
| 2 | 不留 buffer | 意外发生时无余量 | 硬件项目 30% buffer，软件 20% |
| 3 | 多线并行追求完美 | 每条线都做不完 | 每条线只做最小可行进度 |
| 4 | 计划做完不回顾 | 同样的错误重复犯 | Flow 5 每周回顾 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-manage** | 任务完成后的知识沉淀 | "这个任务的经验记下来" |
| **li-workflow** | 计划中的自动化步骤 | "这个步骤可以自动化" |
| **li-mindcoach** | 计划焦虑的心理支持 | "来不及了""压力好大" |
| **li-sync** | 跨工作区计划同步 | "求职区的计划同步到个人" |



## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |


## 联动技能

- **li-research, li-devil, li-manage, li-improve, li-sync, li-workflow**
- 联动方式：上游skill决定何时调用本skill，本skill专注核心能力
- 联动触发条件：上游skill的Phase中明确写了调用本skill的步骤
- 联动验证：联动成功后由li-memory记录事实，li-improve记录教训


## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## Linked Skills

| Skill | Trigger | Role |
|-------|---------|------|
| li-research | 需要调研背景 | 提供决策依据 |
| li-devil | 重大决策 | 泼冷水验证 |
| li-manage | 跨区项目 | 生命周期管理 |
| li-triage | 多任务并行 | 优先级分流 |
| li-improve | 计划执行后 | 复盘改进 |

## 案例库

### 案例 1：FPGA 项目任务规划
**场景**：XC7A35T LCD 驱动项目，3 周 deadline
**方法**：逆向拆解——交付日 → RTL 验证（-3 天）→ 综合（-7 天）→ 编码（-14 天）→ 架构设计（-21 天）
**结果**：按时交付，一把过
**关键**：逆向拆解比正向计划更可靠

### 案例 2：考研 + 实习 + 内容创作三线并行
**场景**：同时推进 3 个主线任务，精力不足
**方法**：时间块规划——上午考研（高认知）、下午实习/项目（中认知）、晚上创作（低认知）
**结果**：三线都有进展，没有崩溃
**关键**：按认知负荷分配时间段

### 案例 3：小红书 30 天内容日历
**场景**：需要规划一个月的小红书发布计划
**方法**：主题矩阵——3 个主题 × 4 种形式 × 2 周 = 24 篇 + 6 篇机动
**结果**：日均发布 1 篇，不断更
**关键**：批量规划 > 逐篇构思