# Case Studies (from li-sync/SKILL.md)

- **li-intent** — 同步意图模式库到所有工作区## 案例库（3 个真实场景）

**Case 1：路由表全工作区同步**（2026-06-08 真实事故修复）
- 问题：158 个 skill 没有注册路由，AI 不知道它们存在
- 流程：os.walk() 全递归扫描 → 66 个含 CLAUDE.md 目录 → 分类（39 用户 + 4 只读 + 21 归档）→ 逐个同步
- 结果：39 个工作区路由表 + CLAUDE.md 加载指令全部就位
- 教训：第三方仓库（GitHub clone）= 只读，改了 4 个已回滚

**Case 2：记忆文件误同步**
- 问题：li-sync 把竞赛区的记忆文件覆盖到了创作区
- 根因：memory/ 目录同步时没有按 containerTag 隔离
- 修复：加了 containerTag 检查——只同步同容器内的记忆

**Case 3：SOP 总索引跨区不一致**
- 问题：5 个工作区的 SOP 总索引格式不同、规则冲突
- 修复：li-sync Phase 4 一致性检查 → 发现格式差异 → 人工确认后统一

