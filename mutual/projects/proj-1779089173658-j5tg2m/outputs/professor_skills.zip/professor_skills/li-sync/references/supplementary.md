
| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 扫描只找顶层目录 | 漏掉深层嵌套工作区 | os.walk() 全递归（最深 11 层） |
| 2 | 同步第三方仓库 | 破坏别人项目 | 第三方 = 只读，跳过 |
| 3 | 只同步路由表不同步 CLAUDE.md | 有文件但不加载 | 两个都要同步 |
| 4 | 不验证同步结果 | 可能静默失败 | 同步后逐个验证 |
| 5 | 把记忆当路由表同步 | memory 是工作区专属 | 只同步路由表和公共规则 |
| 6 | 用硬编码目录列表 | 新工作区被遗漏 | 动态扫描含 CLAUDE.md 的目录 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-infra** | 基础设施管理和初始化 | "新工作区初始化" |
| **li-manage** | 记忆和技能管理 | "同步记忆" |
| **li-skillcreate** | 新 skill 后的同步 | "新建 skill 后同步" |
