# li-sync Theory Table

> Cognitive science foundations for cross-workspace synchronization.

| 理论 | 来源 | 在 li-sync 中的应用 |
|------|------|---------------------|
| 单一真源（Single Source of Truth） | 软件工程架构原则 | `shared-rules/` 是唯一真源，所有工作区的规则从真源同步，避免多份副本不一致 |
| 认知一致性（Cognitive Consistency） | Festinger 认知失调理论 | 用户在不同工作区看到相同规则时产生信任感；不一致会导致困惑和对系统的不信任 |
| 信息级联（Information Cascade） | 信息经济学 | 一条错误规则如果被同步到所有工作区，会造成级联污染——越早发现越好，越晚修越贵 |

