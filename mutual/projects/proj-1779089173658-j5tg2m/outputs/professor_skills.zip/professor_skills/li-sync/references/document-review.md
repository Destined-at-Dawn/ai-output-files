# Phase 5: Document & Memory Hygiene Review

> Detailed steps from li-manage. Triggered at end of session or milestone.

## Phase 5：文档记忆洁癖审查（来源：li-manage）

> 对话结束或里程碑完成后触发。目标：让知识体系始终干净、准确、对新人友好。

### Step 0：尺寸体检

| 文件 | 软限制 | 超了怎么办 |
|------|--------|-----------|
| CLAUDE.md | ~300 行 | 先精简顶部 blockquote/历史叙事段 |
| 记忆索引 | ~150 行 | 删已被取代的/单次复盘 |
| 单条 memory | ~100 行 | 拆分或删（塞多件事） |
| docs/ 单文件 | ~1500 行 | 切分 + 加目录索引 |

**超尺寸 > 本次同步。** 先精简（"什么不该在这"），再补漏（"什么该补"）。

### Step 1：盘点

```
1. ls 工作区根目录 → 确认结构
2. ls docs/ → 枚举所有文档
3. 读 CLAUDE.md + README.md + 每个 docs/*.md
4. 读 memory/ 相关文件
5. 回顾本次对话内容
6. 输出文件清单（标记：评估过/要改/不用改）
```

### Step 2：变更影响矩阵

| 变更类型 | 影响的文档 |
|----------|-----------|
| 新增 API/路由 | CLAUDE.md + integration-guide + architecture |
| 新增环境变量 | CLAUDE.md + runbook + 下游 docs |
| 新增数据库表 | CLAUDE.md + architecture Data Model |
| 跨项目改动 | 上下游两边的 docs |
| 记忆层面 | 绝对时间替换相对时间、过期事实改、重复合并 |

完整映射见 li-manage 的 `references/sync-matrix.md`。

### Step 3：实际修改

**顺序**：docs/ → CLAUDE.md → memory/

**编辑原则**：
- **减优于加**：净涨幅 > 30 行 = 红灯
- **合并优于追加**：先 grep 同关键字看能否并
- **删除优于保留**：完成的计划、推翻的决策、取代的记忆 → 删
- **绝对时间**：永远 `2026-06-07`，不写"今天"
- **面向读者**：docs/ = 第一次接触的外部人
- **受众不混**：CLAUDE.md 不抄 docs/ 全文，docs/ 不写"我记得"

### Step 4：自检

- [ ] CLAUDE.md 净涨幅 ≤ 30 行
- [ ] 没新增 "X 起 Y 上线" 历史叙事
- [ ] 每个文件都判断了"不用改"或"已改"
- [ ] 路径/命令/环境变量在代码中真实存在
- [ ] 没有相对时间遗留（"今天"/"最近" 清零）

### Step 5：变更摘要

```
## 同步完成

### 记忆变更
- 更新：xxx（原因）
- 新增：xxx
- 删除：xxx（原因）

### 文档变更
- <文件> — xxx

### 未处理
- xxx（原因）
```

