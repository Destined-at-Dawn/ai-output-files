# 融合的参考 Skill 清单（60+）

> 本文件是 li-research SKILL.md 的参考附件。
> 本 skill 融合了以下技能的核心模式。不是每个 skill 的全部内容，而是每个 skill 中与"调研"和"迭代"最相关的 1-3 个设计决策。

---

## 调研/搜索类（10 个）

| Skill | 融入的机制 |
|-------|-----------|
| step-search | 轻量搜索 API + 分类搜索策略 |
| research-daily | S/A/B 分级 + "决定而非倾倒"原则 + 创新缺口检测 |
| li-industry | 六维研究框架 + 机会优先级评分 |
| find-skills | 技能发现 + 分类搜索策略 |
| web-access | 分层工具选择决策树 + 一手来源原则 + 子Agent并行 + 站点经验存储 |
| lazyweb-skill | 真实参考优于模板 |
| follow-builders | "Follow builders, not influencers" + 内容Remix机制 |
| X搜索语法生成器 | 语言差异适配 + 互动门槛分级 |
| 全能网页采集器 | 平台专项策略（6种平台）+ 道法术器自动拆解 + 采集策略速查表 |
| baoyu-url-to-markdown | Chrome CDP 抓取 + wait模式 |

---

## DBS系列+认知框架（15 个）

| Skill | 融入的机制 |
|-------|-----------|
| dbs-diagnosis | **问题消解优先于问题解答** + 五层消解漏斗 + 每一步都对话 |
| dbs-good-question | **好问题五项检查**（对象/目标/断点/约束/反馈）+ Agent 可解性判断 + 钉现象再谈解释 |
| dbs-decision | **四层不可变性**（事实→规律→定格→待解）+ 决策立案与结果回填 |
| dbs-learning | **反馈驱动的学习梯度** + 禁用句式（不是否定式）+ 自适应节奏 |
| dbs-action | 信号被动检测（不靠用户自评）+ 诊断者≠执行者 |
| li-content | 先诊断上游问题 + 五维诊断 |
| dbs-deconstruct | 维特根斯坦式概念审查 + 意义即使用 |
| dbs-goal | **发动机空转检测** + 三问测试 + 逐个问等回答 |
| dbs-hook | 素材丰富度五维检查 + 开头必须独立工作 |
| dbs-slowisfast | **摩擦是信息** + 资产检测 + 复利检测 |
| dao-fa-shu-qi | 道法术器四层穿透 + 第一人称口述视角 + 四维评分 |
| li-devil | **触发词从对话中长出来** + 反讨好协议 + 预验尸 + 杠铃式建议 |
| cold-water | 生理-心理桥梁 + 训练→习惯→本能 |
| karpathy-guidelines | 不做投机性设计 + 外科手术式改动 + 强成功标准 |
| BROK提示词优化器 | 猜测目标→确认→执行 |
| prompt-optimizer | BROK四维度拆解 |
| taste-skill | 禁止模式清单打破AI统计偏见 |
| gpt-tasteskill | Python驱动真随机化 |

---

## 迭代/工作流/记忆（15 个）

| Skill | 融入的机制 |
|-------|-----------|
| li-improve | Promotion Pipeline（HOT/WARM/COLD）+ 3次升级铁律 + 技能提取 |
| executing-plans | 批次执行+反馈循环 + 遇阻即停 |
| smart-task-planner-skill | DAG依赖图 + 重试机制 |
| li-plan | 渐进式规划 + auto/manual分类 |
| writing-plans | 假设执行者什么都不知道 + TDD微迭代 |
| li-plan | 评分模型排程 + 习惯学习机制 |
| li-workflow | 优先使用已有工具 |
| conversation-to-knowledge | **教训必须有载体** + 教训四分类法 + 去重机制 |
| session-summary | 不可跳过审计 + 技能组联动检查 |
| daily-review | 模块化输出 + 遗漏提醒 |
| post-task-audit | **第1次就强制执行** + 双检查机制 |
| li-sync | **真源+分发**架构 + 变量替换机制 |
| longmemory | **唯一写入者** + 语义去重 + 长期vs每日价值区分 |
| li-memory | 事件类型驱动差异化保留 + Capsule概念 |
| skill-creator | Progressive Disclosure + 上下文窗口是公共资源 |

---

## 学习/教育/内容（15 个）

| Skill | 融入的机制 |
|-------|-----------|
| interactive-learning | **诊断起点**（先判断水平）+ 自适应推进 + 检查站机制 |
| thinking-coach | 苏格拉底式提问 + 费曼技巧 + 知识分类四档 |
| learning-boost | 采集→消化→检验 + 领域全景 |
| AI方法论学习器 | 看到→提炼→确认→产出 + 只完成Phase 1不算完成 |
| shizhanying-coach | 道法术器+四维收获+能力双栈 |
| li-mindcoach | 填空>讲解 + 认知科学原句引用 |
| nature-skills | 一手资料驱动 |
| blog-post-writer | 从成功样本逆向拆解模板 |
| khazix-writer | 四层自检体系 + AI角色边界 |
| viral-content-tools | 叙事模型公式化 + 风格精选改写 |
| 案例拆解生成器 | **版本化迭代** + 黄金法则提炼 + 文件夹作为外部记忆 |
| 文风DNA分析 | 量化编码让文风可比较 |
| chinese-natural-voice-revision | AI味诊断清单 + 不创造看似真实的例子 |
| niuma-voice-dna | 语言五要素 + 百大认知引用铁律 |
| jc-clarifier | **行动锁** + 澄清漏斗 + 行家视角校准 |

---

## 工具/采集/社媒（10 个）

| Skill | 融入的机制 |
|-------|-----------|
| baoyu-danger-x-to-markdown | consent.json机制 + 媒体下载工作流 |
| wechat-article-collector | 双通道采集 + HTML选择器映射 |
| transcript-cleaner | 道法术器四层拆解 + 术语校正 |
| pdf | 多工具栈互补 + Quick Reference表 |
| deepl | API封装统一 + 重试逻辑 |
| data-analysis | 安全探查原则 + 五步质量检查 |
| deep-review | 模块化分析维度 + 数据支撑要求 |
| personal-rag-qa | 三层检索策略 + 引用均衡机制 |
| anything-to-notebooklm | 多源输入自动识别 + 格式转换链 |
| output-skill | 禁止截断 + 完整输出 |
