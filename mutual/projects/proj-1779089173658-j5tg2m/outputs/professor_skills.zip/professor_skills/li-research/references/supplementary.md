3. ❌ 只搜不读 → ✅ 至少点开 5 个网页
4. ❌ 声称"够了"没产出文件 → ✅ 文件落盘+验证才完成
5. ❌ 搜中文就完事 → ✅ 外网优先，GitHub/X/Reddit/YouTube 必搜

> 完整反模式清单（7条禁止 + 7个反模式详解 + 违规检测信号）→ `references/anti-patterns.md`


## Case Studies

### Case 1: Supermemory 技术分析
- **场景**：用户要求学习 supermemory 并融入 li-memory
- **过程**：Phase 0 态态预判（知识升级）→ Phase 1 目标锁定 → Phase 2 多平台采集（GitHub 23.2K★ + 学术论文 + 文档）→ Phase 3 道法术器穿透 → Phase 4 输出
- **产出**：技术分析报告 + li-memory v2.0 升级方案
- **教训**：先搜宽泛关键词（self-improving），不加平台限定

### Case 2: 嵌入式 Arduino skill 市场调研
- **场景**：需要创建 li-hardware skill
- **过程**：四阶段搜索（skills.sh → GitHub → AIHot → Reddit）→ Top 10 分析 → 选择性吸收
- **产出**：6 个高质量来源（最高 459★）+ li-hardware v1.0
- **教训**：搜索结果最高 <100★ → 关键词太窄，换更宽泛的词重搜

### Case 3: 竞赛区 FPGA 经验全量扫描
- **场景**：竞赛区有大量未吸收的硬件经验
- **过程**：4 个并行 Agent 递归扫描 → 1844 文件 / 468 目录 → 提取 14 个 SOP + 30+ 教训
- **产出**：li-hardware v3.0（25 个 reference 文件）
- **教训**：深层嵌套目录（4-7 层）同样有高价值文件，必须全递归扫描


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 精确匹配搜灵感 | 只找到小圈子（<13★） | 宽泛关键词 + 全平台 |
| 2 | 搜完不读完整文件 | 只看 README 不看实现 | 读 Top 3 的完整 SKILL.md |
| 3 | 不标引用可信度 | 把传言当事实 | `数值 (来源) [A/B/C/D]` |
| 4 | 只搜一个平台 | 漏掉 90% 的好内容 | 四阶段：技能库→GitHub→综合平台→社区 |
| 5 | 搜完不存档 | 下次重新搜 | Phase 7 知识归档 |
| 6 | 搜索饱和后还继续搜 | 边际收益递减 | 3 轮连续无新发现 → 停止 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-bestskill** | 技能市场搜索（四阶段策略） | "搜类似 skill""有没有现成的" |
| **li-analyze** | 调研结果的道法术器深度分析 | "深度分析这个结论" |
| **li-devil** | 调研结论的泼冷水质疑 | "这个结论靠谱吗" |
| **li-industry** | 行业级深度研究 | "行业分析""赛道调研" |
| **li-prompt** | 调研报告的 AI 辅助写作 | "帮我写调研报告" |
