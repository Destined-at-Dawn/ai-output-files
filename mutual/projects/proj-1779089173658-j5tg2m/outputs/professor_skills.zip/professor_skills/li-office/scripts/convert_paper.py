"""
convert_paper.py - Markdown 论文转 PDF（Pandoc + XeLaTeX）
用法:
    python convert_paper.py input.md
    python convert_paper.py input.md --template cn-paper --format pdf
    python convert_paper.py input.md --template ieee
    python convert_paper.py input.md --template nature
    python convert_paper.py input.md --csl custom.csl --bibliography refs.bib

自动检测同目录下的 references.bib（如有）。
输出到输入文件同目录，文件名自动加 -paper 后缀。

支持的模板:
    cn-paper  - 中文论文（ctexart + 国标格式，默认）
    ieee      - IEEE 会议/期刊（双栏）
    nature    - Nature/通用英文期刊

环境要求:
    - Pandoc >= 3.0
    - MiKTeX（含 xelatex + ctex 包）
    - templates/*.tex 和 csl-*.csl 在 scripts/../references/ 下
"""
import subprocess
import shutil
import argparse
from pathlib import Path
import sys

SCRIPT_DIR = Path(__file__).parent
SKILL_DIR = SCRIPT_DIR.parent
REFS_DIR = SKILL_DIR / "references"

# 模板配置
TEMPLATES = {
    "cn-paper": {
        "template": REFS_DIR / "template-cn-paper.tex",
        "csl": REFS_DIR / "csl-gbt7714.csl",
        "label": "中文论文",
    },
    "ieee": {
        "template": REFS_DIR / "template-ieee.tex",
        "csl": REFS_DIR / "csl-ieee.csl",
        "label": "IEEE",
    },
    "nature": {
        "template": REFS_DIR / "template-nature.tex",
        "csl": REFS_DIR / "csl-nature.csl",
        "label": "Nature/英文期刊",
    },
}

MIMETEX = Path(r"C:\Users\13975\AppData\Local\Programs\MiKTeX\miktex\bin\x64")


def check_pandoc():
    if not shutil.which("pandoc"):
        print("ERROR: Pandoc not found. Install from https://pandoc.org/installing.html")
        sys.exit(1)
    # Check MiKTeX
    miktex_path = MIMETEX
    if miktex_path.exists():
        import os
        os.environ["PATH"] = os.environ["PATH"] + ";" + str(miktex_path)
    if not shutil.which("xelatex"):
        print("ERROR: XeLaTeX not found. Install MiKTeX from https://miktex.org/")
        sys.exit(1)


def find_bib_file(input_path: Path) -> Path | None:
    """在输入文件同目录和父目录查找 references.bib"""
    for d in [input_path.parent, input_path.parent.parent]:
        bib = d / "references.bib"
        if bib.exists():
            return bib
    return None


def convert(input_file: Path, template_key: str = "cn-paper",
            custom_csl: str = None, custom_bib: str = None):
    check_pandoc()

    if template_key not in TEMPLATES:
        print(f"ERROR: Unknown template '{template_key}'. Choose from: {', '.join(TEMPLATES.keys())}")
        sys.exit(1)

    cfg = TEMPLATES[template_key]
    template = cfg["template"]
    csl = cfg["csl"]
    label = cfg["label"]

    if not template.exists():
        print(f"ERROR: Template not found: {template}")
        sys.exit(1)
    if not csl.exists():
        print(f"ERROR: CSL not found: {csl}")
        sys.exit(1)

    # Bib file
    bib = None
    if custom_bib:
        bib = Path(custom_bib)
    else:
        bib = find_bib_file(input_file)

    # Custom CSL
    if custom_csl:
        csl = Path(custom_csl)

    # Output
    stem = input_file.stem
    outdir = input_file.parent
    outpath = outdir / f"{stem}-paper.pdf"

    # Build pandoc command
    cmd = [
        "pandoc", str(input_file),
        "-o", str(outpath),
        f"--template={template}",
        "--pdf-engine=xelatex",
        f"--csl={csl}",
        "--citeproc",
        "--number-sections",
        "--toc",
    ]
    if bib:
        cmd.append(f"--bibliography={bib}")

    print(f"[Paper] Input: {input_file.name}")
    print(f"[Paper] Template: {label}")
    print(f"[Paper] CSL: {csl.name}")
    if bib:
        print(f"[Paper] Bibliography: {bib.name}")
    print(f"[Paper] Output: {outpath.name}")
    print()

    result = subprocess.run(cmd, capture_output=True, text=True, errors="replace")

    if result.returncode != 0:
        print("=== Pandoc/XeLaTeX ERROR ===")
        # Filter out harmless MiKTeX warnings
        errors = [l for l in result.stderr.splitlines()
                  if "major issue" not in l and l.strip()]
        print("\n".join(errors[-30:]))
        sys.exit(1)

    if outpath.exists():
        size_kb = outpath.stat().st_size / 1024
        print(f"[OK] {outpath} ({size_kb:.0f} KB)")
    else:
        print("[FAIL] Output not created")
        sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Markdown 论文 → PDF（Pandoc + XeLaTeX）")
    parser.add_argument("input", type=Path, help="Input .md file")
    parser.add_argument("--template", default="cn-paper", choices=list(TEMPLATES.keys()),
                        help="Paper template (default: cn-paper)")
    parser.add_argument("--csl", default=None, help="Custom CSL file path")
    parser.add_argument("--bibliography", default=None, help="Custom .bib file path")
    args = parser.parse_args()

    if not args.input.exists():
        print(f"ERROR: File not found: {args.input}")
        sys.exit(1)

    convert(args.input, args.template, args.csl, args.bibliography)
