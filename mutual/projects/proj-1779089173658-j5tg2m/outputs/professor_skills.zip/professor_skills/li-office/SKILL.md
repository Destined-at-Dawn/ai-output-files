---
name: li-office
version: "2.4"
description: li系列 · Office全栈处理（Word/Excel/PDF/PPT/学术论文），已吸收li-pptx + 论文模板系统 + 论文自动化创建
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/tool-matrix.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[常用库] -> **必须** `Read references/common-libraries.md`
- 场景[反模式] -> **必须** `Read references/anti-patterns.md`
- 场景[MD转DOCX/PDF] -> **必须** `Read references/md-conversion-guide.md`
- 场景[学术论文/期刊/会议论文] -> **必须** `Read references/paper-templates/cn-paper.md`（获取 YAML front-matter 格式）
- 场景[正式投稿/官方模板] -> **必须** `Read references/templates/official/CATALOG.md`（选择正确的官方 cls 模板）

### [STOP] 门禁

- Phase 执行前：确认已读取 references/tool-matrix.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-office v2.3（已吸收 li-pptx + convert_md_to_docx_pdf.py + 论文模板系统 + 官方LaTeX模板）

## 融合历史
| 版本 | 日期 | 吸收来源 | 内容 |
|------|------|----------|------|
| v2.0 | 2026-06-11 | li-pptx | 路径E(PPT演示文稿) — 答辩/汇报专项、金字塔原则、视觉层次 |
| v2.1 | 2026-06-11 | convert_md_to_docx_pdf.py | 路径D(MD→DOCX/PDF) — Pandoc首选+纯Python后备双策略，Tectonic轻量TeX方案 |
| v2.2 | 2026-06-11 | 论文模板系统 | 路径D-3(学术论文排版) — 3种论文模板(cn-paper/ieee/nature) + 3种CSL引用样式 + convert_paper.py |
| v2.3 | 2026-06-11 | 官方LaTeX模板 | 3大模板体系(IEEEtran/Elsevier/SpringerNature) 54文件 + 模板选择指南 + 覆盖TPEL/TIE/TRO/ICRA/IROS/Nature/MI |
| v2.4 | 2026-06-11 | 论文自动化创建 | 路径D-5(论文自动化创建) — 输入期刊名+标题 → 自动创建完整论文目录结构 + new_paper.py + 支持20+期刊 |

> **兼容性**: v1.x 的主 SKILL.md 不存在 → v2.0 即首版。fused_from 信息见 _meta.json。

## 元数据
版本: 2.3 | 难度: 中级 | 预估时间: 5-45min | 频次控制: 无限

## 触发词
Word文档, docx, Excel, xlsx, 表格, PDF, PPT, 演示文稿, Office,
文档处理, 电子表格, 数据分析, 报告, 合同, 表单, 批量处理,
文档合并, 文档拆分, 格式转换, 数据透视表, 图表, 公式,
课件, 汇报, 答辩, 演讲, slide, presentation, 幻灯片,
python-pptx, 演示, 课件制作, 汇报PPT, 答辩PPT,
md转docx, markdown转word, markdown转pdf, md转pdf, md文档转换, markdown转换,
论文, paper, 学术论文, 期刊, 会议论文, 论文排版, 论文模板, LaTeX, XeLaTeX,
GB/T 7714, IEEE, Nature, 参考文献, BibTeX, 引用格式, 学术写作, 论文转换,
创建论文, 新建论文, 论文创建, 论文新建, TPEL, Nature Energy, Applied Energy,
IEEE论文, Elsevier论文, Springer论文, 论文目录

## Phase 0: 需求消解
1. 文件类型: Word/Excel/PDF/PPT/论文？输入还是输出？
2. 操作类型: 创建/编辑/转换/合并/拆分/分析？
3. 数据来源: 已有文件/从零创建/从其他格式转换？
4. 复杂度: 简单(单文件)/中等(多文件)/复杂(批量+自动化)？
5. 输出要求: 格式/样式/模板/兼容性？
6. PPT场景（如适用）: 课件/汇报/答辩/路演/培训？
7. 论文场景（如适用）: 中文论文(国标)/IEEE会议/Nature期刊？有 references.bib？

## Phase 1: 执行路径

### 路径A: Word文档处理 (docx)
适用: 创建/编辑/分析 .docx 文件
工具: python-docx / pandoc / docx-js
能力: 创建专业文档(目录/页眉页脚/样式) / 编辑已有文档 / 内容提取 / 格式转换
流程: 确定模板 → 内容结构 → 生成/编辑 → 格式检查
关键: 样式必须用 Heading 1/2/3，不能手动加粗加大字号（否则无法生成目录）

### 路径B: Excel数据处理 (xlsx)
适用: 创建/编辑/分析 .xlsx 文件
工具: openpyxl / pandas / xlsxwriter
能力: 数据录入 / 公式计算 / 数据透视 / 图表生成 / 财务模型 / 数据清洗
流程: 数据源确认 → 结构设计 → 公式/图表 → 格式美化
关键: 公式错误 #REF! #DIV/0! 必须在交付前全量检查

### 路径C: PDF处理 (pdf)
适用: 创建/编辑/分析/转换 PDF 文件
工具: pypdf / pdfplumber / reportlab / markitdown
能力: 文本提取 / 表格提取 / 合并拆分 / 水印 / 加密 / OCR / 表单填写
流程: 确定操作 → 选择工具 → 执行 → 验证输出
关键: PDF表格提取常遇合并单元格，必须人工校验

### 路径D: Markdown→DOCX/PDF 转换
适用: 将 .md 文件转换为 .docx 和 .pdf（适合实验文档/技术报告/项目文档的格式交付）
策略: **Pandoc 首选 → 纯 Python 后备**（按本机环境自动选择）

#### 路径D-1: Pandoc 转换（首选）
条件: `pandoc --version` 可用（本机已装 3.10）
工具: Pandoc（MD→DOCX 直接转换，MD→PDF 需 TeX 后端）
能力:
- DOCX: 标题/表格/代码块/列表/引用/图片/脚注/数学公式，全部原生支持
- PDF: 需 TeX 后端（XeLaTeX/LuaLaTeX/Tectonic 任一），中文排版用 ctex 宏包
命令:
```bash
# MD → DOCX（零额外依赖）
pandoc input.md -o output.docx

# MD → DOCX（自定义模板）
pandoc input.md -o output.docx --reference-doc=template.docx

# MD → PDF（需 TeX 后端 + ctex 中文支持）
pandoc input.md -o output.pdf --pdf-engine=xelatex -V CJKmainfont="SimSun"

# MD → PDF（Tectonic 轻量替代，~50MB vs TeX Live 4GB）
pandoc input.md -o output.pdf --pdf-engine=tectonic -V CJKmainfont="SimSun"

# 批量转换（通配符）
for f in *.md; do pandoc "$f" -o "${f%.md}.docx"; done
```
关键:
- DOCX 输出质量远超手写解析器（支持图片、嵌套列表、脚注、数学公式）
- PDF 输出需额外安装 TeX 后端：推荐 Tectonic（~50MB，自动下载依赖包）
- 中文 PDF: XeLaTeX + ctex 宏包是行业标准，字体用 `CJKmainfont` 参数指定
- 无 TeX 后端时，DOCX 照常可用，PDF 降级到路径D-2

#### 路径D-2: 纯 Python 后备（零依赖）
条件: Pandoc 不可用 或 仅需简单转换
工具: python-docx + fpdf2
脚本: `scripts/md-to-docx-pdf.py`（自包含，含 Markdown 解析器 + Word/PDF 生成器）
指南: `references/md-conversion-guide.md`
能力: 标题/段落/粗体/行内代码/代码块/有序列表/无序列表/表格/水平分割线
关键:
- 中文字体路径硬编码为 Windows（SimHei/微软雅黑）
- 不支持图片嵌入和嵌套列表
- 适合简单文档快速转换，复杂文档用 D-1

#### 路径D-3: 学术论文排版（Pandoc + XeLaTeX，学术写作专用）
适用: 学术论文/期刊投稿/会议论文/学位论文（从 Markdown 写作 → 专业 PDF 排版）
工具: Pandoc + XeLaTeX + CSL 引用样式 + BibTeX
脚本: `scripts/convert_paper.py`（一键论文 PDF 转换）
模板: `references/template-cn-paper.tex` / `template-ieee.tex` / `template-nature.tex`
引用样式: `references/csl-gbt7714.csl`（国标）/ `csl-ieee.csl` / `csl-nature.csl`
模板示例: `references/paper-templates/cn-paper.md`（含 YAML front-matter 示范）

能力:
- 三种论文格式：中文论文（国标 GB/T 7714）、IEEE 双栏、Nature/英文期刊
- 自动参考文献管理：BibTeX + citeproc，引用格式自动适配
- 专业排版：章节自动编号、三线表、数学公式、代码高亮、目录生成
- 自动 bib 检测：同目录或父目录的 references.bib 自动加载

命令:
```bash
# 中文论文（默认）
python scripts/convert_paper.py 论文.md

# IEEE 会议论文
python scripts/convert_paper.py 论文.md --template ieee

# Nature/英文期刊
python scripts/convert_paper.py 论文.md --template nature

# 自定义 bib 文件
python scripts/convert_paper.py 论文.md --bibliography my-refs.bib
```

Markdown 论文格式要求:
1. YAML front-matter 必须包含: title, author, date, abstract, keywords
2. 正文: 标准 Markdown + `$...$` 数学公式 + `[@cite-key]` 引用
3. 图片: `![caption](path)` 相对于 .md 文件路径

关键:
- 模板含完整 Pandoc citeproc 宏定义（CSLReferences/citeproc/citeproctext），已修复常见 LaTeX 报错
- 中文字体默认用 ctex 自动配置（宋体正文/黑体标题），需要 Times New Roman 时取消模板注释
- MiKTeX 首次使用会自动下载缺失宏包，需联网

#### 路径D-4: 官方 LaTeX 模板（正式投稿用，Overleaf/LaTeX 编译）
适用: 正式期刊/会议投稿（非 Pandoc 快速排版，而是用官方 cls + LaTeX 直接编译）
模板库: `references/templates/official/`（54文件，3大体系）

| 体系 | cls 文件 | 适用场景 | 示例期刊/会议 |
|------|---------|---------|-------------|
| **IEEE** | IEEEtran.cls | 电气/电力电子/机器人 | TPEL, TIE, TRO, ICRA, IROS, RA-L, APEC, ECCE |
| **Elsevier** | elsarticle.cls | 能源/控制 | Applied Energy, Energy, Automatica |
| **Springer Nature** | sn-jnl.cls | 综合顶刊/子刊 | Nature, Nature Comms, Nature Energy, Nature MI |

选择指南:
- **电气/电力电子** → IEEEtran.cls（期刊）或 elsarticle.cls（Applied Energy/Energy）
- **具身智能/机器人** → IEEEtran.cls（TRO/RA-L）或 sn-jnl.cls（Nature MI）或各ML会议模板
- **详细目录和 Overleaf 链接**: `references/templates/official/CATALOG.md`

使用方式:
```
1. 确定目标期刊/会议
2. Read references/templates/official/CATALOG.md 查对应模板
3. 将 official/{体系}/ 中的 .cls + .bst 复制到用户项目目录
4. 基于模板 .tex 示例改造用户论文内容
5. 用 MiKTeX/Overleaf 编译生成 PDF
```

关键:
- 正式投稿**必须用官方模板 + LaTeX 编译**，Pandoc 快速模板仅适合初稿/作业
- IEEEtran.cls 是"一个模板覆盖所有 IEEE 期刊/会议"，仅改 `\documentclass` 选项
- Nature 仅支持 pdfLaTeX（不支持 XeLaTeX），中文需特殊处理
- Overleaf 是最省事的在线编译方案，CATALOG.md 中有所有快捷链接

#### 路径D-5: 论文自动化创建（期刊名 → 完整目录）
适用: 输入期刊名和论文标题，自动创建完整的论文目录结构（含模板文件 + main.tex + 子目录）
工具: `E:\ai产出文件\论文\scripts\new_paper.py`
能力: 自动匹配期刊 → 复制正确模板 → 生成符合期刊要求的 main.tex 框架 → 创建标准目录结构

**快速调用**:
```bash
# 创建 TPEL 论文
python "E:/ai产出文件/论文/scripts/new_paper.py" "TPEL" "Your Paper Title" "Your Name"

# 创建 Nature Energy 论文
python "E:/ai产出文件/论文/scripts/new_paper.py" "Nature Energy" "Your Paper Title"

# 创建 Applied Energy 论文
python "E:/ai产出文件/论文/scripts/new_paper.py" "Applied Energy" "Your Paper Title"
```

**支持的期刊**（自动识别）:
- IEEE: TPEL, TIE, TII, TSG, TRO, RA-L, ICRA, IROS, APEC, ECCE
- Elsevier: Applied Energy, Energy, Energy Conversion and Management, Automatica
- Springer Nature: Nature, Nature Communications, Nature Energy, Nature Machine Intelligence

**生成的目录结构**:
```
papers/your-paper-title-20260611/
├── main.tex          # 已配置好期刊格式的主文件
├── references.bib    # 空的参考文献文件
├── figures/          # 图片目录
├── sections/         # 分章节文件目录
├── *.cls             # 文档类
├── *.bst             # 引用样式
└── README.md         # 编译说明
```

**编译命令**:
```bash
cd papers/your-paper-title-20260611
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

关键:
- **零配置**: 只需提供期刊名和标题，自动完成所有模板配置
- **官方模板**: 使用 E 盘 `论文/templates/` 的官方最新模板（已验证来源）
- **兼容性**: 生成的 main.tex 可直接在 Overleaf 或本地 MiKTeX 编译
- **可扩展**: 如需新增期刊，编辑 `new_paper.py` 的 JOURNAL_MAP 字典

### 路径E: PPT演示文稿（深度策略 — 来自 li-pptx）
适用: 课件/汇报/答辩/路演/培训/演示文稿创建
工具: python-pptx / 手动指导
流程:
1. **内容结构**（金字塔原则）
   - 每页一个核心观点，不超过3个要点
   - 标题 = 结论（不是"数据分析"而是"销量增长23%"）
   - 结构: 议题 → 论据 → 行动建议
2. **视觉层次**
   - 标题字号 ≥ 正文2倍
   - 关键数字放大加粗
   - 留白 ≥ 30%（不是塞满页面）
3. **生成执行**
   - 确定模板/母版 → 逐页填充 → 图表插入 → 动画设置
   - 数据页: 图表标题就是结论，不是"图1"
4. **答辩/汇报专项**
   - 开场: 问题是什么 → 为什么重要 → 我做了什么
   - 结尾: 结论 → 局限性 → 下一步
   - 附录: 备用数据页（应对提问）

## Phase 2: 质量验证
- 文件是否能正常打开？(兼容性检查)
- 格式是否符合要求？(字体/颜色/间距)
- 数据是否准确？(公式/链接/引用)
- 输出大小是否合理？(图片压缩/嵌入字体)
- PPT专项: 每页≤3要点？标题=结论？留白充分？
- 论文专项: 参考文献是否正确显示？章节编号是否连续？中文"等"是否替代了"et al"？

## 案例库

### 案例1: FPGA竞赛答辩PPT
- **场景**: FPGA 项目需要 20 页答辩 PPT，含时序报告/架构图/波形截图
- **做法**: li-office 路径D → python-pptx 从 template 克隆 → 填充数据 → 自动生成图表
- **结果**: 30 分钟自动生成（手动需 4 小时）
- **教训**: 答辩PPT每页不超过3个要点，评委看的是逻辑不是文字量
- **来源**: D:\AMD 竞赛项目

### 案例2: 实验数据整理 (Excel)
- **场景**: 整理实验室采集的 50 组数据
- **做法**: li-office 路径B → 数据清洗 → 公式计算 → 图表生成 → 条件格式
- **教训**: Excel公式错误 #REF! #DIV/0! 等，交付前必须全量检查

### 案例3: 论文PDF提取表格
- **场景**: 论文PDF中的对比表需要提取到Excel
- **做法**: li-office 路径C → pdfplumber提取 → 结构化 → 输出Excel
- **教训**: PDF表格提取经常遇到合并单元格，需要手动校验

### 案例4: 小红书数据分析汇报PPT
- **场景**: 需要汇报小红书运营数据
- **做法**: li-office 路径D + li-analyze 数据支撑 → 30页商务风格
- **教训**: 数据页必须结论先行，图表标题就是结论
- **联动**: li-analyze 分析原始数据 → li-office 生成PPT

### 案例5: 课程课件批量生成
- **场景**: 将一章教材内容做成课件
- **做法**: li-office 路径E + li-transcript 内容提取 → 按知识点分页
- **教训**: 课件需要留白给讲解空间，不要把所有内容都塞进去

### 案例6: 实验文档 MD→Word+PDF 批量转换
- **场景**: FPGA 实验报告需要从 .md 格式交付为 .docx + .pdf（公司格式要求）
- **做法**: li-office 路径D → md-to-docx-pdf.py 批量转换，含表格/代码块/中文排版
- **结果**: 2 个实验文档一次性双格式输出（手动排版需 2 小时 → 10 秒自动完成）
- **教训**: 纯本地脚本（python-docx + fpdf2）零 API 调用，适合批量重复使用
- **来源**: 竞赛区 LCD 驱动开发项目

### 案例7: 学术论文 Markdown→PDF 一键排版
- **场景**: 用 Markdown 写论文初稿，需要转为带参考文献的专业 PDF（中文国标/IEEE/Nature 格式）
- **做法**: li-office 路径D-3 → convert_paper.py 一键转换，Pandoc + XeLaTeX + GB/T 7714 引用样式
- **结果**: 从 Markdown 到带参考文献的 PDF（74KB），含章节编号、三线表、数学公式，3 秒完成
- **教训**: Pandoc citeproc 需要 LaTeX 模板含完整的 CSLReferences/citeproc 宏定义，否则参考文献不显示
- **来源**: mutual 工作区论文模板系统

### 案例8: 官方LaTeX模板库建设（3大体系，54文件）
- **场景**: 正式期刊投稿（TPEL/Nature MI/Applied Energy）需要官方 cls 模板，Pandoc 快速模板不满足投稿要求
- **做法**: li-office 路径D-4 → 下载 IEEEtran.cls + elsarticle.cls + sn-jnl.cls 三大模板体系，附选择指南和 Overleaf 链接
- **结果**: 54 个文件覆盖 13+ 个目标期刊/会议，CATALOG.md 包含完整选择指南
- **教训**: IEEEtran.cls 是"一个模板覆盖所有 IEEE 期刊/会议"（CTAN 下载 404→从 MiKTeX 本地提取）；Nature 仅 pdfLaTeX；Elsevier 的 cls 需从 .ins 文件生成
- **来源**: mutual 工作区论文模板系统 v2.3

## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|------|------|
| T1 | 金字塔原理 | 每页一个核心观点，标题=结论 |
| T2 | 认知负荷理论 | 每页≤3要点，避免信息过载 |
| T3 | 视觉层次理论 | 字号/粗细/颜色引导阅读顺序 |
| T4 | 规则三 | 三个要点/三个方案/三个案例 |
| T5 | 默会知识 | 格式规范是隐性专业门槛 |

## 反模式
- ❌ 文字堆砌 — 每页超过5个要点 = 不是PPT是Word
- ❌ 无视觉层次 — 所有文字同样大小 = 读者找不到重点
- ❌ 手动格式代替样式 — 用加粗+字号代替Heading样式 = 无法生成目录
- ❌ 公式不检查 — #REF! #DIV/0! 交付 = 专业度为零
- ❌ PDF提取不校验 — OCR/表格提取有错误率，必须人工校验
- ❌ 不考虑兼容性 — 用了高级特性但用户用旧版Office打不开
- ❌ 图片不压缩 — 文档里塞10张5MB的图 = 文件100MB
- ❌ 模板滥用 — 花哨模板+严肃内容 = 不专业
- ❌ Pandoc模板正式投稿 — Pandoc快速模板≠官方模板，正式投稿必须用官方cls+LaTeX编译
- ❌ 动画过多 — 每页3种动画 = 分散注意力

## 联动技能
- li-analyze: 数据分析支撑Excel图表和PPT数据页
- li-design: PPT视觉设计/品牌模板
- li-image: 配图/图标/信息图生成
- li-transcript: 语音/文字稿提取要点
- li-debug: 文档格式问题排查
- li-visual: 视觉风格学习与配图

## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [PPT需要数据] | Call li-analyze | 数据分析 → 图表生成 |
| [PPT需要配图] | Call li-image 或 li-visual | 视觉素材 |
| [文档需要深度分析] | Call li-analyze 道法术器 | 深度解读 |
| [质量检查] | Call li-devil 冷水审查 | 质量把关 |
| [跨工作区同步] | Call li-sync | 同步 |

## 禁忌

- **禁止**：PPT 超过 20 页——信息过载等于没有信息
- **禁止**：表格不标注单位/口径——数字没有上下文没有意义
- **禁止**：用 Office 默认模板——丑 = 不专业

---

## 模板填充规则（2026-06-15 新增）

> 来源：2026-06-14 教训闭环（任务书模板填充失败教训）

收到"基于XX模板填写"类任务时：

1. **母版唯一**：以原始模板文件作为唯一母版
2. **只填内容**：项目名称、编号、正文内容
3. **保留原样**：表格结构、段落样式、字体体系一律不动
4. **对齐规范**：正文左对齐 + 中文首行缩进；只有小标题居中
5. **交付校验**：
   - 正文单元格段落样式仍为 `Table Paragraph`
   - 普通正文没有居中对齐
   - `document.xml` 中正文大栏 `center_count=0`

**禁止**："重做文档"——只能"打开模板 → 填内容 → 局部必要修正 → 校验结构未变"
