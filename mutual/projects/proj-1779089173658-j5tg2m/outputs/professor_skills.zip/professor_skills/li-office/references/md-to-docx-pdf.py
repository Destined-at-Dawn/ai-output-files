"""
Markdown → Word(.docx) + PDF 转换脚本
用途：将实验文档的 .md 格式转换为公司交付用的 .docx 和 .pdf
依赖：python-docx（已安装）、fpdf2（已安装）
字体：Windows 自带 SimHei（黑体）+ Consolas（代码）
"""

import re
import os
import sys

# ============================================================
# 第一部分：Markdown 解析器
# ============================================================

def parse_markdown(md_text):
    """将 markdown 文本解析为结构化元素列表"""
    lines = md_text.split('\n')
    elements = []
    i = 0
    in_code_block = False
    code_lines = []
    code_lang = ''

    while i < len(lines):
        line = lines[i]

        # 代码块开始/结束
        if line.strip().startswith('```'):
            if in_code_block:
                elements.append(('code', '\n'.join(code_lines), code_lang))
                code_lines = []
                code_lang = ''
                in_code_block = False
            else:
                in_code_block = True
                code_lang = line.strip()[3:].strip()
            i += 1
            continue

        if in_code_block:
            code_lines.append(line)
            i += 1
            continue

        stripped = line.strip()

        # 空行
        if not stripped:
            i += 1
            continue

        # 水平分割线
        if stripped in ('---', '***', '___'):
            elements.append(('hr', '', ''))
            i += 1
            continue

        # 标题
        m = re.match(r'^(#{1,4})\s+(.+)', line)
        if m:
            level = len(m.group(1))
            elements.append(('heading', m.group(2).strip(), level))
            i += 1
            continue

        # 表格（连续的 | 开头行）
        if stripped.startswith('|'):
            table_rows = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                row_text = lines[i].strip()
                # 跳过分隔行 |---|---|
                if re.match(r'^\|[\s\-:]+\|', row_text) and '|' in row_text[1:]:
                    cells = [c.strip() for c in row_text.split('|')[1:-1]]
                    if all(re.match(r'^[\s\-:]*$', c) for c in cells):
                        i += 1
                        continue
                cells = [c.strip() for c in row_text.split('|')[1:-1]]
                table_rows.append(cells)
                i += 1
            if table_rows:
                elements.append(('table', table_rows, ''))
            continue

        # 有序列表
        m = re.match(r'^(\d+)\.\s+(.+)', stripped)
        if m:
            items = []
            while i < len(lines):
                m2 = re.match(r'^(\d+)\.\s+(.+)', lines[i].strip())
                if m2:
                    items.append(m2.group(2).strip())
                    i += 1
                else:
                    break
            elements.append(('ol', items, ''))
            continue

        # 无序列表
        if re.match(r'^[-*]\s+', stripped):
            items = []
            while i < len(lines) and re.match(r'^[-*]\s+', lines[i].strip()):
                items.append(re.sub(r'^[-*]\s+', '', lines[i].strip()))
                i += 1
            elements.append(('ul', items, ''))
            continue

        # 普通段落
        para_lines = []
        while i < len(lines):
            s = lines[i].strip()
            if not s or s.startswith('#') or s.startswith('|') or s.startswith('```') or s in ('---', '***', '___') or re.match(r'^\d+\.\s+', s) or re.match(r'^[-*]\s+', s):
                break
            para_lines.append(s)
            i += 1
        if para_lines:
            elements.append(('para', ' '.join(para_lines), ''))

    return elements


# ============================================================
# 第二部分：Word (.docx) 生成
# ============================================================

def create_docx(elements, output_path, title='实验文档'):
    """从解析后的元素列表生成 Word 文档"""
    from docx import Document
    from docx.shared import Pt, Inches, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn

    doc = Document()

    # 设置默认字体
    style = doc.styles['Normal']
    font = style.font
    font.name = '微软雅黑'
    font.size = Pt(11)
    style.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

    # 设置页边距
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)

    def add_rich_text(paragraph, text):
        """解析行内格式（粗体、代码）并添加到段落"""
        parts = re.split(r'(\*\*.*?\*\*|`[^`]+`)', text)
        for part in parts:
            if part.startswith('**') and part.endswith('**'):
                run = paragraph.add_run(part[2:-2])
                run.bold = True
                run.font.name = '微软雅黑'
                run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
            elif part.startswith('`') and part.endswith('`'):
                run = paragraph.add_run(part[1:-1])
                run.font.name = 'Consolas'
                run.font.size = Pt(9.5)
                run.font.color.rgb = RGBColor(0xC7, 0x25, 0x4E)
                # 灰底
                from docx.oxml import OxmlElement
                shd = OxmlElement('w:shd')
                shd.set(qn('w:val'), 'clear')
                shd.set(qn('w:color'), 'auto')
                shd.set(qn('w:fill'), 'F5F5F5')
                run.element.rPr.append(shd)
            else:
                if part:
                    run = paragraph.add_run(part)
                    run.font.name = '微软雅黑'
                    run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

    for elem_type, content, extra in elements:
        if elem_type == 'heading':
            level = min(extra, 3)
            heading = doc.add_heading(content, level=level)
            for run in heading.runs:
                run.font.name = '微软雅黑'
                run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

        elif elem_type == 'para':
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing = 1.5
            add_rich_text(p, content)

        elif elem_type == 'ol':
            for idx, item in enumerate(content, 1):
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(3)
                p.paragraph_format.line_spacing = 1.5
                p.paragraph_format.left_indent = Cm(0.5)
                run = p.add_run(f'{idx}. ')
                run.font.name = '微软雅黑'
                run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
                add_rich_text(p, item)

        elif elem_type == 'ul':
            for item in content:
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(3)
                p.paragraph_format.line_spacing = 1.5
                p.paragraph_format.left_indent = Cm(0.5)
                run = p.add_run('- ')
                run.font.name = '微软雅黑'
                run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
                add_rich_text(p, item)

        elif elem_type == 'table':
            rows = content
            if not rows:
                continue
            ncols = max(len(r) for r in rows)
            table = doc.add_table(rows=len(rows), cols=ncols, style='Table Grid')
            table.alignment = WD_TABLE_ALIGNMENT.CENTER

            for ri, row_data in enumerate(rows):
                for ci, cell_text in enumerate(row_data):
                    if ci < ncols:
                        cell = table.rows[ri].cells[ci]
                        cell.text = ''
                        p = cell.paragraphs[0]
                        p.paragraph_format.space_before = Pt(2)
                        p.paragraph_format.space_after = Pt(2)
                        run = p.add_run(cell_text)
                        run.font.name = '微软雅黑'
                        run.font.size = Pt(10)
                        run.element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')

                        # 表头行加粗+灰底
                        if ri == 0:
                            run.bold = True
                            from docx.oxml import OxmlElement
                            shd = OxmlElement('w:shd')
                            shd.set(qn('w:val'), 'clear')
                            shd.set(qn('w:color'), 'auto')
                            shd.set(qn('w:fill'), 'E8E8E8')
                            cell._tc.get_or_add_tcPr().append(shd)

        elif elem_type == 'code':
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing = 1.2
            p.paragraph_format.left_indent = Cm(0.5)
            # 灰底效果（通过段落shading）
            from docx.oxml import OxmlElement
            pPr = p._element.get_or_add_pPr()
            shd = OxmlElement('w:shd')
            shd.set(qn('w:val'), 'clear')
            shd.set(qn('w:color'), 'auto')
            shd.set(qn('w:fill'), 'F5F5F5')
            pPr.append(shd)

            run = p.add_run(content)
            run.font.name = 'Consolas'
            run.font.size = Pt(9)
            run.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

        elif elem_type == 'hr':
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(6)
            pPr = p._element.get_or_add_pPr()
            from docx.oxml import OxmlElement
            pBdr = OxmlElement('w:pBdr')
            bottom = OxmlElement('w:bottom')
            bottom.set(qn('w:val'), 'single')
            bottom.set(qn('w:sz'), '6')
            bottom.set(qn('w:space'), '1')
            bottom.set(qn('w:color'), 'CCCCCC')
            pBdr.append(bottom)
            pPr.append(pBdr)

    doc.save(output_path)
    print(f'  [docx] 已生成: {output_path} ({os.path.getsize(output_path)} 字节)')


# ============================================================
# 第三部分：PDF 生成
# ============================================================

def create_pdf(elements, output_path, title='实验文档'):
    """从解析后的元素列表生成 PDF 文档"""
    from fpdf import FPDF

    class ChinesePDF(FPDF):
        def header(self):
            self.set_font('SimHei', size=9)
            self.set_text_color(150, 150, 150)
            self.cell(0, 8, title, align='C', new_x='LMARGIN', new_y='NEXT')
            self.line(10, self.get_y(), 200, self.get_y())
            self.ln(3)

        def footer(self):
            self.set_y(-15)
            self.set_font('SimHei', size=8)
            self.set_text_color(150, 150, 150)
            self.cell(0, 10, f'- {self.page_no()} -', align='C')

    pdf = ChinesePDF()
    pdf.set_auto_page_break(auto=True, margin=20)

    # 注册中文字体
    pdf.add_font('SimHei', '', 'C:/Windows/Fonts/simhei.ttf')
    pdf.add_font('SimHeiBold', '', 'C:/Windows/Fonts/simhei.ttf')  # fpdf2 无bold变体，用set_text_color区分
    pdf.add_font('Consolas', '', 'C:/Windows/Fonts/consola.ttf')

    pdf.add_page()

    PAGE_W = 190  # 可用宽度 mm
    MARGIN = 10

    def set_normal():
        pdf.set_font('SimHei', size=10)
        pdf.set_text_color(33, 33, 33)

    def set_code():
        pdf.set_font('Consolas', size=8)
        pdf.set_text_color(80, 80, 80)

    def write_rich_text(text, font_size=10):
        """解析行内格式写入PDF"""
        parts = re.split(r'(\*\*.*?\*\*|`[^`]+`)', text)
        for part in parts:
            if part.startswith('**') and part.endswith('**'):
                pdf.set_font('SimHei', size=font_size)
                pdf.set_text_color(33, 33, 33)
                pdf.write(6, part[2:-2])
            elif part.startswith('`') and part.endswith('`'):
                # 行内代码统一用SimHei，避免Consolas缺中文字形
                pdf.set_font('SimHei', size=font_size - 1)
                pdf.set_text_color(0xC7, 0x25, 0x4E)
                pdf.write(6, part[1:-1])
                pdf.set_text_color(33, 33, 33)
            else:
                if part:
                    pdf.set_font('SimHei', size=font_size)
                    pdf.set_text_color(33, 33, 33)
                    pdf.write(6, part)

    for elem_type, content, extra in elements:
        # 检查是否需要换页
        if pdf.get_y() > 265:
            pdf.add_page()

        if elem_type == 'heading':
            level = extra
            if level == 1:
                pdf.ln(8)
                pdf.set_font('SimHei', size=18)
                pdf.set_text_color(33, 33, 33)
                pdf.cell(0, 12, content, new_x='LMARGIN', new_y='NEXT')
                pdf.set_draw_color(66, 133, 244)
                pdf.set_line_width(0.8)
                pdf.line(MARGIN, pdf.get_y(), MARGIN + 80, pdf.get_y())
                pdf.ln(4)
            elif level == 2:
                pdf.ln(6)
                pdf.set_font('SimHei', size=14)
                pdf.set_text_color(50, 50, 50)
                pdf.cell(0, 10, content, new_x='LMARGIN', new_y='NEXT')
                pdf.ln(2)
            elif level >= 3:
                pdf.ln(4)
                pdf.set_font('SimHei', size=12)
                pdf.set_text_color(66, 66, 66)
                pdf.cell(0, 8, content, new_x='LMARGIN', new_y='NEXT')
                pdf.ln(2)
            set_normal()

        elif elem_type == 'para':
            pdf.set_font('SimHei', size=10)
            pdf.set_text_color(33, 33, 33)
            write_rich_text(content)
            pdf.ln(6)

        elif elem_type == 'ol':
            for idx, item in enumerate(content, 1):
                if pdf.get_y() > 265:
                    pdf.add_page()
                pdf.set_font('SimHei', size=10)
                pdf.set_text_color(33, 33, 33)
                pdf.write(6, f'{idx}. ')
                write_rich_text(item)
                pdf.ln(6)

        elif elem_type == 'ul':
            for item in content:
                if pdf.get_y() > 265:
                    pdf.add_page()
                pdf.set_font('SimHei', size=10)
                pdf.set_text_color(33, 33, 33)
                pdf.write(6, '- ')
                write_rich_text(item)
                pdf.ln(6)

        elif elem_type == 'table':
            rows = content
            if not rows:
                continue
            ncols = max(len(r) for r in rows)
            col_w = min(PAGE_W / ncols, 50)  # 自适应列宽，最宽50mm
            row_h = 7

            for ri, row_data in enumerate(rows):
                if pdf.get_y() + row_h > 275:
                    pdf.add_page()

                if ri == 0:
                    pdf.set_fill_color(232, 232, 232)
                    pdf.set_font('SimHei', size=9)
                    pdf.set_text_color(33, 33, 33)
                else:
                    pdf.set_fill_color(255, 255, 255)
                    pdf.set_font('SimHei', size=9)
                    pdf.set_text_color(50, 50, 50)

                for ci, cell_text in enumerate(row_data):
                    if ci < ncols:
                        pdf.cell(col_w, row_h, cell_text[:30], border=1,
                                 fill=(ri == 0), align='C')
                pdf.ln(row_h)
            pdf.ln(3)
            set_normal()

        elif elem_type == 'code':
            if pdf.get_y() > 250:
                pdf.add_page()
            pdf.set_fill_color(245, 245, 245)
            pdf.set_draw_color(220, 220, 220)
            pdf.set_text_color(80, 80, 80)

            x_start = pdf.get_x() + 3
            code_lines_list = content.split('\n')
            block_h = len(code_lines_list) * 5 + 4

            # 画灰底
            pdf.rect(MARGIN, pdf.get_y(), PAGE_W, block_h, style='DF')
            pdf.ln(2)

            for cl in code_lines_list:
                if pdf.get_y() > 275:
                    pdf.add_page()
                pdf.set_x(x_start)
                # 检测是否含中文字符，有则用SimHei，纯ASCII用Consolas
                has_cjk = any('一' <= ch <= '鿿' or ch in '（）：，。、；' for ch in cl)
                if has_cjk:
                    pdf.set_font('SimHei', size=8)
                else:
                    pdf.set_font('Consolas', size=8)
                pdf.cell(0, 5, cl[:90], new_x='LMARGIN', new_y='NEXT')
            pdf.ln(4)
            set_normal()

        elif elem_type == 'hr':
            pdf.ln(3)
            pdf.set_draw_color(200, 200, 200)
            pdf.set_line_width(0.3)
            pdf.line(MARGIN, pdf.get_y(), MARGIN + PAGE_W, pdf.get_y())
            pdf.ln(3)

    pdf.output(output_path)
    print(f'  [pdf]  已生成: {output_path} ({os.path.getsize(output_path)} 字节)')


# ============================================================
# 第四部分：主程序
# ============================================================

if __name__ == '__main__':
    base_dir = os.path.dirname(os.path.abspath(__file__))

    doc_dir = os.path.join(base_dir, '实验文档')

    experiments = [
        {
            'md': os.path.join(doc_dir, '实验1_LED流水灯设计.md'),
            'title': '实验一 LED流水灯设计',
            'docx': os.path.join(doc_dir, '实验一_LED流水灯设计.docx'),
            'pdf': os.path.join(doc_dir, '实验一_LED流水灯设计.pdf'),
        },
        {
            'md': os.path.join(doc_dir, '实验_TFT_LCD显示屏驱动设计.md'),
            'title': '实验 TFT-LCD显示屏驱动设计',
            'docx': os.path.join(doc_dir, '实验_TFT_LCD显示屏驱动设计.docx'),
            'pdf': os.path.join(doc_dir, '实验_TFT_LCD显示屏驱动设计.pdf'),
        },
    ]

    for exp in experiments:
        print(f'\n处理: {exp["title"]}')
        if not os.path.exists(exp['md']):
            print(f'  [跳过] 找不到 {exp["md"]}')
            continue

        with open(exp['md'], 'r', encoding='utf-8') as f:
            md_text = f.read()

        elements = parse_markdown(md_text)
        print(f'  解析完成: {len(elements)} 个元素')

        create_docx(elements, exp['docx'], exp['title'])
        create_pdf(elements, exp['pdf'], exp['title'])

    print('\n全部完成！')
