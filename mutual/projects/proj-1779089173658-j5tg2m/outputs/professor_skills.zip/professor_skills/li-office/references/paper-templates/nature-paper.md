---
title: "Paper Title for Nature/Science Style Journal"
author:
  - "First Author"
  - "Second Author"
date: "2026"
abstract: |
  Brief abstract describing the research question, approach, key findings, and significance.
bibliography: references.bib
---

# Introduction

The first paragraph introduces the research question and its significance [@zhang2023vsg].

Recent advances have demonstrated that... [@li2022review; @wang2024fpga].

# Results

## Main Finding

Our experimental results demonstrate a significant improvement in performance. The timing constraint is given by:

$$t_{setup} = T_{clk} - t_{co} - t_{logic} - t_{routing} \geq 0$$

where $T_{clk} = 10ns$.

## Performance Comparison

| Strategy | Latency | Power | Improvement |
|:---------|:--------|:------|:------------|
| Baseline | 5.2 ns | 12.3 mW | — |
| Proposed | 3.8 ns | 11.8 mW | 27% faster, 4% lower |

The proposed strategy achieves a 27% reduction in latency while maintaining lower power consumption.

## Robustness Analysis

The method remains stable across varying operating conditions...

# Discussion

These findings have important implications for... The key insight is that...

# Methods

## System Design

Technical details of the implementation...

## Experimental Protocol

Description of experimental procedures...

# Data Availability

All data generated or analysed during this study are included in this published article.

# Code Availability

Code is available at [repository URL].

# References
