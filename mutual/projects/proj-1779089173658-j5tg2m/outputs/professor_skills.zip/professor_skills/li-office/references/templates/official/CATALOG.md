# 学术论文官方模板目录

> 适用领域：电气工程、具身智能、电力电子、机器人学
> **模板实际位置**: `E:\ai产出文件\论文\templates\`（已从 C 盘迁移到 E 盘论文工作目录）
> 详见: `E:\ai产出文件\论文\README.md`

---

## 一、IEEE 模板体系（IEEEtran.cls — 一个模板覆盖所有 IEEE 期刊/会议）

| 目标 | 类型 | 页数 | 投稿系统 |
|------|------|------|---------|
| **TPEL** (IEEE Trans. Power Electronics) | 期刊 | ~8-10页 | ScholarOne |
| **TIE** (IEEE Trans. Industrial Electronics) | 期刊 | ~10页 | ScholarOne |
| **TRO** (IEEE Trans. Robotics) | 期刊 | ~12页 | PaperPlaza |
| **ICRA** | 会议 | 8页 | PaperPlaza |
| **IROS** | 会议 | 8页 | PaperPlaza |
| **RA-L** (IEEE Robotics & Automation Letters) | 期刊 | ~8页 | PaperPlaza |
| **APEC/ECCE** | 会议 | 6-8页 | ScholarOne |

**模板**：`IEEEtran.cls` + `IEEEtran.bst`
- 期刊：`\documentclass[journal]{IEEEtran}`
- 会议：`\documentclass[conference]{IEEEtran}`
- 双栏、10pt、摘要≤200词
- **模板位置**：`E:\ai产出文件\论文\templates\IEEE\IEEEtran.cls`

---

## 二、Elsevier 模板体系（elsarticle.cls）

| 目标 | 类型 | 说明 |
|------|------|------|
| **Applied Energy** | 期刊 | 能源领域SCI |
| **Energy** | 期刊 | 能源综合SCI |
| **Energy Conversion and Management** | 期刊 | 能源转换SCI |
| **Automatica** (IFAC) | 期刊 | 控制领域顶刊 |
| **自动化学报** | 期刊 | 中国自动化顶刊 |

**模板**：`elsarticle.cls` + `elsarticle-num.bst`
- 预印：`\documentclass[preprint,12pt]{elsarticle}`
- 需要 Highlights（3-5个要点）
- **模板位置**：`E:\ai产出文件\论文\templates\Elsevier\elsarticle.cls`

---

## 三、Springer Nature 模板体系（sn-jnl.cls）

| 目标 | 类型 | 字数限制 | 说明 |
|------|------|---------|------|
| **Nature** | 期刊 | ~3000词 | Methods放参考文献后 |
| **Nature Communications** | 期刊 | 无严格限制 | 开放获取 |
| **Nature Energy** | 期刊 | 按模板 | 能源子刊 |
| **Nature Machine Intelligence** | 期刊 | 按模板 | AI/机器人子刊 |

**模板**：`sn-jnl.cls` + 9个 `.bst`
- 仅 pdfLaTeX（不支持 XeLaTeX）
- **模板位置**：`E:\ai产出文件\论文\templates\Springer-Nature\sn-jnl.cls`

---

## 四、Science (AAAS)

| 目标 | 类型 | 字数限制 |
|------|------|---------|
| **Science** | 期刊 | 2500词(正文，严格) |
| **Science Advances** | 期刊 | 按模板 |
| **Science Robotics** | 期刊 | 按模板 |

**模板**：标准 `article` + `scicite.sty`
- 仅 pdfLaTeX
- **下载**：https://www.science.org/content/page/preparing-manuscripts-using-latex

---

## 五、ML/AI 会议模板（具身智能论文常用）

| 目标 | 页数 | Overleaf |
|------|------|----------|
| **NeurIPS 2026** | 9页(正文) | https://www.overleaf.com/latex/templates/formatting-instructions-for-neurips-2026/bjdwqfdkyftc |
| **ICML 2026** | 8页(正文) | https://www.overleaf.com/latex/templates/icml2025-template/dhxrkcgkvnkt |
| **ICLR 2026** | 9页(正文) | https://github.com/ICLR/Master-Template |
| **CoRL 2026** | 8页/9页 | https://drive.google.com/drive/folders/13t4JoHU37yWVinyJleCRXg91s7YofmO2 |
| **RSS 2026** | 8页 | https://www.overleaf.com/latex/templates/rss-2026-conference-template/bqmthckndvzf |
| **arXiv** | 无限制 | https://www.overleaf.com/gallery/tagged/arxiv |

---

## 六、选择指南

### 电气/电力电子
- 期刊 → IEEEtran.cls（TPEL/TIE）或 elsarticle.cls（Applied Energy/Energy）
- 会议 → IEEEtran.cls conference（APEC/ECCE）

### 具身智能/机器人
- 期刊 → IEEEtran.cls journal（TRO/RA-L）
- 会议 → IEEEtran.cls conference（ICRA/IROS）或各ML会议模板
- 顶刊 → sn-jnl.cls（Nature Machine Intelligence）或 Science

### 我们的 Pandoc 快速模板（MD→PDF，初稿/作业/内部使用）
- `template-cn-paper.tex` → 国标格式
- `template-ieee.tex` → 双栏 IEEE 风格
- `template-nature.tex` → Nature 风格

**正式投稿请用官方模板 + Overleaf/LaTeX 编译。**

---

## 七、Overleaf 快速入口

| 模板 | 链接 |
|------|------|
| Nature | https://www.overleaf.com/latex/templates/springer-nature-latex-template/gsvvftmrppwq |
| Science | https://www.overleaf.com/latex/templates/latex-template-for-science-family-journals/kjytmmfyxthd |
| Elsevier | https://www.overleaf.com/latex/templates/tagged/elsevier |
| IEEE Journal | https://www.overleaf.com/latex/templates/ieee-journal-paper-template/jbbbdkztwxrd |
| IEEE Conference | https://www.overleaf.com/latex/templates/ieee-conference-template/grfzhhncsfqn |
| NeurIPS | https://www.overleaf.com/latex/templates/formatting-instructions-for-neurips-2026/bjdwqfdkyftc |
| ICML | https://www.overleaf.com/latex/templates/icml2025-template/dhxrkcgkvnkt |
| arXiv | https://www.overleaf.com/gallery/tagged/arxiv |
