# Office工具选型矩阵

| 任务 | Word | Excel | PDF | PPT |
|------|------|-------|-----|-----|
| 创建 | python-docx/docx-js | openpyxl/xlsxwriter | reportlab | python-pptx |
| 读取 | pandoc/python-docx | pandas/openpyxl | pypdf/pdfplumber | python-pptx |
| 编辑 | unpack XML→edit→repack | openpyxl | pypdf PdfWriter | python-pptx |
| 转换 | pandoc(多格式互转) | pandas(to_csv/json等) | markitdown(to md) | python-pptx(to pdf) |
| MD→DOCX+PDF | **Pandoc**(首选)/md-to-docx-pdf.py(后备) | — | Pandoc+XeLaTeX/md-to-docx-pdf.py | — |
| 分析 | pandoc+grep | pandas(describe/corr) | pdfplumber(表格提取) | python-pptx(结构分析) |

## Python库速查
```python
# Word
from docx import Document
doc = Document()
doc.add_heading('Title', level=1)
doc.add_paragraph('Content')
doc.save('output.docx')

# Excel
import openpyxl
wb = openpyxl.Workbook()
ws = wb.active
ws['A1'] = 'Hello'
wb.save('output.xlsx')

# PDF
from pypdf import PdfReader
reader = PdfReader('input.pdf')
text = reader.pages[0].extract_text()

# PPT
from pptx import Presentation
prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[0])
prs.save('output.pptx')
```
