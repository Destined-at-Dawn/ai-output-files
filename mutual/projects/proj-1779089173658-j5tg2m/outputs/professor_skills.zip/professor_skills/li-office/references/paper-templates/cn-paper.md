---
title: "论文标题"
author:
  - 姓名
affiliation: "单位名称，城市 邮编"
email: "email@example.com"
date: "2026年6月"
abstract: |
  **目的：** 简述研究目的。
  **方法：** 简述研究方法。
  **结果：** 简述主要结果。
  **结论：** 简述主要结论。
keywords:
  - 关键词1
  - 关键词2
  - 关键词3
toc: true
bibliography: references.bib
---

# 引言

研究背景和动机。引用文献示例：VSG 控制策略已广泛应用于微电网频率调节 [@zhang2023vsg]。

多项研究验证了该方法的有效性 [see @li2022review; @wang2024fpga]。

## 研究现状

当前领域的研究进展……

# 方法

## 系统模型

系统数学模型描述。建立时间约束：

$$t_{setup} = T_{clk} - t_{co} - t_{logic} - t_{routing} \geq 0 \tag{1}$$

其中 $T_{clk} = 10ns$（100MHz 时钟）。

## 实验设计

### 仿真环境

仿真配置描述。

### 硬件平台

硬件平台描述。

# 结果与讨论

## 仿真结果

| 方案 | 延迟 (ns) | 功耗 (mW) | 面积 (μm²) |
|:-----|:----------|:----------|:-----------|
| 方案A | 5.2 | 12.3 | 2800 |
| 方案B | 3.8 | 15.1 | 3200 |
| 方案C | 4.1 | 11.8 | 2950 |

: 表1 不同方案性能对比

如表1所示，方案C在功耗和面积之间取得了最佳平衡。

## 分析

代码示例：

```verilog
module vsg_control (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] freq_dev,
    output reg  [15:0] power_ref
);
    // VSG 控制算法实现
endmodule
```

# 结论

主要贡献和结论总结。

# 参考文献
