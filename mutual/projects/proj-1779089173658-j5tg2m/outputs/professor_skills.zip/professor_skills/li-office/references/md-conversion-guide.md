# Markdown → DOCX/PDF 转换指南（v2.1）

> **策略：Pandoc 首选 → 纯 Python 后备**

---

## 方案选择决策树

```
需要 MD → DOCX/PDF？
  ├─ 本机有 Pandoc？（pandoc --version）
  │   ├─ 是 → 用 Pandoc（方案 A）
  │   │   ├─ 需要 PDF？
  │   │   │   ├─ 有 TeX 后端？（xelatex/lualatex/tectonic）
  │   │   │   │   ├─ 是 → pandoc --pdf-engine=xelatex（完美中文排版）
  │   │   │   │   └─ 否 → DOCX 用 Pandoc，PDF 降级到方案 B
  │   │   │   └─ 仅需 DOCX → pandoc 直接搞定
  │   │   └─ 需要自定义样式？→ 用 --reference-doc=template.docx
  │   └─ 否 → 用纯 Python 脚本（方案 B）
  └─ 都没有 → 安装 Pandoc（推荐）或 pip install python-docx fpdf2
```

---

## 论文模板（Pandoc + XeLaTeX，学术写作专用）

### 支持的模板
| 模板 | 用途 | 引用格式 | 特点 |
|------|------|---------|------|
| `cn-paper` | 中文论文 | GB/T 7714-2015 | 三号标题、宋体正文、1.5倍行距、页眉页脚 |
| `ieee` | IEEE 会议/期刊 | IEEE 数字引用 | 双栏、10pt、IEEEtran 文档类 |
| `nature` | Nature/英文期刊 | Nature 编号格式 | 双倍行距、Times Roman 字体 |

### 用法
```bash
# 基本用法（默认中文论文模板）
python scripts/convert_paper.py input.md

# 指定模板
python scripts/convert_paper.py input.md --template ieee
python scripts/convert_paper.py input.md --template nature

# 自定义引用文件
python scripts/convert_paper.py input.md --bibliography my-refs.bib --csl my-style.csl
```

### Markdown 论文格式要求
1. **YAML front-matter**：title, author, date, abstract, keywords（必须）
2. **正文**：标准 Markdown，支持数学公式（`$...$`）、代码块、表格
3. **引用**：`[@cite-key]` 语法，对应 references.bib 中的条目
4. **图片**：`![caption](path)` 语法，相对于 .md 文件路径

### 模板示例
参考 `references/paper-templates/cn-paper.md`，包含完整 YAML front-matter 和格式示范。

### 文件结构
```
references/
  ├── template-cn-paper.tex    # 中文论文 LaTeX 模板
  ├── template-ieee.tex        # IEEE LaTeX 模板
  ├── template-nature.tex      # Nature LaTeX 模板
  ├── csl-gbt7714.csl          # GB/T 7714-2015 引用样式
  ├── csl-ieee.csl             # IEEE 引用样式
  ├── csl-nature.csl           # Nature 引用样式
  └── paper-templates/
      ├── cn-paper.md          # 中文论文模板示例
      └── references.bib       # 示例 BibTeX 文件
```

---

## 方案 A：Pandoc 转换（首选）

### 安装
```bash
# Windows
winget install Pandoc

# macOS
brew install pandoc

# Linux
sudo apt install pandoc
```

### 基本用法
```bash
# MD → DOCX（最常用）
pandoc input.md -o output.docx

# MD → DOCX（自定义模板，保留公司样式）
pandoc input.md -o output.docx --reference-doc=company-template.docx

# MD → HTML（微信公众号等场景）
pandoc input.md -o output.html --standalone

# 批量转换
for f in *.md; do pandoc "$f" -o "${f%.md}.docx"; done
```

### MD → PDF（需 TeX 后端）

#### 中文排版：XeLaTeX + ctex
```bash
# 安装 TeX 后端（三选一）：
# 1. TeX Live 完整版（~4GB，功能最全）
#    winget install TeXLive

# 2. Tectonic（~50MB，推荐！自动下载依赖包）
#    winget install tectonic
#    cargo install tectonic

# 3. MiKTeX（Windows 原生，按需下载包）
#    winget install MiKTeX

# 转换命令
pandoc input.md -o output.pdf \
  --pdf-engine=xelatex \
  -V CJKmainfont="SimSun" \
  -V geometry:margin=2.5cm

# 用 Tectonic 作为引擎
pandoc input.md -o output.pdf \
  --pdf-engine=tectonic \
  -V CJKmainfont="SimSun"
```

#### Pandoc 中文 PDF 常用参数
| 参数 | 说明 | 示例 |
|------|------|------|
| `--pdf-engine` | TeX 引擎 | `xelatex` / `tectonic` / `lualatex` |
| `-V CJKmainfont` | 中文主字体 | `"SimSun"` / `"SimHei"` / `"Microsoft YaHei"` |
| `-V geometry:margin` | 页边距 | `2.5cm` / `1in` |
| `-V fontsize` | 正文字号 | `12pt` / `11pt` |
| `--highlight-style` | 代码高亮风格 | `tango` / `kate` / `monochrome` |
| `--toc` | 生成目录 | |
| `-V documentclass` | 文档类 | `ctexart`（中文文章）/ `article` |

#### 高级：自定义 LaTeX 模板
```bash
# 生成默认模板
pandoc -D latex > my-template.tex

# 编辑模板（加入 ctex 等）
# 使用自定义模板
pandoc input.md -o output.pdf --template=my-template.tex --pdf-engine=xelatex
```

### Pandoc 支持的 Markdown 元素（远超手写解析器）
| 元素 | DOCX | PDF | 手写脚本 |
|------|------|-----|---------|
| 标题 h1-h6 | ✅ | ✅ | ⚠️ 仅 h1-h4 |
| 表格 | ✅ | ✅ | ✅ |
| 代码块（语法高亮）| ✅ | ✅ | ⚠️ 无语法高亮 |
| 图片 | ✅ | ✅ | ❌ |
| 嵌套列表 | ✅ | ✅ | ❌ |
| 脚注 | ✅ | ✅ | ❌ |
| 数学公式 (LaTeX) | ✅ | ✅ | ❌ |
| 引用块 | ✅ | ✅ | ❌ |
| 链接 | ✅ | ✅ | ❌ |
| YAML front matter | ✅ | ✅ | ❌ |

---

## 方案 B：纯 Python 后备（零依赖）

### 脚本位置
`references/md-to-docx-pdf.py`

### 依赖
```bash
pip install python-docx fpdf2
```

### 使用方式
```python
import sys
sys.path.insert(0, '/path/to/li-office/references')
from md_to_docx_pdf import parse_markdown, create_docx, create_pdf

with open('input.md', 'r', encoding='utf-8') as f:
    elements = parse_markdown(f.read())

create_docx(elements, 'output.docx', title='文档标题')
create_pdf(elements, 'output.pdf', title='文档标题')
```

### 适用场景
- Pandoc 不可用的环境
- 仅需简单文档转换（无图片/公式/脚注）
- 不想安装 TeX 后端时的 PDF 快速生成

### 局限性
- 不支持图片、嵌套列表、脚注、数学公式、链接
- PDF 表格单元格截断 30 字符
- 中文字体路径硬编码为 Windows

---

## Tectonic 轻量安装指南（替代 TeX Live）

> Tectonic = ~50MB 自包含 TeX 编译器，自动下载所需宏包，无需安装完整 TeX Live（4GB+）

```bash
# Windows (winget)
winget install tectonic

# Windows (cargo)
cargo install tectonic

# macOS
brew install tectonic

# Linux
curl --proto '=https' --tlsv1.2 -fsSL https://drop-sh.fullyjustified.net | sh

# 验证
tectonic --version

# 使用（Pandoc 后端）
pandoc input.md -o output.pdf --pdf-engine=tectonic -V CJKmainfont="SimSun"

# 直接编译 .tex
tectonic -X compile input.tex
```

**Tectonic vs TeX Live**：
| 维度 | Tectonic | TeX Live |
|------|----------|----------|
| 安装大小 | ~50MB | ~4GB |
| 安装时间 | 秒级 | 30分钟+ |
| 包管理 | 自动下载 | 手动更新 |
| 中文支持 | ✅ 需配置字体 | ✅ 完整 |
| 适合场景 | 个人/小团队 | 学术机构 |

---

## 中文字体速查（Windows）
| 字体名 | 文件名 | 用途 |
|--------|--------|------|
| SimSun（宋体）| simsun.ttc | 正文印刷体 |
| SimHei（黑体）| simhei.ttf | 标题/强调 |
| Microsoft YaHei（微软雅黑）| msyh.ttc | 屏幕显示/现代风格 |
| KaiTi（楷体）| simkai.ttf | 引用/批注 |
| FangSong（仿宋）| simfs.ttf | 公文 |

字体路径：`C:/Windows/Fonts/`
