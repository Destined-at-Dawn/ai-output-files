# Office处理常用Python库

## 文档处理
| 库 | 用途 | 安装 |
|---|---|---|
| python-docx | Word读写 | pip install python-docx |
| openpyxl | Excel读写 | pip install openpyxl |
| python-pptx | PPT读写 | pip install python-pptx |
| pypdf | PDF读写/合并/拆分 | pip install pypdf |
| pdfplumber | PDF表格/文本提取 | pip install pdfplumber |
| reportlab | PDF创建 | pip install reportlab |
| markitdown | Office→Markdown | pip install markitdown |
| fpdf2 | PDF创建(含中文) | pip install fpdf2 |

## 数据处理
| 库 | 用途 | 安装 |
|---|---|---|
| pandas | 数据分析/清洗 | pip install pandas |
| xlsxwriter | Excel高级格式 | pip install XlsxWriter |
| tabulate | 表格格式化输出 | pip install tabulate |

## 转换工具
| 工具 | 用途 | 安装 |
|---|---|---|
| pandoc | **MD→DOCX/PDF 首选**，多格式文档转换 | brew/apt install pandoc / winget install pandoc |
| Tectonic | 轻量 TeX 编译器（~50MB，替代 TeX Live 4GB） | cargo install tectonic / winget install tectonic |
| LibreOffice | Office格式转换 | soffice --headless --convert-to |
| XeLaTeX | TeX PDF 引擎（中文用 ctex 宏包） | TeX Live / MiKTeX 完整安装 (~4GB) |
