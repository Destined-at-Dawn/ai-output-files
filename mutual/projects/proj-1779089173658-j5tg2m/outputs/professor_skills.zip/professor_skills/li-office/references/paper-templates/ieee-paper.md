---
title: "Paper Title"
author:
  - name: "First Author"
    affiliation: "Department, University, City, Country"
    email: "first@university.edu"
  - name: "Second Author"
    affiliation: "Department, University, City, Country"
    email: "second@university.edu"
date: "June 2026"
abstract: |
  This paper presents... The results show... We conclude that...
keywords:
  - keyword1
  - keyword2
  - keyword3
bibliography: references.bib
---

# Introduction

Research background and motivation. The virtual synchronous generator (VSG) control strategy has been widely adopted in microgrid frequency regulation [@zhang2023vsg].

Multiple studies have validated the effectiveness of this approach [see @li2022review; @wang2024fpga].

## Related Work

Current research progress...

# Methodology

## System Model

The mathematical model is described by:

$$t_{setup} = T_{clk} - t_{co} - t_{logic} - t_{routing} \geq 0 \tag{1}$$

where $T_{clk} = 10ns$ (100 MHz clock).

## Experimental Setup

### Simulation Environment

Simulation configuration...

### Hardware Platform

Hardware description...

# Results and Discussion

## Simulation Results

| Scheme | Delay (ns) | Power (mW) | Area (μm²) |
|:-------|:-----------|:-----------|:-----------|
| A | 5.2 | 12.3 | 2800 |
| B | 3.8 | 15.1 | 3200 |
| C | 4.1 | 11.8 | 2950 |

: Table I: Performance comparison of different schemes {#tbl:comparison}

As shown in @tbl:comparison, Scheme C achieves the best trade-off between power and area.

## Analysis

Code example:

```verilog
module vsg_control (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] freq_dev,
    output reg  [15:0] power_ref
);
    // VSG control algorithm implementation
endmodule
```

# Conclusion

Main contributions and conclusions.

# References
