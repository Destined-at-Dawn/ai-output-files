# 论文排版模板库

## 可用模板

| 模板 | 文件 | 适用场景 | 引用格式 |
|------|------|---------|---------|
| **中文论文** | `cn-paper.md` | 国内期刊/学位论文/实验报告 | GB/T 7714-2015 顺序编码 |
| **IEEE 论文** | `ieee-paper.md` | IEEE 期刊/会议 | IEEE 数字引用 [1] |
| **Nature 论文** | `nature-paper.md` | Nature/Science/通用英文期刊 | Nature 上标数字¹ |

## 使用方式

### 1. 复制模板
```bash
cp references/paper-templates/cn-paper.md 我的论文.md
```

### 2. 填写 YAML front matter
编辑 .md 文件顶部的 `---` 区域（标题、作者、摘要等）

### 3. 一键转换
```bash
# 中文论文 → PDF
pandoc 我的论文.md -o 我的论文.pdf \
  --template=references/template-cn-paper.tex \
  --pdf-engine=xelatex \
  --csl=references/csl-gbt7714.csl \
  --bibliography=references.bib

# IEEE 论文 → PDF
pandoc 我的论文.md -o 我的论文.pdf \
  --template=references/template-ieee.tex \
  --pdf-engine=xelatex \
  --csl=references/csl-ieee.csl \
  --bibliography=references.bib

# Nature 论文 → PDF
pandoc 我的论文.md -o 我的论文.pdf \
  --template=references/template-nature.tex \
  --pdf-engine=xelatex \
  --csl=references/csl-nature.csl \
  --bibliography=references.bib
```

## 引用写法（Markdown 内）

Pandoc 使用 `@citation_key` 语法引用 .bib 文件中的文献：

```markdown
研究表明 VSG 控制策略能有效改善频率响应 [@zhang2023vsg]。
多项对比实验验证了该方法的优越性 [see @li2022review; @wang2024fpga]。
如 @chen2021power 所述，虚拟同步机技术已广泛应用于微电网。
```

转换后自动变成：
- 中文：[1] / [1,2] / 文献[1]指出
- IEEE：[1] / [1], [2] / Ref. [1]
- Nature：上标数字 ¹ / ¹˒²
