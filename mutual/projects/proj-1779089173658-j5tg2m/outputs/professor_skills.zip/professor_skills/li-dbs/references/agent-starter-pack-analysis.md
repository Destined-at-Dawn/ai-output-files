# Agent Starter Pack 分析 (3K★)

## 核心机制
- 三阶段迁移：Inventory → Classify → Migrate
- 工作区模板：预配置 CLAUDE.md + .claude/rules/ + skills/
- 自动检测：扫描源目录，识别可迁移组件

## 关键设计
1. 每个工作区有独立的 CLAUDE.md（不是全局共享）
2. 路由表是 SSOT（Single Source of Truth）
3. 第三方仓库标记只读

## 我们吸收了什么
- 四维分类法（必须迁移/必须更新/可以跳过/必须删除）
- 三层沉淀（配置/数据/代码）
- 差异≠错误铁律（来自 SOP-08）
