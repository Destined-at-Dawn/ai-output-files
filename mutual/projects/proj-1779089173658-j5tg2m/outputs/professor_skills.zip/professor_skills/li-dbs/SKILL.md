---
name: li-dbs
version: "1.0"
description: li系列 · 深度商业战略分析（行业/竞争/商业模式）
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/vendor-code-porting.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[迁移检查] -> **必须** `Read references/migration-checklist.md`
- 场景[Agent分析] -> **必须** `Read references/agent-starter-pack-analysis.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/vendor-code-porting.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-wechat — 微信公众号文章处理

## 理论锚点
| ID | 理论 | 来源 | 应用 |
|----|------|------|------|
| T1 | 信息提取 | 008-深度工作 | 只提取有价值内容 |
| T2 | 费曼检验 | 002-学习之道 | 用自己的话复述 |
| T3 | 认知负荷 | 002-学习之道 | 一次只处理一个核心观点 |

## Phase 0 识别
| 信号 | 行动 |
|------|------|
| 公众号链接（mp.weixin.qq.com） | WebFetch 提取 → Phase 1 |
| "帮我看看这篇文章" | 确认是公众号还是其他来源 |
| "公众号内容分析" | 提取 → li-analyze 道法术器 |

## Phase 1 提取
1. WebFetch 抓取链接
2. 清理广告/推广/评论区
3. 提取：标题、作者、核心论点、数据、来源

## Phase 2 处理
- **分析模式**：→ li-analyze（道法术器 + 百大认知）
- **提取模式**：→ 只提取关键信息 → li-memory 沉淀
- **对比模式**：→ 与已有知识对比 → 标注新知/重复/矛盾

## 案例库
- **案例1**：FPGA 技术文章 → 道法术器分析 + li-hardware 知识对比
- **案例2**：AI 行业周报 → 筛选相关条目 → 3 条洞察
- **案例3**：控制理论文章 → 费曼检验 → 学习笔记



## Theory Anchors (T1-T12)
| ID | Theory | Application |
|---|---|---|
| T1 | Defamiliarization | Re-frame familiar problems |
| T4 | Rule of Three | Three examples before generalizing |
| T5 | Tacit Knowledge | Make implicit expertise explicit |
| T10 | Double-loop Learning | Question assumptions, not just actions |
| T12 | Skill Acquisition | Dreyfus model: novice to expert |
## 反模式
- ❌ 全文复制不清理 → 广告和推广混入
- ❌ 不标注来源 → 后续无法追溯
- ❌ 一次处理太多文章 → 认知超载
- ❌ 不做费曼检验 → 以为看懂了其实没有
- ❌ 不和已有知识对比 → 重复学习已知内容

## 联动技能
- **li-analyze**：道法术器深度分析
- **li-memory**：事实提取和记忆沉淀
- **li-research**：扩展研究（文章提到的引用/论文）
- **li-xhs**：公众号→小红书内容改编
- **li-transcript**：如果是公众号音频/视频的逐字稿


## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## Anti-Patterns

| # | Anti-Pattern | Consequence | Fix |
|---|---|---|---|
| AP-1 | 迁移不备份 | 数据丢失无法恢复 | Phase 0 强制 git checkpoint |
| AP-2 | 路由不同步 | 新工作区无法触发 skill | Phase 3 全量同步验证 |
| AP-3 | 忽略编码差异 | GBK/UTF-8 路径损坏 | Python 处理中文路径 |
| AP-4 | SOP 不迁移 | 工作流断裂 | Phase 2 列出所有 SOP 并验证 |

## Linked Skills

- li-sync: Phase 3 路由同步的执行者
- li-manage: 迁移后的记忆和知识管理
- li-infra: CLAUDE.md 和 memory 结构管理
- li-workspace: 重构/scaffold 与迁移互补

## Case Studies

### CS-1: 从日常学习区迁移到竞赛区
- 场景: FPGA 竞赛项目从日常学习区独立出来
- 结果: 竞赛区独立运行，触发词自动命中 li-hardware

### CS-2: 跨机器迁移 li- 系列 skill
- 场景: 在新电脑重建牛马 AI 生态
- 结果: 30 分钟完成 40+ skill 的环境重建

### CS-3: 项目归档迁移
- 场景: 完成的项目从活跃区移到归档区
- 结果: 归档可随时恢复，不占活跃工作区空间

## 禁忌

- **禁止**：`DELETE` 不带 `WHERE`——绝对不允许
- **禁止**：在生产环境直接执行 `DROP TABLE`——必须先备份
- **禁止**：不设索引就做大表 `JOIN`——性能灾难
