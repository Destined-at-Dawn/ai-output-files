---
name: li-improve
slug: li-improve
version: 4.0.0
description: >
  li- 系列进化引擎。对话结束前强制自审 + 教训五步闭环 + 道法术器深度门禁 + 引用均衡 +
  系统健康自举（脚本驱动） + 晋升管线 + 技能提取 + Hook 驱动激活 + 递归度追踪。
  Progressive Disclosure：主文件只放 Phase 0/0.5/1/1.5 核心流程，其余按需加载 references/。
  来源：li-improve v3.5 全量升级 + li-improve 机制吸收 + peterskoett(641★)/HyperAgents(2.6K★)。
  触发词：自我改进/自我优化/学习记录/错误记录/经验总结/持续改进/从错误中学习/教训/踩坑/
  做得好/做得差/经验沉淀/教训记录/复盘/反思/进化/li-improve/self-evolve/自审/
  系统健康/健康检查/晋升/升级为铁律/技能提取/复盘总结/经验归档。
  Use when: (1) user corrects you; (2) command fails; (3) conversation ends (auto-audit);
  (4) knowledge outdated; (5) better approach found; (6) lessons/learning keywords;
  (7) system health check; (8) pattern ≥2 times; (9) hook injects pending reminder.
---


> **必读（执行前必须 Read）**：`references/skill-linkage.md` — li- 系列联动规则。不读 = 跳过联动 = 产出不完整。500 万 token 上下文中本文件可能被压缩，但 references/ 不会被压缩。


## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **执行约束（非建议）。** **必读（必须 Read）**: `references/theory-table.md` | `references/phase-4-promotion.md` | `references/phase-5-skill-extraction.md` | `references/health-check-template.md` | `references/hooks-setup.md` | `references/metacognitive-layer.md` | `references/efficiency-modes.md` | `references/phase-3-tiered-memory.md` | `references/recurrence-tracking.md` | `references/phase-2-best-practices.md` | `references/openclaw-integration.md` | `references/external-research.md` | `references/case-studies.md` | `references/conditional-next-steps.md` | `references/anti-patterns.md` | `references/examples.md`。无 Source = 禁止声称。跳过 = 违反法则8。Phase 执行前确认已 Read 所有 references/ 必读文件，未读 = 禁止继续。
> **按需**: `references/phase-4-promotion.md` | `references/phase-5-skill-extraction.md` | `references/health-check-template.md` | `references/hooks-setup.md` | `references/metacognitive-layer.md` | `references/efficiency-modes.md` | `references/phase-3-tiered-memory.md` | `references/recurrence-tracking.md` | `references/phase-2-best-practices.md` | `references/openclaw-integration.md` | `references/external-research.md` | `references/case-studies.md` | `references/conditional-next-steps.md` | `references/anti-patterns.md` | `references/examples.md`

# li-improve v4.0 — 进化引擎

> 「你并没有上升到你的目标水平，你下降到了你的系统水平。」——《原子习惯》001
>
> **Progressive Disclosure**：本文件只含核心 Phase（0/0.5/1/1.5）。
> 详细内容在 `references/` 按需加载，避免超出上下文窗口。

---

## 设计哲学（7 条）

| # | 哲学 | 理论 |
|---|------|------|
| P1 | **教训必须有载体** — 口头 = 没记录 | 间隔效应 007 |
| P2 | **对话结束前强制自审** — 不是"想起来才做" | 双系统理论 003 |
| P3 | **双写不验证 = 未完成** — 根级+模块级同步 | 刻意练习 004 |
| P4 | **深度决定复用** — 道法术器缺一不可 | 知识诅咒 021 |
| P5 | **引用必须轮换** — 30 天新面孔 ≥1/3 | 确认偏误 003 |
| P6 | **触发词从数据长出来** — 不是人工预设 | Dreyfus 模型 035 |
| P7 | **只升级不删减** — 有疑问默认记为教训 | 反脆弱 046 |

> 详细理论表（12 项认知科学锚点）→ `references/theory-table.md`

---

## 理论锚点

| # | 理论 | 应用 | 来源 |
|---|------|------|------|
| T1 | 双系统理论 | 快速路由 vs 深度分析 | 《思考，快与慢》 |
| T2 | 认知负荷理论 | 主文件<=300行 | 《认知负荷理论》 |
| T3 | WYSIATI | AI只看到用户说的 | 《思考，快与慢》 |
| T4 | 锚定效应 | 首次结果影响后续判断 | 《思考，快与慢》 |
| T5 | 奥卡姆剃刀 | 最简方案优先 | 《精要主义》 |
| T6 | 刻意练习 | 迭代必须有实质差异 | 《刻意练习》 |
| T7 | 反脆弱 | 负结果归档 | 《反脆弱》 |
| T8 | 间隔效应 | 定期复习有效 | 《认知天性》 |
| T9 | 损失厌恶 | 先备份再操作 | 《思考，快与慢》 |
| T10 | 第一性原理 | 先问为什么 | 《第一性原理》 |
| T11 | 费曼检验 | 简单话解释 | 《费曼学习法》 |
| T12 | 预验尸 | 假设已失败倒推 | 《超越智商》 |

## Phase 0：对话结束前强制自审

> 每次对话结束前必执行。理论：双系统理论——自审 = 强制系统 2 介入。

### 自审检查清单（8 项）

| # | 检查项 | 信号 | 处理 |
|---|--------|------|------|
| 1 | 用户纠正（"不对""不要""改成"）？ | 有/无 | 有 → Phase 1 |
| 2 | 方案失败/被否定/需重做？ | 有/无 | 有 → 教训+负结果日志 |
| 3 | 踩坑/报错/弯路？ | 有/无 | 有 → 记教训 |
| 4 | 做得好/用户表扬？ | 有/无 | 有 → `references/phase-2-best-practices.md`，≥7分入库 |
| 5 | 同类教训 ≥2 次？ | 有/无 | 有 → `references/phase-4-promotion.md` |
| 6 | 涉及子模块？ | 有/无 | 有 → 双写到模块级经验库 |
| 7 | 创建了新文件？ | 有/无 | 有 → file-placement-precheck |
| 8 | skill 调用未记录到 skill-usage-log？ | 有/无 | 有 → 补记（联动 li-manage） |

**全部"无"→** `📋 经验自审：本轮无经验沉淀项`
**任一"有"→ 进入对应 Phase。**

### 遗漏检测

以下任一条 = 自审被跳过：
- [ ] 写了 memory 但没输出自审清单
- [ ] 写完 memory 直接结束
- [ ] 用户问"为什么没更新进化文件"

**检测到 → 立即停下，先补 Phase 0 再继续。**

---

## Phase 0.5：系统健康自举检查（脚本驱动）

> 硬约束本身也需要被监督——谁监督监督者？用脚本，不用人。
> 理论：元认知监控 049。

### 触发条件

| 条件 | 频率 |
|------|------|
| 每 7 天 | 完整健康检查 |
| INDEX 缺口 >5% | 立即执行 |
| 双写同步率 <95% | 立即执行 |
| F1 审计同一项连续 2 次 | 专项检查 |

### 检查项（5 项）

| # | 检查项 | 工具 | 正常值 | 异常动作 |
|---|--------|------|--------|---------|
| H1 | C 级预防占比 | `scan-lesson-patterns.py` | <15% | >30% → 逐条补系统加固 |
| H2 | INDEX 覆盖率 | `check-index-gaps.py` | 100% | <95% → `rebuild-index.py` |
| H3 | 双写同步率 | `dual-write-verify.py` | 100% | <100% → `--fix` |
| H4 | 未执行审计项 | `scan-lesson-patterns.py --promotions` | 0 | >0 → 逐项补修正 |
| H5 | 升级建议 | `scan-lesson-patterns.py --promotions` | 无 critical | 有 critical → Phase 4 |

### 健康分与行动

| 分 | 状态 | 行动 |
|----|------|------|
| 90-100 | OK | 摘要即可 |
| 60-79 | WARNING | Top 3 修复项 |
| 40-59 | CRITICAL | 停止新任务，全部修复 |
| <40 | FAILURE | 用户介入 |

**自举失败退出**：健康分 <60 且连续 2 次未改善 → 停止新任务（结构墙）。

> 输出格式模板 → `references/health-check-template.md`

---

## Phase 1：教训记录流程（五步闭环）

> 理论：刻意练习四要素 004 + 间隔效应 007。
> 少任何一步 = 流程未完成。

### Step 1：写入结构化日志
- **路径**：`.learnings/LEARNINGS.md`
- **格式**：`[LRN-YYYYMMDD-XXX]` 编号
- **内容**：Summary + Details + Suggested Action + Metadata（含 pattern_key + recurrence_count）
- **验证**：Read 确认已落盘

### Step 2：写入当日记忆
- **路径**：`memory/{YYYY-MM-DD}.md`
- **内容**：教训摘要 + 根因 + 正确做法

### Step 3：写入自我进化系统 + 负结果日志
- **自我进化**：`self-evolution/做得差的避免/`
- **负结果日志**：项目目录 `negative-results.md`
- **索引**：`self-evolution/lessons.md`

### Step 4：教训回写到 skill/SOP/rules（强制执行清单）

> **教训只记不改 = 白记。** 此步骤强制执行，不可跳过。
> **2026-06-13 重写**：原版只有"识别影响范围"等抽象指令，AI不知道具体改什么。现在给出具体映射表。

**触发**：Step 1-3 完成后自动触发。

#### 4a. 教训分类 → 回写目标映射表

| 教训类型 | 必须回写的目标 | 回写方式 |
|----------|---------------|---------|
| **用户纠正 AI 行为** | 对应 skill 的"反模式"表 + 本 skill 的"变更记录" | Edit 追加行 |
| **路由/调用失败** | `skill-routing-table.json` + `skill-auto-activation.md` 失败模式表 | Edit 追加行 |
| **文件操作事故** | `.claude/rules/` 对应规则（如 no-blind-overwrite.md） | Edit 追加铁律 |
| **Skill 创建/拆分问题** | `li-skillfusion/lifecycle-log.md` + 对应 SKILL.md | Edit 追加 |
| **数据集/训练教训** | `competition-yolo/SKILL.md` 避坑指南 | Edit 追加条目 |
| **记忆/归档事故** | `memory-candidate-protocol.md` 或 `lesson-auto-update.md` | Edit 追加铁律 |
| **架构/规范教训** | `CLAUDE.md` 对应铁律（F编号） | Edit 追加 |
| **编码/中文路径** | `chinese-path-safety.md` | Edit 追加禁止模式 |
| **Goal 模式问题** | `goal-mode-anti-repeat.md` | Edit 追加铁律 |
| **竞赛项目特有** | 项目主文件夹 `skills/competition-local.md` | Edit 追加复盘 |

#### 4b. 执行检查清单（每条教训必须过完）

```
□ Step 4.1: 教训归类（上表哪一行？）
□ Step 4.2: 列出所有需要修改的文件路径（≥1个）
□ Step 4.3: 归档原文件（调用 auto_archive.py 或复制到归档目录）
□ Step 4.4: 用 Edit 逐个修改（不用 Write 覆盖）
□ Step 4.5: 每个修改后 Read 验证
□ Step 4.6: 输出修改总结（修改了哪些文件、改了什么）
```

**不可跳过。没有"先记下来后面再改"的例外。**

#### 4c. 回写质量门禁

| 检查项 | 通过标准 |
|--------|---------|
| 教训已写入对应 skill 的迭代日志/变更记录？ | Read 验证新增行存在 |
| 教训已写入对应 rules 的铁律/禁止模式？ | Read 验证新增段落存在 |
| 教训已写入 self-evolution/lessons.md？ | Read 验证条目存在 |
| 47+ 条教训中回写率 > 80%？ | 定期审计 |

> 强制规则：`.claude/rules/lesson-auto-update.md`

### Step 5：双写验证
- 涉及子模块 → 写入模块级 `经验库/做得差的/`
- **验证**：`python scripts/dual-write-verify.py`
- 不同步 → `--fix`

---

## Phase 1.5：教训深度化门禁（道法术器 + 引用均衡）

> 理论：知识诅咒 021 + 确认偏误 003 + 刻意练习 004。
> "记下来"≠"学会了"。没有道法术器 = 死路重踩只是时间问题。

### 触发条件

Phase 1 Step 3 完成后自动触发。

> 详见 `references/theory-table.md` § 教训深度化门禁（D1-D5 五维检查 + 引用均衡）

---

## Phase 2-5（按需加载 → references/）

| Phase | 触发条件 | 加载文件 |
|-------|---------|---------|
| Phase 2 成功实践 | Phase 0 #4 "做得好" | `references/phase-2-best-practices.md` |
| Phase 3 分层记忆 | 周期性 | `references/phase-3-tiered-memory.md` |
| Phase 4 晋升管线 | 同类教训 ≥2 次 | `references/phase-4-promotion.md` |
| Phase 5 技能提取 | 2+ 类似条目 | `references/phase-5-skill-extraction.md` |

---

## li- 系列联动（7 个）

| 联动 Skill | 触发条件 | 联动方式 |
|------------|---------|---------|
| **li-devil** | 重大决策教训 | 升级铁律前先泼冷水 |
| **li-manage** | 教训涉及技能管理 | Flow A 文档体检 |
| **li-skillcreate** | Phase 4 ≥5 次 → 新 Skill | 走六阶段创建 |
| **li-research** | 教训涉及新领域 | 先调研再写教训 |
| **li-sync** | 跨区铁律 | 同步到全部工作区 |
| **li-transcript** | 教训来自对话 | 逐字稿提取教训 |
| **li-mindcoach** | 心理障碍/焦虑 | 心力教练辅助 |

---

## Hook 驱动激活（从 peterskoett 641★ 学习）

> **可靠性层级**：L1 Hook 脚本 > L2 CLAUDE.md 规则 > L3 AI 自发想起。
> 能用 L1 就不用 L3。

| Hook | 触发 | 脚本 | 行为 |
|------|------|------|------|
| UserPromptSubmit | 每次提交前 | `scripts/activator.sh` | pending 教训提醒 |
| PostToolUse(Bash) | 每次命令后 | `scripts/error-detector.sh` | 非零退出码 → 自动写 `.learnings/ERRORS.md` |

> Hook 配置指南 → `references/hooks-setup.md`
> 递归度追踪 + Pattern-Key → `references/recurrence-tracking.md`
> 元认知自修改 → `references/metacognitive-layer.md`
> 外部研究库 → `references/external-research.md`
> 案例库 → `references/case-studies.md`
> 反模式 → `references/anti-patterns.md`
> 条件式下一步 → `references/conditional-next-steps.md`

---

## Quick Reference

| 场景 | 操作 |
|------|------|
| 用户纠正我 | Phase 1 → Phase 1.5 |
| 操作失败 | `.learnings/ERRORS.md` + 负结果日志 |
| 对话结束 | Phase 0 自审 |
| 每 7 天/退化 | Phase 0.5 健康检查 |
| 好的做法 | Phase 2，≥7 分入库 |
| 同类 ≥2 次 | Phase 4 晋升管线 |
| 提取 Skill | Phase 5 + li-skillcreate |
| 跨区铁律 | li-sync |
| 涉及心理 | li-mindcoach |

---

## 安全边界

参见 `boundaries.md`——永不存储凭证、健康数据、第三方信息。

---

## 变更记录

| 日期 | 版本 | 变更 |
|------|------|------|
| 2026-05-18 | li-improve v2.1 | 自动教训提取 + conversation-to-knowledge 联动 |
| 2026-06-07 | li-improve v3.5 | Phase 1.5 引用均衡 + Phase 0.5 健康自举 + Progressive Disclosure |
| 2026-06-08 | li-improve v4.0 | **全面升级**：(1) 品牌升级为 li- 系列统一命名 (2) 理论表/案例库/反模式/条件下一步拆到 references/（保持主文件精简）(3) 吸收 li-improve 的 Hook 驱动+递归度追踪+自动提取+元认知层（4 路 references/）(4) 联动 7 个 li-skill (5) 外部研究库 5 个项目 (6) 主文件 ≤300 行，参考 Progressive Disclosure 架构 |
| 2026-06-13 | li-improve v4.1 | **Step 4 重写**：审计发现 47+ 条教训回写率 <10%，根因是原 Step 4 只有"识别影响范围"等抽象指令。新增：(1) 教训分类→回写目标映射表（10 种教训类型对应具体文件）(2) 执行检查清单（6 步强制）(3) 回写质量门禁（4 项检查）。来源：用户纠正"自进化功能形同虚设" |

## 案例库

### 案例 1: self-improving → li-improve 进化
- **场景**: 原始 self-improving agent 286 行功能齐全，但不符合 li- 系列标准
- **做法**: 升级为 Progressive Disclosure（主文件 286→251 行）+ 吸收 peterskoett(641★) Hook 驱动 + HyperAgents(2.6K★) 元认知层
- **结果**: 功能完整性保持 95%，主文件更精简
- **教训**: 升级 ≠ 重写，保留好架构，补新机制
- **来源**: mutual 工作区，2026-06

### 案例1：典型使用场景
li-improve在以下场景中最常用：用户发出与"improve"相关的指令时自动触发。
典型流程：Phase 0需求消解 → Phase 1核心执行 → Phase 2质量验证 → Phase 3记忆沉淀。

### 案例2：跨skill联动场景
li-improve经常与其他li-skill串联使用——详见"联动技能"章节。
联动时由上游skill决定何时调用本skill，本skill专注自己的核心能力。

### 案例3：失败恢复场景
当li-improve执行失败时：检查是否缺少输入（Phase 0消解不充分）、是否触发词误匹配（应触发其他skill）、是否references/文件缺失。
失败记录写入golden_rules.md防止重复。

## 反模式

| 反模式 | 后果 | 正确做法 |
|--------|------|---------|
| 跳过Phase 0直接执行 | 输出不符合用户意图 | Phase 0消解不可跳过 |
| 不读references/直接写 | 输出质量低、缺少理论支撑 | Progressive Disclosure——按需加载reference |
| 输出后不记录反馈 | 同样的错误重复犯 | 任何用户纠正写入golden_rules.md |
| 和其他li-skill功能重叠 | 用户困惑该触发哪个 | 检查联动技能章节确认职责边界 |
| 不更新skill-routing-table.json | skill文件存在但不被触发 | 创建/修改后立即更新路由+同步工作区 |

> See references/ for conditional-next-steps, external-research, and notes.

## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
## 联动技能 → 详见 `references/linked-skills.md`

## 禁忌

- **禁止**：把失败经验当成功案例记录——正负结果同等重要
- **禁止**：修改 golden_rules 不记录原因——每条规则必须有来源
- **禁止**：改进后不回测——改了技能必须用真实任务验证
