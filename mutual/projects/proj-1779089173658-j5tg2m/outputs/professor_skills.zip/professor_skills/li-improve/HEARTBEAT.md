## Self-Improving Check

- Read `./skills/li-improve/heartbeat-rules.md`
- Use `~/li-improve/heartbeat-state.md` for last-run markers and action notes
- If no file inside `~/li-improve/` changed since the last reviewed change, return `HEARTBEAT_OK`
