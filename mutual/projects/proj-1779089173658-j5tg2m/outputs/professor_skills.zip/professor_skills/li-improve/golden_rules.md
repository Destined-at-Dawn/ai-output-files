# li-improve 黄金规则

## GR-001：教训必须有触发条件
每条教训必须写明什么情况下触发。没有触发条件的教训 = AI 永远不会主动想起。
- 来源：peterskoett Recurrence-Count 机制
- 反模式：教训文件里写了一堆但 AI 从不回看

## GR-002：递归度追踪自动计
Recurrence-Count >=3 + 跨 >=2 任务 + 30 天内 → 自动晋升为规则。
- 来源：peterskoett self-improving-agent（641★）
- 反模式：AI 说这是第 3 次了但其实数错了

## GR-003：Hook 驱动不靠记忆
自审清单靠 AI 想起来要做 → 经常被跳过。用 activator.sh 自动注入提醒。
- 来源：peterskoett activator.sh
- 反模式：Phase 0 自审被这次简单不用检查跳过

## GR-004：改进流程本身也要被改
每月 1 次检查：Phase 通过率 / Hook 有效性 / 引用均衡。
- 来源：HyperAgents 元认知自修改（2.6K★）
- 反模式：规则写了半年没人 review，已经和实际脱节

## GR-005：Caveman 模式降成本
非关键上下文用极简模式输出（75% token 压缩）。
- 来源：mattpocock/skills caveman
- 反模式：每个输出都写完整段落，token 成本失控
