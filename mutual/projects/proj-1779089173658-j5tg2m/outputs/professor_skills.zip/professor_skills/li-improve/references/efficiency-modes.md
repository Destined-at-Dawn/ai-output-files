# 效率模式（从 mattpocock/skills 吸收）

## 模式 1: Caveman（极简沟通）

> 来源: mattpocock/skills caveman (200+ star)
> 目标: 75% token 压缩，技术精度不丢

### 触发
用户说"极简模式"/"caveman"/"少废话"/"压缩输出"/"精简回答"。

### 规则
- 丢弃: 冠词 (a/an/the)、填充词 (just/really/basically/actually/simply)、客套 (sure/certainly/of course)
- 保留: 所有技术术语精确不变、代码块不变、错误消息原文引用
- 简写: 常见术语 (DB/auth/config/req/res/fn/impl)
- 格式: `[thing] [action] [reason]. [next step].`

### 示例

**普通**: "Sure! I'd be happy to help you with that. The issue you're experiencing is likely caused by..."
**Caveman**: "Bug in auth middleware. Token expiry check use `<` not `<=`. Fix:"

**普通**: "Let me explain database connection pooling in detail..."
**Caveman**: "Pool = reuse DB conn. Skip handshake -> fast under load."

### 安全例外
以下场景临时退出极简模式：
- 安全警告（不可逆操作确认）
- 多步骤序列（片段顺序可能误读）
- 用户要求澄清或重复提问
- 安全相关内容说完后恢复极简模式

### 持久性
一旦激活，每条回复都用极简模式。直到用户说"正常模式"/"stop caveman"。

---

## 模式 2: Handoff（交接文档）

> 来源: mattpocock/skills handoff (200+ star)
> 目标: 对话 -> 结构化交接文档，agent 连续性

### 触发
用户说"交接"/"handoff"/"换个会话继续"/"保存进度"/"下次接着做"。

### 流程
1. 生成交接文档，包含：
   - **当前状态**: 做到了哪，下一步是什么
   - **关键决策**: 本次对话做了什么选择，为什么
   - **修改的文件**: 路径列表 + 每个改了什么
   - **待办事项**: 具体到操作级别的 TODO
   - **建议技能**: 下个会话应该调用哪些 li- skill
   - **约束**: 不能做什么、已排除的方案

2. 保存到工作区 `outputs/handoff-{date}-{topic}.md`
3. 不复制已在其他产物中的内容（引用路径即可）
4. 脱敏：删除 API key、密码、个人信息

### 交接文档模板

```markdown
# Handoff: {topic}

## 状态
- 已完成: [列表]
- 进行中: [当前任务]
- 下一步: [具体操作]

## 关键决策
- 决策 1: [选择] because [理由]
- 决策 2: [选择] because [理由]

## 修改的文件
- path/to/file1: [改了什么]
- path/to/file2: [改了什么]

## 待办
- [ ] 具体操作 1
- [ ] 具体操作 2

## 建议技能
- li-debug: [为什么]
- li-manage: [为什么]

## 约束
- 不要: [已排除的方案 + 原因]
```

---

## 使用决策

| 场景 | 用哪个模式 |
|------|-----------|
| 长对话信息密度低 | Caveman（压缩输出） |
| 需要切换会话 | Handoff（生成交接文档） |
| 两者结合 | 先 Caveman 压缩对话，再 Handoff 生成文档 |
