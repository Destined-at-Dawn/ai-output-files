# Phase 3：分级记忆系统

> 从 SKILL.md 拆出，按需加载。周期性执行（非每次对话），或当需要管理 HOT/WARM/COLD 记忆时读取本文件。

## 存储分层

| 层级 | 位置 | 大小限制 | 行为 |
|------|------|---------|------|
| HOT | `~/li-improve/memory.md` | ≤100 行 | 每次对话必加载 |
| WARM | `~/li-improve/projects/` + `domains/` | 各≤200 行 | 上下文匹配时加载 |
| COLD | `~/li-improve/archive/` | 不限 | 显式查询时加载 |

## 升降规则

- 3 天内使用 3 次 → 升级到 HOT
- 30 天未使用 → 降级到 WARM
- 90 天未使用 → 归档到 COLD
- **永不删除**（除非用户明确要求）

## 冲突解决

1. 最具体优先（project > domain > global）
2. 最新优先（同层级）
3. 不确定 → 问用户

## 透明性规则

- 使用记忆时必须引用来源："Using X (from memory.md:12)"
- 按需完整导出
- 永不从沉默中推断

## 优雅降级

上下文限制时：
1. 只加载 HOT tier（`memory.md`）
2. 按需加载相关 namespace
3. 告知用户什么没被加载
