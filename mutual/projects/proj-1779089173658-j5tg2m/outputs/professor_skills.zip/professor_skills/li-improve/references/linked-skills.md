# 联动技能详解

| Skill | 触发条件 | 联动方式 |
|-------|---------|---------|
| li-manage | 教训≥3次需规则化 | Phase 2 → li-manage Flow A 记忆沉淀 |
| li-devil | 重大改进决策 | Phase 3 → li-devil 预验尸审查 |
| li-memory | 需要检索历史教训 | Phase 1 → li-memory 事实检索 |
| li-diagnose | 系统级健康问题 | Phase 0.5 → li-diagnose 熵增诊断 |
| li-mindcoach | 改进涉及心理障碍 | Phase 3 → li-mindcoach 心力支持 |
| li-sync | 跨工作区同步教训 | Phase 4 → li-sync 全量同步 |
