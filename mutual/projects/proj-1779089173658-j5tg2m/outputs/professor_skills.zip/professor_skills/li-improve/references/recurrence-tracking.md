# 递归度追踪系统（从 peterskoett/li-improve-agent 641★ 学习）

> 核心洞察：peterskoett 用 `Recurrence-Count` + `First-Seen` + `Last-Seen` + `Pattern-Key` 做结构化去重和升级判断。
> 我们之前靠 AI 手动数"第几次"→ 经常数错。解法：结构化元数据 + 自动计数。

---

## 每条教训的元数据字段

```yaml
# 写入 .learnings/LEARNINGS.md 时，每条必须包含：
metadata:
  pattern_key: "write-before-read"       # 稳定去重键（kebab-case）
  source: "user-correction"              # user-correction / command-failure / self-audit / external
  related_files: ["path/to/file"]        # 相关文件
  tags: ["data-safety", "write-tool"]    # 标签
  recurrence_count: 1                    # 递归度（相同 pattern_key 出现次数）
  first_seen: "2026-06-08"              # 首次出现
  last_seen: "2026-06-08"               # 最后出现
  status: "pending"                      # pending → in_progress → resolved / promoted / wont_fix
```

---

## 自动晋升规则（替代手动判断）

| 条件 | 动作 |
|------|------|
| `recurrence_count ≥ 3` + 跨 ≥2 个任务 + 30 天内 | → 候选铁律（Phase 4） |
| `recurrence_count ≥ 5` + 已有 working fix | → 独立 Skill 候选（Phase 5） |
| `recurrence_count` 自增但 `related_files` 全相同 | → 只记 1 次（同根因多次表现） |

---

## Pattern-Key 去重流程

```
新教训触发
  → 生成 pattern_key（kebab-case 描述核心问题）
  → grep .learnings/ 搜索相同 pattern_key
  → 找到 → recurrence_count += 1, 更新 last_seen, 添加 See Also
  → 没找到 → 创建新条目，recurrence_count = 1
```

**命名规则**：
- 必须是 kebab-case（如 `write-before-read`）
- 描述问题本质，不是表面现象
- 示例：`search-keyword-too-narrow`（对），不是 `bestskill-search-failed`（太具体）
