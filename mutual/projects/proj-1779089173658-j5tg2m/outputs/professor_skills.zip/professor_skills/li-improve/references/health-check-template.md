# 健康检查输出格式模板

```
🩺 系统健康自举检查 — {日期}

C级预防: {pct}% ({c_count}/{total}) — {OK/WARNING/CRITICAL}
INDEX:   {covered}/{total} ({pct}%) — {OK/GAPS}
双写:    {synced} 同步, {only_module} 仅模块级 — {OK/GAPS}
健康分:  {score}/100 — {OK/WARNING/CRITICAL}

Top 3 优先修复:
  1. {item} — {action}
  2. {item} — {action}
  3. {item} — {action}
```
