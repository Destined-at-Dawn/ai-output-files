# 外部研究库

> 2026-06-08 搜索结果（关键词：`li-improve agent`，GitHub 按 stars 排序）
> 搜索策略：宽泛关键词搜 GitHub 全局 + stars 排序，不要限定到 Claude Code 生态内部。

| 项目 | Stars | 核心机制 | 我们学到了什么 |
|------|-------|---------|---------------|
| **letta-ai/letta** | 23.2K | 有状态 agent + 高级记忆 + 自我改进 | 分层记忆系统（HOT/WARM/COLD）|
| **facebookresearch/HyperAgents** | 2.6K | 双层架构（task+meta agent），元认知自修改 | 元认知层每月自检 + 自修改规则 |
| **peterskoett/li-improve-agent** | 641 | `.learnings/` 日志 + hook 驱动 + Recurrence-Count + extract-skill.sh | Hook 激活 + 递归度追踪 + 自动 Skill 提取 |
| **jennyzzt/dgm** | 2.1K | Darwin Gödel Machine，开放式自改进进化 | 进化算法思想（select_next_parent）|
| **metauto-ai/GPTSwarm** | 1.0K | RL/Prompting 优化的自改进 agent | 提示词自动优化 |

**搜索策略教训**：用宽泛关键词（`li-improve agent`）搜 GitHub 全局 + 按 stars 排序。结果最高 <100★ → 说明关键词太窄，换更宽泛的词重搜。
