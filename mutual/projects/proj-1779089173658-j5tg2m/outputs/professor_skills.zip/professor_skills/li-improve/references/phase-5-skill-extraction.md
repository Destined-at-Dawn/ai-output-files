# Phase 5：技能提取

> 从 SKILL.md 拆出，按需加载。当有 2+ 个类似的学习条目时读取本文件，判断是否应提取为独立 Skill。

## 提取条件

- **重复性**：有 2+ 个 See Also 链接到类似条目
- **已验证**：Status 为 resolved 且有修复方案
- **非显而易见**：需要实际调查才能发现
- **广泛适用**：跨代码库/工作区有用
- **用户标记**：用户说"保存为 skill"

## 提取流程

1. 读取 `scripts/extract-skill.sh` 使用说明
2. `extract-skill.sh <skill-name> --dry-run` 预览
3. `extract-skill.sh <skill-name>` 执行
4. 更新原始条目状态为 `promoted_to_skill`
