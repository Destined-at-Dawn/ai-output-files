---
name: li-workspace
description: >
  宏观工作区治理引擎 (v4.0)。负责长效容器的搭建、跨区规则同步与全局架构重构。
  与微观级的 project-init 形成“宏微观分层”治理闭环。
version: 4.0.0
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读

- 无固定必读文件 — 按 Flow 类型读取对应 references/ 文件（见按需段）

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[scaffold流程] -> **必须** `Read references/scaffold-workspace-patterns.md`
- 场景[redesign流程] -> **必须** `Read references/redesign-refactoring-patterns.md`
- 场景[migration流程] -> **必须** `Read references/migration-migration-patterns.md`

### [STOP] 门禁

- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# 工作区治理引擎 (Workspace Governance Engine v4.0)

> **核心哲学**：工作区是生命的长效容器，是所有项目的母体。
> **参考来源**：牛马 AI 配置包 v3.1 + niuma-engine。

## 宏微观分层架构 (Layered Architecture)

| 层级 | 负责 Skill | 核心职责 | 目录特征 |
| :--- | :--- | :--- | :--- |
| **宏观 (Workspace)** | **li-workspace** | 全局规则、跨区同步、长效记忆、环境治理 | `memory/`, `skills/`, `shared-rules/` |
| **微观 (Project)** | **project-init** | 阶段化管理、任务执行、00-04 编号资产化 | `00-资料`, `01-设计`, `02-代码` |

## 工作流程 (Modes)

### 1. Setup (宏观搭建)

用于创建一个全新的功能型工作区（如：个人、竞赛、创作）：
- **注入全局灵魂**：读取 `~/.newmax/user-profile.md` 初始化 `telos` 同步。
- **骨架搭建**：创建 `CLAUDE.md`, `memory/`, `SOPs/`, `skills/`, `outputs/`, `.claude/rules/`。
- **规则同步**：调用 `li-sync` 强制同步全局共享规则（如：双写协议）。
- **初始化 Git**：建立长效跟踪机制。

### 2. Migration (跨区迁移)

用于文件/项目在不同工作区间的流转：
- **资产标记**：识别项目属性，确保迁移后目录语义不丢失。
- **路径对齐**：根据 R16 根目录优先原则重新对齐路径。

### 3. Refactoring (架构重构)

针对已有工作区的深度治理：
- **冗余清理**：识别并合并重复的 Skill 或 SOP。
- **语义重构**：将混乱的根目录文件按“宏微观分层”重新归位。

## 联动逻辑

- **向下调用**：在工作区内启动具体任务时，调用 `project-init` 在 `projects/` 下生成微观节点。
- **向上同步**：项目结项后，调用 `li-memory` 将微观教训回流至宏观 `memory/long-term.md`。

## Theory Anchors

| # | Theory | Source | Application |
|---|--------|--------|-------------|
| T1 | Convention over Configuration | Rails | Standard structure reduces cognitive load |
| T2 | Incremental Migration | Martin Fowler | Batch execution, verify each batch |
| T3 | SSOT | Data Engineering | Source files are the single source of truth |
| T4 | SRP | Robert C. Martin | One module, one job |

## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
