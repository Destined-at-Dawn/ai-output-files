# 平台配置差异

## Claude Code
- 主约束文件: CLAUDE.md
- 规则目录: .claude/rules/（自动加载）
- 技能目录: ~/.newmax/skills/
- 路由表: skill-routing-table.json
- 会话管理: .claude/session-checkpoint.md

## Codex
- 主约束文件: AGENTS.md
- 规则目录: .codex/rules/
- 技能目录: ~/.codex/skills/
- 路由表: skill-rules.json

## Grok
- 主约束文件: GROK.md
- 规则目录: .grok/rules/
- 技能目录: ~/.grok/skills/
- 路由表: skill-rules.json

## 通用配置（跨平台）
- memory/ 目录结构（所有平台通用）
- SOPs/ 目录（所有平台通用）
- outputs/ 目录（所有平台通用）
- Git工作流（所有平台通用）
