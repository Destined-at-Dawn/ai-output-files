# 平台Bridge模板

## Claude Code Bridge
```markdown
# CLAUDE.md
[项目约束]
## 启动序列
Step 0: Read runtime-snapshot.md
Step 1: Read memory/long-term.md
...
## 技能路由
读取 skill-routing-table.json 并匹配触发词
```

## Codex Bridge
```markdown
# AGENTS.md
[项目约束]
## 启动协议
1. 读取 memory/long-term.md
2. 读取 .codex/rules/
3. 加载技能路由
```

## Grok Bridge
```markdown
# GROK.md
[项目约束]
## 启动协议
1. 读取上下文文件
2. 加载规则
3. 匹配技能
```

## 兼容性矩阵

| 功能 | Claude Code | Codex | Grok |
|------|------------|-------|------|
| 主约束文件 | CLAUDE.md | AGENTS.md | GROK.md |
| 规则目录 | .claude/rules/ | .codex/rules/ | .grok/rules/ |
| 技能目录 | ~/.newmax/skills/ | ~/.codex/skills/ | ~/.grok/skills/ |
| 路由表 | skill-routing-table.json | skill-rules.json | skill-rules.json |
| 自动加载 | .claude/rules/自动 | .codex/rules/自动 | 手动 |
