# 工作区类型模板

## 类型1: 管理工作区（如 mutual）
```
管理/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/
├── outputs/
├── handoffs/              # 跨工具交接文件
├── project-context/       # 项目上下文卡
├── artifact-registry.md   # 产出注册表
├── workflow-inbox.md      # 工作流改进收件箱
└── .claude/rules/
```

## 类型2: 创作工作区
```
创作/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/
├── outputs/
├── drafts/                # 草稿
├── published/             # 已发布
├── media/                 # 媒体素材
├── content-calendar.md    # 内容日历
└── .claude/rules/
```

## 类型3: 求职工作区
```
求职/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/
├── outputs/
├── resumes/               # 简历版本
├── companies/             # 目标企业
├── applications/          # 申请记录
├── job-search-tracker.md  # 求职追踪器
└── .claude/rules/
```

## 类型4: 竞赛工作区
```
竞赛/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/                  # 竞赛SOP
├── outputs/
├── projects/              # 竞赛项目
├── logs/                  # 调试日志
├── competition-deadlines.md
└── .claude/rules/
```

## 类型5: 学习工作区
```
学习/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/
├── outputs/
├── courses/               # 课程资料
├── notes/                 # 学习笔记
├── exams/                 # 考试准备
├── study-schedule.md      # 学习计划
└── .claude/rules/
```

## 类型6: 通用工作区
```
项目/
├── CLAUDE.md
├── memory/
├── skills/
├── SOPs/
├── outputs/
├── references/
├── project.md
└── .claude/rules/
```

## CLAUDE.md 启动序列模板

```markdown
# 启动强制读取序列

| Step | 操作 | 触发条件 |
|------|------|----------|
| 0 | Read runtime-snapshot.md | 每次对话必读 |
| 1 | Read memory/long-term.md | 首次对话必读 |
| 2 | Read memory/{今天日期}.md | 每日首次对话必读 |
| 3 | Read self-evolution/evolution-calendar.md | 每次对话必读 |
| 4 | 若Step 3匹配 -> 先执行进化任务 | auto-evolution |
| 4.5 | 加载 skill-routing-table.json | 每次对话必读 |
| 5 | 记忆写入候选 | 每次写入memory/前 |
| 6 | 检查session checkpoint | 每次对话必读 |
```
