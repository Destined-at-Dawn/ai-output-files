# Golden Rules - li-workspace

1. [GR-001] Workspace operations = assess first, execute second. Never skip Phase 0.
2. [GR-002] Third-party repos are READ-ONLY. Never modify downloaded GitHub repos.
3. [GR-003] Before creating new workspace, check if existing one can be reused.
4. [GR-004] Every workspace change needs a git checkpoint before execution.
5. [GR-005] Route table must be synced after any workspace structure change.
6. [GR-006] Refactoring = small steps. One dimension at a time. Test after each step.
7. [GR-007] Migration source files are the single source of truth. Bridge adapts, not source.
