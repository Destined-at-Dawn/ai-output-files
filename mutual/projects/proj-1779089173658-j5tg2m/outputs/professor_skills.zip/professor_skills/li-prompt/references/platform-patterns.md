# 平台特化模式详解

## Claude 最佳实践

### 母语：XML标签 + 结构化指令
```xml
<role>你是一个数据分析专家</role>
<context>
用户有一份销售数据CSV，需要分析季度趋势。
</context>
<task>
1. 计算每个季度的总销售额
2. 识别增长/下降趋势
3. 给出3个可执行的建议
</task>
<output_format>
Markdown表格 + 趋势图描述 + 编号建议列表
</output_format>
<constraints>
- 不要编造数据
- 数字保留2位小数
- 中文输出
</constraints>
```

### Claude独有优势
- 200K tokens长上下文 → 可以放完整文档作为参考
- XML标签分隔 → 结构清晰，AI不容易混淆不同部分
- System prompt放角色定义 → Claude对system prompt的遵循度极高
- `extended thinking`模式 → 复杂推理任务开启深度思考

### Claude避坑
- ❌ 不要用对话式（"嘿，帮我个忙"）→ 直接给指令
- ❌ 不要把所有信息塞一个标签 → 分标签分层
- ❌ 不要忽略output_format → 不给格式约束输出会很散

## GPT 最佳实践

### 母语：Markdown + 对话式 + Function Calling
```markdown
# System
你是一个数据分析专家。输出格式为Markdown。

# User
我有一份销售数据CSV，需要分析季度趋势。
请按以下步骤执行：
1. 计算每个季度的总销售额
2. 识别增长/下降趋势
3. 给出3个可执行的建议

输出格式：Markdown表格 + 编号列表
```

### GPT独有优势
- Function Calling → 结构化JSON输出（API场景首选）
- 多模态（GPT-4V）→ 图片理解能力强
- Plugin生态 → 可以调用外部工具

### GPT避坑
- ❌ System prompt太长 → GPT对长system prompt的遵循度随长度下降
- ❌ 不给Temperature调参 → 创意任务0.7-0.9，精确任务0-0.3
- ❌ 用XML标签 → GPT不原生支持XML标签分隔

## Gemini 最佳实践

### 母语：分析式 + 多模态优先
- 长文档处理能力强（1M tokens）
- 图片+文字 > 纯文字（Gemini原生多模态）
- 思维链提示效果好

### Gemini避坑
- ❌ 纯文本prompt不用图片 → 浪费多模态能力
- ❌ 短prompt → Gemini擅长处理长上下文

## Codex / Grok

### Codex
- 代码优先，最小上下文
- 精确到函数签名级别的指令
- 适合代码生成和重构

### Grok
- X平台数据优势（实时信息）
- 对话式，高幽默容忍
- 适合搜索和创意任务

## 通用模式（跨平台）

### 三明治结构
```
[核心要求]
[详细说明]
[核心要求重复]
```
原理：注意力机制的U型曲线——开头和结尾权重最高。

### 角色设定公式
```
你是一个{专业领域}的{角色}，有{年限}年经验，擅长{具体技能}。
你的{输出风格}风格是{具体描述}。
```

### 约束公式
```
输出要求：
- 格式：{Markdown/JSON/代码块}
- 长度：{不超过N字/N个要点}
- 风格：{正式/轻松/技术}
- 禁止：{不要X}
- 必须：{必须包含Y}
```
