---
name: li-prompt
description: |
  li系列 · 跨AI平台Prompt构建引擎 v2.0。六维构建 + 平台适配 + 迭代打磨。
  不同LLM有不同的"母语"——Claude爱XML标签，GPT爱Markdown，Gemini爱分析式。
  本skill不生产prompt模板，而是教你如何为任何平台构建最优prompt。
  融合：hue(ASI-Arch 3.7K★) + Chain-of-Thought + Few-shot + Constitutional AI。
version: 2.0.0
allowed-tools: [Read, Write, Edit, Glob, Grep, WebFetch, WebSearch]
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **执行约束（非建议）。** **必读（必须 Read）**: `references/iteration-protocol.md` | `references/platform-patterns.md` | `references/theory-table.md` | `references/case-studies.md` | `references/anti-patterns.md`。无 Source = 禁止声称。跳过 = 违反法则8。Phase 执行前确认已 Read 所有 references/ 必读文件，未读 = 禁止继续。
> **按需**: `references/platform-patterns.md` | `references/theory-table.md` | `references/case-studies.md` | `references/anti-patterns.md`


# li-prompt — 跨AI平台Prompt构建引擎

> Prompt不是"写给AI的话"，是"把你的意图翻译成AI的母语"。
> 同一个需求，Claude版和GPT版prompt可能完全不同——因为它们的"母语"不同。
> 六维构建：目标 → 平台 → 约束 → 示例 → 格式 → 审计。缺一维，效果打折。

**详细方法论见 references/ 目录。本文件是执行骨架。**

---

## 参考文件地图（references/）

| 文件 | 内容 | 何时读取 |
|------|------|---------|
| `references/theory-table.md` | 12项认知科学锚点 + Prompt工程理论基础 | 构建prompt时 |
| `references/platform-patterns.md` | 6大平台最佳实践详解（Claude/GPT/Gemini/Codex/Grok/通用） | Phase 2 平台适配时 |
| `references/case-studies.md` | 3个真实案例（代码生成/内容创作/跨平台迁移） | 需要参考范例时 |
| `references/anti-patterns.md` | 9条反模式详解 + 违规检测信号 | 全程自检时 |
| `references/iteration-protocol.md` | 测试→评分→修复→重测协议 + 饱和检测 | Phase 3 迭代时 |

---

## Phase 0：生态预热（每次启动必执行）

### Step 0.1：加载用户画像

**必须读取**：
1. `memory/long-term.md` → 用户偏好、技术水平、常用平台
2. `memory/{today}.md` → 今日上下文
3. `memory/research-profile.md` → 历史prompt使用模式（如果存在）

### Step 0.2：需求消解

**三层消解**（防止做无用功）：
1. **语言陷阱**："帮我写个prompt" → 写给哪个平台？什么任务？现有prompt有没有？
2. **发动机空转**：去掉修饰词，需求是否还成立？
3. **好问题五项检查**：目标平台 / 任务类型 / 约束条件 / 成功标准 / 参考prompt

**评分**：0-4分 → 追问；5-7分 → 先给低置信版本；8-10分 → 进入Phase 1

### Step 0.3：模式分流

**入口A：新建prompt** → Phase 1（六维构建）
**入口B：优化现有prompt** → 读取现有prompt → Phase 2（平台优化）→ Phase 3（迭代）
**入口C：跨平台迁移** → 读取源平台prompt → Phase 2（平台转换）

---

## Phase 1：六维构建（核心）

> 详细理论 → `references/theory-table.md`

### 维度1：目标（What and Why）
- 一句话：做什么
- 为什么：动机 = 更好的输出（AI理解"为什么"比"做什么"更重要）
- **反直觉**：目标越具体越好——"写一篇关于X的文章"不如"写一篇800字的X文章，目标读者是大学生，风格像知乎高赞回答"

### 维度2：平台适配
> 详细平台模式 → `references/platform-patterns.md`

| 平台 | 母语 | 核心技巧 |
|------|------|---------|
| Claude | XML标签 + 结构化指令 | `<context>`, `<instructions>`, `<output_format>` |
| GPT | Markdown + 对话式 | 系统提示 + 用户消息分离，function calling |
| Gemini | 分析式 + 多模态 | 长上下文，图片/PDF优先，思维链 |
| Codex | 代码优先 + 精确指令 | 最小上下文，精确到函数签名 |
| Grok | 对话式 + 高幽默容忍 | X平台数据优势，轻松语气 |
| 通用 | Markdown + 明确结构 | 不依赖平台特性的通用写法 |

### 维度3：约束（Constraints）
- 输出长度 / 格式 / 风格
- 禁止项（"不要使用..."）
- 必须包含项（"必须包含..."）
- **反直觉**：约束越紧，输出越可控——但太紧会扼杀创造力。sweet spot是"框架内自由"

### 维度4：示例（Few-shot）
- 正例：2-3个理想输出样例
- 反例：1-2个"不要这样"的示例
- **认知科学**：Few-shot learning的核心是"模式识别"——AI从示例中提取隐含的格式/风格/深度规则
- **反直觉**：1个好示例 > 3个平庸示例。示例质量比数量重要

### 维度5：格式（Format）
- 输出结构（JSON / Markdown / 代码块）
- 分隔符和标记
- **Claude特有**：XML标签包裹输出格式要求效果最好

### 维度6：审计（Audit）
- 生成后对照6个维度逐一检查
- 不通过 → 修prompt → 重新生成
- **不可跳过**：没有审计的prompt = 没测试的代码

---

## Phase 2：平台特化优化

> 6 大平台优化策略详见 `references/platform-patterns.md`（Claude用XML标签、GPT用Markdown+function calling、Gemini多模态优先等）

---

## Phase 3：测试与迭代

> 详细迭代协议 → `references/iteration-protocol.md`

### 测试流程
1. 用3个不同输入测试
2. 评分输出质量（1-5分）
3. 分数 < 4 → 诊断问题 → 修prompt → 重测
4. **铁律**：修一个维度，其他维度不变（控制变量）

### 饱和检测
- 连续3轮迭代分数变化 < 0.3 → 达到平台能力上限
- 换平台或换prompt架构（不是微调能解决的）

### 一鱼多吃（生态副作用写入）

| 编号 | 目标文件 | 操作 |
|------|---------|------|
| ① | `outputs/prompt-library/{平台}-{任务类型}-{日期}.md` | 保存高质量prompt到库 |
| ② | `memory/{today}.md` | Edit追加prompt构建摘要 |
| ③ | `memory/long-term.md` | 高价值prompt模式走候选确认 |
| ④ | `memory/research-profile.md` | 更新prompt使用偏好（如果存在） |

---

## 设计哲学（7条）

| # | 哲学 | 反例 |
|---|------|------|
| 1 | 平台感知：不同LLM有不同"母语" | 一个prompt打所有平台 |
| 2 | 六维完整：缺一维效果打折 | 只写任务不写约束 |
| 3 | 可测试：好prompt必须有成功标准 | "写个好prompt"无法验证 |
| 4 | 反讨好：不要"请""谢谢"，直接指令 | 浪费tokens，不提升质量 |
| 5 | 示例 > 规则：1个好示例胜过10条规则 | 堆砌规则不给示例 |
| 6 | 约束 = 自由：框架内自由 > 无限自由 | 不给约束让AI"自由发挥" |
| 7 | 迭代 > 一次到位：好prompt是改出来的 | 写一次就用，不测试 |

---

## 理论锚点（摘要）

| # | 理论 | 来源 | 在prompt中的应用 |
|---|------|------|-----------------|
| T1 | Chain-of-Thought | Wei et al. 2022 | "让我们一步步思考"提升推理质量 |
| T2 | Few-shot Learning | Brown et al. 2020 | 2-3个示例激活模式识别 |
| T3 | Constitutional AI | Anthropic 2023 | 约束prompt内置安全边界 |
| T4 | 认知负荷理论 | Sweller 1988 | prompt太长太复杂 → AI"记不住" |
| T5 | 锚定效应 | Tversky & Kahneman | prompt里的第一个示例影响最大 |
| T6 | 框架效应 | Kahneman & Tversky | 同一任务用不同框架描述 → 不同结果 |

> 完整12项 → `references/theory-table.md`

---

## 反模式（摘要）

| # | 反模式 | 后果 | 修正 |
|---|--------|------|------|
| 1 | 一个prompt打所有平台 | 各平台表现不一致 | 为每个平台定制 |
| 2 | 不给示例 | 输出格式不可控 | 至少2个正例 |
| 3 | 堆砌"请""谢谢" | 浪费tokens | 直接指令 |
| 4 | 不测试就用 | 生产环境翻车 | 3次测试+评分 |
| 5 | 约束太多 | AI"窒息"，输出僵硬 | 约束=框架，留空间 |
| 6 | 约束太少 | 输出不可控 | 至少给格式约束 |
| 7 | 修prompt改多个维度 | 无法定位哪个改动有效 | 每次只改一个维度 |

> 完整9条 + 违规检测信号 → `references/anti-patterns.md`

---

## 条件式下一步推荐

| 条件 | 推荐skill | 话术 |
|------|-----------|------|
| prompt需要视觉风格 | li-visual | "prompt里加视觉描述？用li-visual生成风格词。" |
| prompt要变成skill | li-skillcreate | "这个prompt值得固化成skill。" |
| 需要跨区同步prompt库 | li-sync | "prompt库要同步到其他工作区。" |
| prompt效果不好要诊断 | li-diagnose | "prompt系统熵增了？做诊断。" |
| 需要深度调研prompt技术 | li-research | "prompt engineering前沿值得调研。" |
| prompt内容要变成文章 | li-content | "这个prompt经验可以写成教程。" |

---

## 联动技能

| 技能 | 联动方式 | 触发条件 |
|------|---------|---------|
| li-visual | 上游 | 需要视觉风格描述时 |
| li-skillcreate | 下游 | prompt成熟后固化为skill |
| li-research | 并行 | 调研prompt engineering前沿 |
| li-content | 下游 | prompt经验变成内容产出 |
| li-sync | 并行 | 同步prompt库到其他工作区 |
| li-diagnose | 并行 | 诊断prompt系统问题 |
| li-improve | 下游 | prompt构建经验沉淀为规则 |

---

## 外部研究（摘要）

| 项目 | Stars | 核心价值 |
|------|-------|---------|
| ASI-Arch Hue | 3.7K | 六维跨AI平台prompt构建框架 |
| Brex HQ prompt-engineering | 12K | GPT最佳实践（角色/任务/格式/约束） |
| OpenAI Cookbook | 15K+ | 官方prompt工程指南 |
| Anthropic Prompt Engineering | 官方 | Claude XML标签最佳实践 |

> 完整研究清单 → `references/external-research.md`（待创建）

## 案例库

### 案例 1: 公众号文章跨平台改写
- **场景**: 一篇技术文章要发公众号/小红书/知乎/即刻 4 个平台，每个平台风格不同
- **做法**: li-prompt Phase 1 六维框架（目标/平台/约束/例证/格式/审计） → 每平台生成独立 prompt
- **结果**: 4 个平台 prompt 一次性生成，节省 90% 重复调整时间
- **来源**: 创作工作区，2026

### 案例1：典型使用场景
li-prompt在以下场景中最常用：用户发出与"prompt"相关的指令时自动触发。
典型流程：Phase 0需求消解 → Phase 1核心执行 → Phase 2质量验证 → Phase 3记忆沉淀。

### 案例2：跨skill联动场景
li-prompt经常与其他li-skill串联使用——详见"联动技能"章节。
联动时由上游skill决定何时调用本skill，本skill专注自己的核心能力。

### 案例3：失败恢复场景
当li-prompt执行失败时：检查是否缺少输入（Phase 0消解不充分）、是否触发词误匹配（应触发其他skill）、是否references/文件缺失。
失败记录写入golden_rules.md防止重复。


## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈



## Conditional Next Steps
| Signal | Action | Chain |
|--------|--------|-------|
| [Phase complete] | Determine next phase | Continue within this skill |
| [External data needed] | Call li-research or li-bestskill | Research phase |
| [Quality check needed] | Call li-devil for cold water review | Devil review |
| [User unhappy] | Call li-mindcoach for mindset shift | Mindcoach |
| [Memory update needed] | Call li-memory for fact extraction | Memory |
| [Cross-workspace sync] | Call li-sync | Sync |

## Case Studies

### Case 1: 为 Claude Code 构建 System Prompt（2026-06-08）
- **场景**: 需要跨 AI 平台的 prompt 工程，统一 li- 系列 skill 的行为规范
- **方法**: 六维分析（目标/平台/约束/例证/格式/审计）-> 生成 CLAUDE.md 结构
- **结果**: 43 个工作区统一的行为规范
- **Source**: .claude/rules/ 目录

### Case 2: CO-STAR 框架跨平台 prompt（2026-06-09）
- **场景**: 需要在 ChatGPT/Claude/Gemini 三个平台复用 prompt
- **方法**: CO-STAR 框架（Context/Objective/Style/Tone/Audience/Response）
- **教训**: 不同平台对 prompt 格式敏感度不同

### Case 3: contract-style prompt（2026-06-09）
- **场景**: Agent 的 prompt 需要明确输入/输出契约
- **方法**: 每个 prompt 附带 Input Contract + Output Contract
- **教训**: 明确契约 > 自然语言描述

## Anti-Patterns

| ID | 反模式 | 后果 | 纠正 |
|----|--------|------|------|
| AP-01 | Prompt 太长导致指令遗忘 | AI 忘记后半部分指令 | 关键指令放首尾 |
| AP-02 | 不区分平台直接复用 | 效果差异大 | 每平台微调 |
| AP-03 | 不给示例 | AI 理解偏差 | 至少 1 个 input/output 示例 |
| AP-04 | 过度约束 | AI 创造力受限 | 只约束必须的，留空间 |
| AP-05 | 不测试边界情况 | 异常输入时 AI 崩溃 | 测试 3 个边界 case |

## Linked Skills

| Skill | 触发条件 | 联动方式 |
|-------|---------|----------|
| li-skillcreate | 创建新 skill 的 SKILL.md | prompt 质量检查 |
| li-manage | 优化 CLAUDE.md 内容 | prompt 工程优化 |
| li-research | 研究 prompt 最佳实践 | 搜索外部 prompt 模板 |