# 分流决策树

## 分流矩阵
| 紧急\重要 | 高重要 | 低重要 |
|-----------|--------|--------|
| 高紧急 | 🔴 立即处理 | 🟡 委派/快速处理 |
| 低紧急 | 🟢 计划处理 | ⚪ 排队/丢弃 |

## 5 状态机
- **New**：刚收到，未分类
- **Triaged**：已分类，待分配
- **InProgress**：正在处理
- **Blocked**：被阻塞，需要输入
- **Done**：完成

## 状态转移规则
- New → Triaged：必须在 5 分钟内
- Triaged → InProgress：按优先级排序
- InProgress → Blocked：标记阻塞原因
- Blocked → InProgress：阻塞解除
