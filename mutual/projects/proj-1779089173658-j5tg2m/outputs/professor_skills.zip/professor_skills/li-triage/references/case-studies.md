# li-triage 案例库

## 案例 1: 竞赛项目 bug 收集

**背景**: RoboMaster 步兵，23 个 bug 报告。
**分流**: needs-triage 23 -> ready-for-agent 8, ready-for-human 5, needs-info 7, wontfix 3
**关键决策**:
- 云台抖动 -> ready-for-human (需要示波器)
- CAN 丢帧 -> needs-info (需要总线抓包)
- 调试 LED 不亮 -> wontfix (比赛不允许)

## 案例 2: 学习计划需求整理

**背景**: 期末前 12 个学习需求。
**分流**:
- 整理电磁学公式 -> ready-for-agent (明确、可自动化)
- 理解麦克斯韦方程 -> ready-for-human (需要对话式教学)
- 物理题格式优化 -> ready-for-agent (有 SOP)
- 量子力学复习 -> needs-info (范围太大)

## 案例 3: 内容创作需求分流

**背景**: 小红书 + 公众号 15 个内容需求。
**分流**:
- 写 FPGA 入门 -> ready-for-agent (主题明确)
- 规划本月内容 -> ready-for-human (需要商业判断)
- 优化帖子标题 -> ready-for-agent (有 li-content)
- 确定内容定位 -> needs-info (需要先做市场分析)
