---
name: li-triage
description: >
  Issue/任务分流状态机。5 状态 x 2 类别，纪律化分流。
  触发词：triage/分流/issue管理/bug分类/任务分级/待办整理。
  基于 mattpocock/skills triage (200+ star) 的状态机分流方法。
version: 1.0
---

## [LIGHTNING] 执行协议（强制 - 禁止跳过）

> **本段是执行约束，不是参考建议。违反 = 产出质量不可信。**

### [RED] 必读（执行前必须读取，不可跳过）

- 执行前**必须** `Read references/triage-decision-tree.md` - 不读 = 不了解核心方法论 = 产出不合格

### [YELLOW] 按需（匹配场景时必须读取）

- 场景[案例] -> **必须** `Read references/case-studies.md`

### [STOP] 门禁

- Phase 执行前：确认已读取 references/triage-decision-tree.md。未读 -> **禁止继续**
- 输出结论前：确认有 evidence path (Source: path#line)。无证据 -> **禁止声称**
- 跳过本协议 = 违反工程法则 8（门禁不可跳过）


# li-triage

通过状态机纪律化分流 issue、bug、任务、需求。

---

## 理论锚点

| # | 锚点 | 来源 |
|---|------|------|
| T1 | 状态机分流 | mattpocock triage (5 states x 2 categories) |
| T2 | 有限状态机 | 计算理论 (确定性状态转移) |
| T3 | 艾森豪威尔矩阵 | 紧急/重要四象限 |
| T4 | 信息论 | 信息不足时不该做决策 |
| T5 | 结构化决策 | 决策树优于直觉判断 |

---

## 状态定义

### 2 个类别

| 类别 | 含义 |
|------|------|
| **bug** | 某个东西坏了 |
| **enhancement** | 新功能或改进 |

### 5 个状态

| 状态 | 含义 | 下一步 |
|------|------|--------|
| **needs-triage** | 待评估 | 分流到以下 4 个状态之一 |
| **needs-info** | 等待更多信息 | 报告者回复后回到 needs-triage |
| **ready-for-agent** | 完整定义，可交给 AI | 分配给 agent 执行 |
| **ready-for-human** | 需要人工判断 | 分配给人执行 |
| **wontfix** | 不处理 | 关闭 + 说明理由 |

### 状态转移规则

```
新 issue -> needs-triage
    -> needs-info (信息不足)
    -> ready-for-agent (完整且可自动化)
    -> ready-for-human (需要人工判断)
    -> wontfix (不处理)

needs-info -> needs-triage (信息补齐)
维护者可随时覆盖状态 (但要标记异常转移)
```

---

## Phase 0 - 收集注意力桶

查询所有待处理项，按 3 个桶分组 (最旧优先)：

| 桶 | 定义 | 紧急度 |
|----|------|--------|
| 未标记 | 从未分流 | 最高 |
| needs-triage | 评估进行中 | 高 |
| needs-info 有新回复 | 需要重新评估 | 中 |

每个 issue 显示计数 + 一行摘要。让用户选择。

---

## Phase 1 - 分流单个 issue

### Step 1: 收集上下文
读取完整 issue (正文/评论/标签/报告者/日期)。解析之前分流笔记。读取相关代码。

### Step 2: 推荐
向用户推荐类别和状态 + 推理过程。等用户确认。

### Step 3: 复现 (仅 bug)
尝试复现。报告：成功复现 / 复现失败 / 细节不足。

### Step 4: 深入 (如需)
issue 需要充实 -> 进入深度访谈模式。

### Step 5: 应用结果

| 结果状态 | 动作 |
|---------|------|
| ready-for-agent | 写 agent brief (目标/约束/验收标准) |
| ready-for-human | 同上 + 标注为什么不能自动化 |
| needs-info | 写分流笔记 (已确认 + 还需要什么) |
| wontfix | 说明理由 + 关闭 |

---

## Agent Brief 模板

```
## 任务描述
[一句话]

## 已确认
- point 1

## 约束
- constraint 1

## 验收标准
- [ ] criterion 1
- [ ] criterion 2
```

---

## Needs-Info 模板

```
## 分流笔记

**已确认：**
- point 1

**还需要你提供：**
- 具体问题 1
- 具体问题 2
```

问题必须具体可操作，不要"请提供更多信息"。

---

## 联动

| Skill | 触发条件 | 联动方式 |
|-------|---------|---------|
| li-devil | issue 涉及重大决策 | 泼冷水评估 |
| li-debug | bug 分流后进入调试 | 调试循环 |
| li-manage | 批量任务整理 | 生命周期管理 |
| li-workflow | agent brief 需要自动化 | 工作流编排 |

---

## 反模式

| # | 反模式 | 后果 |
|---|--------|------|
| 1 | 不看代码就分流 | 推荐的类别可能全错 |
| 2 | needs-info 问得模糊 | 报告者回复还是不够 |
| 3 | 跳过复现直接修 | 修的可能不是用户遇到的 bug |
| 4 | wontfix 不给理由 | 用户困惑 + 重复提交 |
| 5 | 不检查历史拒绝 | 同一理由说两遍 |
| 6 | 全部标 ready-for-agent | 需要人工判断的强行自动化出错 |

---

## 条件下一步

| 条件 | 下一步 |
|------|--------|
| issue 描述不清 | -> needs-info |
| bug 可复现 | -> ready-for-agent |
| bug 不可复现 | -> needs-info 要复现步骤 |
| enhancement 有明确规格 | -> ready-for-agent |
| enhancement 需要设计决策 | -> ready-for-human |
| 类似 issue 已有 wontfix | 告知用户历史拒绝理由 |
| 批量 issue 需要整理 | 调用 li-manage |


## Case Studies

### Case 1: GitHub Issue 分流
- **场景**：项目收到 20 个 issue，需要分类处理
- **方法**：5 状态机（backlog→needs-info→ready→in-progress→done）+ 2 类别（bug/feature）
- **结果**：30 分钟完成分流，之前手动要 2 小时
- **教训**：分流的关键是快速判断"这个 issue 现在能不能做"

### Case 2: 竞赛任务分优先级
- **场景**：竞赛项目 15 个待办任务
- **方法**：影响×紧急度矩阵 → P0/P1/P2 分级 → 每天只做 P0
- **结果**：按时完成核心功能
- **教训**：P0 不超过 3 个，否则优先级等于没设

### Case 3: 多人协作任务分配
- **场景**：团队 3 人，10 个任务需要分配
- **方法**：Agent Brief 模板（目标+约束+验收标准）→ 每人分配独立任务
- **结果**：无任务冲突，按时交付
- **教训**：分配任务时必须写清验收标准


## Anti-Patterns

| # | Anti-Pattern | Why It Fails | Correct Approach |
|---|---|---|---|
| 1 | 所有 issue 都标 P0 | 优先级等于没设 | P0 不超过 3 个 |
| 2 | 不写 Agent Brief | sub-agent 不知道目标 | 必须包含目标+约束+验收标准 |
| 3 | 分流后不跟踪状态 | issue 卡在某个状态无人知 | 每天检查状态机流转 |
| 4 | needs-info 不设超时 | issue 永远停在等待状态 | 48 小时无回复 → 关闭 |


## Linked Skills

| Skill | Integration Point | Trigger |
|-------|-------------------|---------|
| **li-plan** | 分流后的任务排期 | "这个任务排到什么时候" |
| **li-debug** | bug 类 issue 的调试 | "这个 bug 怎么修" |
| **li-infra** | issue 涉及基础设施变更 | "需要改 CLAUDE.md" |

## 注意事项

1. Progressive Disclosure——主文件≤300行，详细内容在references/
2. 每次修改后必须更新skill-routing-table.json并同步所有工作区
3. 用户反馈（"好"或"不好"）必须写入golden_rules.md
4. 本skill的触发词必须和其他li-skill正交——不抢别人的触发词
5. 引用百大认知书籍时标注书名+编号，不空谈

## 案例库

### 案例 1：GitHub Issues 批量分流
**场景**：项目积累了 30 个未分类 Issue
**方法**：每个 Issue → 判断严重度 × 类别 → 分流到 bug/feature/question
**结果**：30 个 Issue 在 15 分钟内全部分类
**关键**：先分严重度再分类别，不要反过来

### 案例 2：竞赛任务优先级排序
**场景**：RoboMaster 比赛前 2 周，10 个待完成任务
**方法**：Critical（必须完成）/ Important（应该完成）/ Nice-to-have（可以推迟）
**结果**：聚焦 3 个 Critical 任务，按时完成
**关键**：Nice-to-have 不是"低优先级"，是"不做"

### 案例 3：多平台消息分流
**场景**：微信/小红书/邮件同时有消息需要处理
**方法**：按紧急度 × 回复成本矩阵分流
**结果**：先处理 2 个紧急+低成本的，其余排入明天
**关键**：不是所有消息都需要今天回复