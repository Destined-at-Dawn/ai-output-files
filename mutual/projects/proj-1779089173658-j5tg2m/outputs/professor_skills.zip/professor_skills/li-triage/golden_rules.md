# li-triage 黄金规则

## GR-001: P0 不超过 3 个
- **规则**：任何时刻，in-progress 状态的 issue 不超过 3 个
- **来源**：项目管理最佳实践
- **反模式**：所有 issue 都标 P0 = 优先级等于没设

## GR-002: needs-info 必须有超时
- **规则**：needs-info 状态超过 48 小时无回复 → 自动关闭
- **来源**：GitHub issue 管理最佳实践
- **反模式**：issue 永远停在 needs-info 无人处理

## GR-003: Agent Brief 必须完整
- **规则**：分配给 sub-agent 的任务必须包含目标+约束+验收标准
- **来源**：agent-prompt-ironclad.md 铁律 1
- **反模式**：只给标题不给细节 → sub-agent 跑偏

## GR-004: 分流必须有状态机
- **规则**：所有 issue 必须在明确的状态（backlog/needs-info/ready/in-progress/done）
- **来源**：mattpocock triage（19 skill 项目）
- **反模式**：issue 没有状态 = 没人管

## GR-005: 每天检查状态流转
- **规则**：每天开始时检查是否有 issue 卡在某个状态超过 24 小时
- **来源**：li-manage Flow E 优化机制
- **反模式**：分流后不跟踪 = 分流白做

## GR-006: 分流标准必须可操作
- **规则**：每个状态的进入/退出条件必须是可验证的，不是主观判断
- **来源**：工程法则 8（门禁不可跳过）
- **反模式**：靠感觉分流 → 不一致
