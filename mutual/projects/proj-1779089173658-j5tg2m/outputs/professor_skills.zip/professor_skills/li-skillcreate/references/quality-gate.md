### Phase 3.5：质量门禁（15 项强制检查）

构建完成后必须过 **15 项质量门禁**（详见 `references/skill-structure.md` § 质量门禁）。不过不能进入 Phase 4。

核心检查：主文件 ≤300行 / 理论锚点 ≥5 / 反模式 ≥5 / 案例 ≥2 / 联动 ≥3 / 外部研究 ≥1 / 标配文件齐全 / 触发词 ≥10 / 费曼检验通过

> ⚠️ **硬规则**：质量门禁必须包含"路由表是否已注册"（见 `.claude/rules/skill-route-enforcement.md` 铁律 1）。路由未注册 = 质量门禁不通过 = 不准提交。

> 🔴 **硬规则·三工具同步（Codex 孤岛事故 2026-06-18）**：门禁必须验证 skill 已落盘到 `.codex` + `.newmax` + `.claude` **三处**，且三处 `skill-routing-table.json` **均**已注册路由。任一缺失 = 不通过 = 不准提交。验证：`for t in .codex .newmax .claude; do ls ~/$t/skills/{skill}/SKILL.md; done`（应三行全中）。

**必须输出评审报告**（5 维 × 5 分 = 25 分满分，< 20 分 = 重做）。详见 `references/skill-structure.md`。

---
