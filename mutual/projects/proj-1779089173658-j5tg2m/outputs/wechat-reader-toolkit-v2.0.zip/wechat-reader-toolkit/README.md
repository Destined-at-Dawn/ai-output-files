# 微信聊天记录读取工具包 v2.0

## 简介

一套完整的微信聊天记录提取与分析工具链。从已解密的微信数据库中提取聊天记录、联系人信息、转账红包记录，并进行文风分析。

## 环境要求

- **Python 3.8+**（推荐 3.10+）
- **已解密的微信数据库文件**（message_0.db, contact.db, general.db, session.db）

### 安装依赖

```bash
pip install zstandard
```

## 文件说明

| 脚本 | 功能 | 核心输出 |
|------|------|---------|
| `extract_full_data.py` | 全量数据提取（聊天+联系人+群成员） | corpus.json, all_sessions.json 等 |
| `export_chat.py` | 单个联系人/群聊记录导出为 Markdown | chat_xxx.md |
| `analyze_wechat.py` | 聊天分类汇总+统计报告 | MD + JSON 报告 |
| `analyze_voice_dna.py` | 文风DNA蒸馏（私聊vs群聊风格对比） | 文风分析报告 |
| `extract_red_envelopes.py` | 红包记录提取（含金额） | red_envelopes.json |
| `extract_transfer_amounts.py` | 转账记录提取（含金额） | transfers.json |

## 快速开始

### Step 1: 获取解密后的数据库

你需要先解密微信数据库。推荐工具：
- **PyWxDump**: `pip install pywxdump` → `pywxdump bias_addr` → `pywxdump decrypt`
- **wx_key**: `pip install wx_key`（需微信正在运行）

解密后你会得到以下文件（通常在同一个目录下）：
```
message_0.db    # 聊天记录（最大，几百MB）
contact.db      # 联系人信息
general.db      # 转账/红包/收藏等
session.db      # 会话列表
```

### Step 2: 全量提取

```bash
python extract_full_data.py --db-dir "你的数据库目录" --output "输出目录"
```

输出文件：
- `all_sessions.json` — 所有会话统计
- `top_private.json` — 私聊排行 Top 20
- `top_groups.json` — 群聊排行 Top 20
- `corpus.json` — 全量消息语料
- `transfers.json` — 转账记录
- `group_members.json` — 群成员列表
- `data_summary.md` — Markdown 报告

### Step 3: 导出特定聊天

```bash
python export_chat.py --db "消息数据库路径/message_0.db" --contact-db "联系人数据库路径/contact.db" --target "张三" --output "chat_张三.md"
```

支持导出私聊和群聊，自动解析联系人名称和群成员昵称。

### Step 4: 生成分析报告

```bash
python analyze_wechat.py --db-dir "数据库目录" --out-dir "输出目录"
```

生成分类汇总报告，自动按"学习/AI/竞赛/生活"等类别归类消息。

### Step 5: 文风分析

```bash
python analyze_voice_dna.py --corpus "输出目录/corpus.json" --output "文风报告.txt"
```

对比你的私聊和群聊用语差异：消息长度、标点使用、高频词等。

### Step 6: 提取红包和转账

```bash
python extract_red_envelopes.py --db-dir "数据库目录" --output "red_envelopes.json"
python extract_transfer_amounts.py --db-dir "数据库目录" --output "transfers.json"
```

## 数据库 Schema 说明

微信 4.0 使用 WCDB（自定义 AES-CBC 加密 SQLite），解密后的关键表：

### message_0.db
- **表名**: `Msg_00` ~ `Msg_xx`（按 hash 分表，需遍历）
- **关键列**: `local_id`, `create_time`(Unix时间戳), `real_sender_id`, `message_content`, `compress_content`(zstd压缩), `status`, `local_type`(10000=系统消息)
- **sender_id=2 永远是数据库主人**
- **群聊消息内容**: 格式为 `sender_wxid:\n消息内容`

### contact.db
- **contact 表**: `username`, `nick_name`, `remark`, `alias`
- **chatroom_member 表**: `room_id`, `member_id`
- **chat_room 表**: `id`, `username`, `owner`

### general.db
- **transferTable**: 转账记录
- **redEnvelopeTable**: 红包记录

### session.db
- **session 表**: 会话列表（username + 最新消息时间）

## 常见问题

### Q: zstandard 安装失败？
```bash
pip install zstandard --only-binary=:all:
```

### Q: 数据库是加密的怎么办？
本工具只处理**已解密**的数据库。解密步骤请参考 PyWxDump 或 wx_key 文档。

### Q: 不知道数据库在哪里？
微信 4.0 默认路径: `D:\data\wechat\xwechat_files\wxid_xxx\db_storage\message\message_0.db`
或: `%LOCALAPPDATA%\Packages\...\LocalCache\Roaming\Tencent\WeChat\...`

### Q: 消息内容是乱码/bytes？
微信 4.0 的 message_content 可能是 zstd 压缩的。脚本已内置解压，确保安装了 zstandard。

### Q: 群聊消息只有 wxid 没有名字？
需要同时读取 contact.db 的 chatroom_member 表。`extract_full_data.py` 会自动处理。

## 技术细节

- **加密算法**: PBKDF2-HMAC-SHA1, 64000 迭代, 32 字节密钥, 4096 页大小
- **压缩**: zstd（magic bytes: `\x28\xb5\x2f\xfd`）
- **分表**: 消息按 `Msg_md5_hash % N` 分到多个表
- **时间戳**: Unix timestamp（秒）

## 免责声明

本工具仅供个人数据分析使用。请遵守当地法律法规，尊重他人隐私。
